@echo off
cls
title ROWA Contracts Manager - Local Runner

echo ==========================================================
echo        ROWA CONTRACTS AND CERTIFICATES SYSTEM
echo ==========================================================
echo.

:: [1] Check Node.js
echo [1/3] Checking Node.js environment...
node -v >nul 2>&1
if %errorlevel% neq 0 goto :node_missing
echo Node.js is installed successfully!
echo.
goto :check_dependencies

:node_missing
echo ----------------------------------------------------------
echo ERROR: Node.js was not found on your system!
echo Please download and install Node.js from the official site:
echo      https://nodejs.org
echo ----------------------------------------------------------
echo.
pause
exit /b

:check_dependencies
:: [2] Check and Install dependencies
if exist node_modules goto :run_app
echo.
echo ==========================================================
echo [2/3] Installing dependencies... Please wait a moment.
echo ==========================================================
echo.
goto :do_install

:do_install
echo.
call npm install --registry=https://registry.npmmirror.com --no-audit --no-fund
if %errorlevel% neq 0 echo Warning: Node package installation finished with some warnings.
echo.

:run_app
:: Configure default port to 3005 as requested
set PORT=3005
set NODE_ENV=production

:: Check if build is needed (First run or update)
if exist dist\server.cjs goto :launch_server

echo.
echo ==========================================================
echo [3/4] First-time setup: Compiling application for maximum speed...
echo ==========================================================
echo Please wait about 10-15 seconds while we build the optimized files...
echo.
call npm run build
if %errorlevel% neq 0 goto :build_failed
goto :launch_server

:build_failed
echo.
echo WARNING: Standard build compilation failed.
echo Attempting to run in Developer Mode fallback instead...
echo.
set NODE_ENV=development
goto :launch_developer

:launch_server
echo.
echo ==========================================================
echo [4/4] Starting local server in High-Performance Mode...
echo ----------------------------------------------------------
echo Server listening port is set to: %PORT%
echo Web application will open at: http://localhost:%PORT%
echo.
echo ** IMPORTANT INFO FOR WINDOWS USERS / معلومات هامة لتجنب تجميد التشغيل **
echo ----------------------------------------------------------
echo If you click inside this black window, Windows might PAUSE/FREEZE
echo the server execution. Just press ENTER or ESC to unfreeze it!
echo.
echo إذا قمت بالضغط بالماوس داخل هذه النافذة السوداء، فقد يتجمد التشغيل مؤقتاً.
echo اضغط على زر ENTER أو ESC في لوحة المفاتيح لإلغاء التجميد فوراً واستئناف العمل.
echo ----------------------------------------------------------
echo.

:: Open browser after a short delay
timeout /t 3 >nul 2>&1
start "" "http://localhost:3005"

:: Run compiled high-performance production server
call npm run start

if %errorlevel% neq 0 goto :run_failed
exit /b

:launch_developer
:: Fallback to developer dev mode if build files are missing
timeout /t 3 >nul 2>&1
start "" "http://localhost:3005"
call npm run dev
if %errorlevel% neq 0 goto :run_failed
exit /b

:run_failed
echo.
echo ERROR: Failed to start the server on Port %PORT%.
echo This usually happens if Port %PORT% is already in use by another app,
echo or if dependencies are not fully configured.
echo Please close all other command prompt windows and try opening start.bat again.
echo.
pause
exit /b
