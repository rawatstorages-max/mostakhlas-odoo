import { Certificate } from "../src/types";

/**
 * Analytics and helper utilities for project delay tracking and financial calculations
 */
export class AnalyticsService {
  /**
   * Calculate cumulative completion stats of a project certificate
   */
  public static calculateCertificateCompletion(cert: Certificate) {
    const contractVal = cert.contractValue || 1;
    const completedVal = cert.items.reduce((sum, item) => {
      const totalQty = item.prevQty + item.currQty;
      return sum + (totalQty * item.rate);
    }, 0);

    const percent = Math.min((completedVal / contractVal) * 100, 100);
    return {
      completedVal,
      percent,
      remainingVal: Math.max(contractVal - completedVal, 0)
    };
  }

  /**
   * Determine delay penalty liabilities
   */
  public static calculateDelayPenalty(cert: Certificate): number {
    if (!cert.isDelayAlertActive) return 0;
    const days = cert.delayDaysOfProject ?? 0;
    const rate = cert.delayPenaltyPerDayRate ?? 0;
    return days * rate;
  }
}
