import { Certificate } from "../types";

export const SAMPLE_CERTIFICATES: Certificate[] = [
  {
    id: "template-jari-7",
    title: "مستخلص جاري رقم 7 (المطابق للمرفق)",
    certificateNumber: "م-7",
    date: "2026-06-11",
    contractorName: "شركة روعة عالم التصميم للمقاولات",
    projectName: "مشروع إنشاء وتأثيث وتشطيب المقر الرئيسي ومرحلتي التوسعة الأولى والثانية",
    clientName: "مجموعة روعة القابضة",
    contractValue: 115682208, // 21,331,799.15 / 115,682,208 * 100 = 18.44% Overall Completion %
    contractDate: "2025-08-12",
    duration: "24 شهراً",
    retentionPercent: 5, // 5% ضمان أعمال
    advanceDeduction: 5, // 5% خصم دفعة مقدمة
    otherDeductions: 0,
    vatPercent: 15,
    previousPayments: 17599007.55,
    stageProgressPercent: 24.17, // نسبة الانجاز المرحله الاولي والثانيه %
    calculationMethod: "direct", // الحساب المباشر من المستخلص الحالي للمطابقة الكاملة
    siteEngineer: "م. محمد الحربي (مهندس التنفيذ)",
    consultantEngineer: "المهندس الاستشاري / المدير العام",
    contractorRepresentative: "ممثل شركة روعة عالم التصميم",
    createdAt: "2026-06-11T12:00:00Z",
    items: [
      {
        id: "j7-item-1",
        itemNumber: "1",
        description: "تجهيز الموقع وأعمال الهيكل الإنشائي والخرسانات والتشييد العام لمقر الشركة بجدة ومرحلتي التوسعة الأولى والثانية",
        unit: "متر مكعب",
        contractQty: 500000,
        rate: 100,
        prevQty: 125990.0755,
        currQty: 27327.916,
        notes: "تم الفحص الهندسي والخرسانات معتمدة بالكامل"
      },
      {
        id: "j7-item-2",
        itemNumber: "2",
        description: "أعمال الكهروميكانيك والتمديدات والشبكات الكهربائية والمائية التقنية المتقدمة",
        unit: "مقطوعية",
        contractQty: 1,
        rate: 33000000,
        prevQty: 0.10,
        currQty: 0.02,
        notes: "تمديد الأعمال مستمر بنجاح"
      },
      {
        id: "j7-item-3",
        itemNumber: "3",
        description: "التشطيبات المعمارية والواجهات والجدران الزجاجية والمجسمات وشارات الهوية",
        unit: "متر مسطح",
        contractQty: 120000,
        rate: 170,
        prevQty: 10000,
        currQty: 2000,
        notes: "تجليد وتكسية الواجهات الديكورية والملصقات ثلاثية الأبعاد"
      }
    ]
  },
  {
    id: "template-rowa",
    title: "مستخلص جاري رقم 1",
    certificateNumber: "م-1",
    date: "2026-05-03",
    contractorName: "شركة روعة عالم التصميم للمقاولات",
    projectName: "اعتماد أعمال دعاية وإعلان المقر الجديد لمجموعة روعة",
    clientName: "شركة روعة الاستثمارية",
    contractValue: 121200,
    contractDate: "2026-04-10",
    duration: "مدة العقد",
    retentionPercent: 10, // خصم 10% توقيفات
    advanceDeduction: 0,
    otherDeductions: 0,
    vatPercent: 15, // ضريبة القيمة المضافة لتقديم نموذج كامل وممتاز
    previousPayments: 0,
    siteEngineer: "م. محمد الحربي (مهندس التنفيذ)",
    consultantEngineer: "المهندس الاستشاري / المدير العام",
    contractorRepresentative: "ممثل شركة روعة عالم التصميم",
    createdAt: "2026-05-03T09:00:00Z",
    items: [
      {
        id: "item-1",
        itemNumber: "1",
        description: "تصميم وتوريد وتركيب مجسمات إعلانية مضيئة ثلاثية الأبعاد (3D Channel Letters) للمدخل الرئيسي للشركة بجدة بالهوية المعتمدة شاملة التمديدات الكهربائية وأجهزة التحكم والضمان والتشغيل والتركيب في الموقع.",
        unit: "مقطوعية",
        contractQty: 1,
        rate: 95000,
        prevQty: 0,
        currQty: 1,
        notes: "تم التركيب والتشغيل بنسبة 100% والاعتماد من مشرف الموقع"
      },
      {
        id: "item-2",
        itemNumber: "2",
        description: "طباعة وتوريد ملصقات فينيل جدارية داخلية مقاومة للرطوبة والخدش مع الحماية (Lamination) للديكورات والممرات والغرف والمكاتب الإدارية حسب التصاميم والمساحات المحددة بجدول الكميات.",
        unit: "متر مسطح",
        contractQty: 120,
        rate: 210,
        prevQty: 0,
        currQty: 120,
        notes: "مكتملة بالكامل ومسلمة حسب الفحص الهندسي للتشطيبات"
      }
    ]
  },
  {
    id: "template-villa",
    title: "مستخلص جاري رقم 3",
    certificateNumber: "م-3",
    date: "2026-06-09",
    contractorName: "مؤسسة الروافد للمقاولات العامة",
    projectName: "فيلا سكنية خاصة - حي النرجس بالرياض",
    clientName: "سعادة الأستاذ عبد الرحمن الخالدي",
    contractValue: 850000,
    contractDate: "2026-01-15",
    duration: "8 أشهر",
    retentionPercent: 5, // 5% ضمان أعمال
    advanceDeduction: 15000, // استرداد دفعة مقدمة
    otherDeductions: 1200, // جزاءات تأخير أو نظافة الموقع
    vatPercent: 15,
    previousPayments: 112000, // ما تم صرفه في المستخلصات السابقة 1 و 2
    siteEngineer: "م. يوسف العتيبي",
    consultantEngineer: "مكتب الإعمار للاستشارات الهندسية",
    contractorRepresentative: "م. خالد الرشيد (مدير المشروع)",
    createdAt: "2026-06-09T11:00:00Z",
    items: [
      {
        id: "v-item-1",
        itemNumber: "1",
        description: "أعمال الحفر والردم والتسوية لأرض المشروع تحت القواعد واللبشة شاملة النقل لمرامي البلدية والتنظيف والرش والدك طبقاً لتقرير فحص التربة المعتمد بالمشروع.",
        unit: "متر مكعب",
        contractQty: 450,
        rate: 35,
        prevQty: 450,
        currQty: 0,
        notes: "أعمال منتهية ومقاسة سابقاً"
      },
      {
        id: "v-item-2",
        itemNumber: "2",
        description: "خرسانة عادية عيار 250 كجم/سم3 مقاومة للأملاح والكبريتات أسفل القواعد والأساسات بسمك 10 سم شاملة الصب والرش بالماء وتجفيف القوالب طبقاً للمواصفات والمخططات التفصيلية.",
        unit: "متر مسطح",
        contractQty: 180,
        rate: 85,
        prevQty: 180,
        currQty: 0,
        notes: "أعمال منتهية ومقاسة سابقاً"
      },
      {
        id: "v-item-3",
        itemNumber: "3",
        description: "خرسانة مسلحة للقواعد والأساسات عيار 350 كجم/سم3 باستخدام الإسمنت المقاوم شاملة حديد التسليح الكويتي أو الراجحي وتوريد خرسانة جاهزة من مصنع معتمد والصب بالمضخة والاختبار والاختام والرش.",
        unit: "متر مكعب",
        contractQty: 110,
        rate: 450,
        prevQty: 90,
        currQty: 20,
        notes: "تم استكمال كامل الكمية بنسبة 100% في هذه الدورة"
      },
      {
        id: "v-item-4",
        itemNumber: "4",
        description: "خرسانة مسلحة لرقاب الأعمدة وميدات الأرضية شاملة الحديد والعزل المائي بمادة البتومين الحار ثلاث طبقات والردم بين الميدات على طبقات بسمك 30 سم والرش والدك وجدول تسوية التدفق.",
        unit: "متر مكعب",
        contractQty: 65,
        rate: 550,
        prevQty: 30,
        currQty: 30,
        notes: "تم بناء دكة الأرضية والصب وعزل الرقاب والميدات بنسبة 92%"
      },
      {
        id: "v-item-5",
        itemNumber: "5",
        description: "مباني الطوب الأسمنتي المعزول (البلوك الأسود المعزول جفالي) بسمك 20 سم للجدران الخارجية شامل المونة الأسمنتية والشبك والزوايا المعدنية وإبر التثبيت طبقاً للأصول الهندسية والمخططات.",
        unit: "متر مسطح",
        contractQty: 350,
        rate: 65,
        prevQty: 0,
        currQty: 140,
        notes: "بدء أعمال جدران الدور الأرضي بنجاح"
      }
    ]
  }
];
