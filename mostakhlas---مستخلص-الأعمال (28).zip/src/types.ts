export interface WorkItem {
  id: string;
  itemNumber: string; // e.g., "1", "1/أ", "2"
  description: string; // بيان الأعمال
  unit: string; // الوحدة (e.g., متر مسطح، متر مكعب، مقطوعية)
  contractQty: number; // الكمية الإجمالية بالعقد
  rate: number; // الفئة (سعر الوحدة)
  prevQty: number; // الكمية السابقة المنفذة
  currQty: number; // الكمية الحالية المنفذة
  notes: string; // ملاحظات
}

export interface Certificate {
  id: string;
  title: string; // e.g., مستخلص جاري رقم 1
  certificateNumber: string; // رقم المستخلص
  date: string; // تاريخ المستخلص
  contractorName: string; // اسم المقاول
  projectName: string; // اسم المشروع
  clientName: string; // اسم العميل / المالك
  contractValue: number; // قيمة العقد الإجمالية
  contractDate: string; // تاريخ بدء العمل / تاريخ العقد
  duration: string; // مدة العقد / المدة
  items: WorkItem[];
  retentionPercent: number; // نسبة التوقيفات (e.g., 5, 10)
  advanceDeduction: number; // خصم دفعة مقدمة
  otherDeductions: number; // خصومات أخرى
  vatPercent: number; // نسبة ضريبة القيمة المضافة (e.g., 15)
  previousPayments: number; // ما تم صرفه سابقاً
  siteEngineer: string; // مهندس الموقع / التنفيذ
  consultantEngineer: string; // المهندس الاستشاري / المدير العام
  contractorRepresentative: string; // ممثل المقاول
  createdAt: string;
  calculationMethod?: "cumulative" | "direct"; // طيقة الحساب التراكمي العام أو الحساب المباشر من جاري7
  stageProgressPercent?: number; // نسبة إرساء وإنجاز المرحلة الأولى والثانية
  // Delay Tracking Details & Reminders
  delayDaysOfProject?: number; // عدد أيام التأخير المتراكمة
  delayPenaltyPerDayRate?: number; // غرامة التأخير التعاقدية اليومية
  isDelayAlertActive?: boolean; // تفعيل جرس تنبيه التأخير
  delayRemedyNotes?: string; // إشعار ومبررات ومقترحات معالجة التأخير
}

export interface CompanyProfile {
  name: string;
  crNumber: string;
  vatNumber: string;
  address: string;
  phone: string;
  email: string;
  logoType: "initials" | "base64";
  logoInitials: string;
  logoBase64: string;
  logoColor: string;
}

export interface EmailData {
  to: string;
  subject: string;
  body: string;
}
