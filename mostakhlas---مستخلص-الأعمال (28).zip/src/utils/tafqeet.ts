/**
 * Arabic Number to Words (Tafqeet) Converter
 * Converts numeric amounts to formal Arabic words for financial certificates.
 */

const ones = ["", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة", "عشرة"];
const teens = ["عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر"];
const tens = ["", "عشرة", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون"];
const hundreds = ["", "مائة", "مائتان", "ثلاثمائة", "أربعمائة", "خمسمائة", "ستمائة", "سبعمائة", "ثمانمائة", "تسعمائة"];

function convertUnderThousand(num: number): string {
  if (num === 0) return "";

  let result = "";

  // Hundreds
  const h = Math.floor(num / 100);
  const remainder100 = num % 100;

  if (h > 0) {
    result += hundreds[h];
  }

  if (remainder100 === 0) return result;

  if (result !== "") result += " و ";

  // Tens and Ones
  if (remainder100 < 10) {
    result += ones[remainder100];
  } else if (remainder100 < 20) {
    result += teens[remainder100 - 10];
  } else {
    const t = Math.floor(remainder100 / 10);
    const o = remainder100 % 10;

    if (o > 0) {
      result += ones[o] + " و " + tens[t];
    } else {
      result += tens[t];
    }
  }

  return result;
}

export function numberToArabicWords(num: number): string {
  if (num === 0) return "صفر";

  // Handle decimals (halalas)
  const integerPart = Math.floor(num);
  const decimalPart = Math.round((num - integerPart) * 100);

  let result = "";

  if (integerPart > 0) {
    let temp = integerPart;
    const parts: string[] = [];

    // Billions
    const billions = Math.floor(temp / 1000000000);
    temp %= 1000000000;
    if (billions > 0) {
      if (billions === 1) parts.push("مليار");
      else if (billions === 2) parts.push("ملياران");
      else if (billions >= 3 && billions <= 10) parts.push(`${convertUnderThousand(billions)} مليارات`);
      else parts.push(`${convertUnderThousand(billions)} مليار`);
    }

    // Millions
    const millions = Math.floor(temp / 1000000);
    temp %= 1000000;
    if (millions > 0) {
      if (millions === 1) parts.push("مليون");
      else if (millions === 2) parts.push("مليونان");
      else if (millions >= 3 && millions <= 10) parts.push(`${convertUnderThousand(millions)} ملايين`);
      else parts.push(`${convertUnderThousand(millions)} مليون`);
    }

    // Thousands
    const thousands = Math.floor(temp / 1000);
    temp %= 1000;
    if (thousands > 0) {
      if (thousands === 1) parts.push("ألف");
      else if (thousands === 2) parts.push("ألفان");
      else if (thousands >= 3 && thousands <= 10) parts.push(`${convertUnderThousand(thousands)} آلاف`);
      else parts.push(`${convertUnderThousand(thousands)} ألف`);
    }

    // Hundreds, tens, ones
    if (temp > 0) {
      // Small grammar adjustments for standard flow
      parts.push(convertUnderThousand(temp));
    }

    result = parts.join(" و ");
  }

  let finalString = "فقط ";
  if (result) {
    finalString += result + " ريال سعودي";
  }

  if (decimalPart > 0) {
    if (result) {
      finalString += " و " + convertUnderThousand(decimalPart) + " هللة";
    } else {
      finalString += convertUnderThousand(decimalPart) + " هللة";
    }
  }

  finalString += " لا غير";
  return finalString;
}
