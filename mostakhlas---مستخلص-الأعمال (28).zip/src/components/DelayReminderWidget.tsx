import React from "react";
import { Certificate } from "../types";
import { AlertTriangle, Bell, Clock, ShieldAlert, BadgeInfo, CheckCircle2, TrendingDown, HelpCircle } from "lucide-react";

interface DelayReminderWidgetProps {
  certificate: Certificate;
  onUpdate: (updated: Partial<Certificate>) => void;
  isPrintView?: boolean;
}

export const DelayReminderWidget: React.FC<DelayReminderWidgetProps> = ({
  certificate,
  onUpdate,
  isPrintView = false,
}) => {
  const isAlertActive = certificate.isDelayAlertActive ?? false;
  const delayDays = certificate.delayDaysOfProject ?? 0;
  const penaltyRate = certificate.delayPenaltyPerDayRate ?? 0;
  const delayNotes = certificate.delayRemedyNotes ?? "";

  const totalPenalty = delayDays * penaltyRate;

  const handleToggleAlert = () => {
    onUpdate({ isDelayAlertActive: !isAlertActive });
  };

  const handleNumberChange = (field: "delayDaysOfProject" | "delayPenaltyPerDayRate", val: number) => {
    onUpdate({ [field]: val >= 0 ? val : 0 });
  };

  const handleNotesChange = (val: string) => {
    onUpdate({ delayRemedyNotes: val });
  };

  // Button to automatically deduct from the current certificate's other deductions
  const handleApplyAsDeduction = () => {
    onUpdate({ otherDeductions: totalPenalty });
    alert(`💸 تم ترحيل مبلغ ${totalPenalty.toLocaleString()} ريال كغرامات تأخير ضمن بند الخصومات في مستخلص الحسابات الجارية بنجاح!`);
  };

  if (isPrintView) {
    if (!isAlertActive) return null;
    return (
      <div className="w-full text-right mt-6 border-2 border-red-650 bg-white p-4 rounded-xl font-sans" dir="rtl">
        <div className="flex items-center gap-2 border-b-2 border-red-600 pb-2 mb-3">
          <ShieldAlert className="w-6 h-6 text-red-600" />
          <h3 className="font-extrabold text-base text-red-700">تذكرة إنذار ومتابعة تأخيرات المشروع المعتمدة</h3>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div className="bg-slate-50 p-2 rounded border border-slate-200">
            <span className="text-slate-500 block font-bold">حالة الإنذار:</span>
            <span className="text-red-700 font-extrabold text-xs">🚨 إنذار فني نشط بالتاخير</span>
          </div>
          <div className="bg-slate-50 p-2 rounded border border-slate-200">
            <span className="text-slate-500 block font-bold">أيام التأخير المسجلة:</span>
            <span className="font-bold text-red-700 font-mono text-sm">{delayDays} يوم</span>
          </div>
          <div className="bg-slate-50 p-2 rounded border border-slate-200">
            <span className="text-slate-500 block font-bold">غرامة التأخير اليومية:</span>
            <span className="font-bold text-slate-800 font-mono text-sm">{penaltyRate.toLocaleString()} ريال/يوم</span>
          </div>
          <div className="bg-red-50 p-2 rounded border border-red-200">
            <span className="text-red-800 block font-bold">إجمالي غرامة التأخير:</span>
            <span className="font-extrabold text-red-900 font-mono text-sm">{totalPenalty.toLocaleString()} ريال</span>
          </div>
        </div>

        {delayNotes && (
          <div className="mt-3 bg-amber-50/50 p-3 rounded-lg border border-amber-100 text-xs text-slate-800 leading-relaxed font-semibold">
            <span className="text-amber-800 font-bold block mb-1">📝 أسباب التأخير والتقرير الميداني والمبررات التعاقدية للجنة:</span>
            <p>{delayNotes}</p>
          </div>
        )}

        <div className="mt-4 pt-2 border-t border-dashed border-gray-300 flex justify-between items-center text-[10px] text-slate-400">
          <span>* تم احتساب غرامات التأخير طبقاً للأنظمة الفنية وجداول الشروط الخاصة لشركة روعة عالم التصميم للمقاولات</span>
          <span>توقيع واعتماد استشاري العقد: ...............................</span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 text-right space-y-5" dir="rtl">
      {/* Widget Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <h3 className="text-lg font-bold text-slate-900 flex items-center justify-end gap-2">
            <span>تذكرة ومتابعة التأخير وغرامات الإجازة الفنية</span>
            <Clock className="w-5 h-5 text-amber-500" />
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            تابع التأجيلات الزمنية للموقع، واحسب غرامات التأخير الموقعة مع تفعيل تذاكر التنبيه ومبرراتها للملكف الـفـني
          </p>
        </div>

        {/* Master Switch on/off with custom sleek styling */}
        <button
          onClick={handleToggleAlert}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all duration-150 flex items-center gap-1.5 cursor-pointer border ${
            isAlertActive
              ? "bg-rose-50 border-rose-200 text-rose-700 shadow-inner"
              : "bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200"
          }`}
        >
          <Bell className={`w-3.5 h-3.5 ${isAlertActive ? "animate-bounce" : ""}`} />
          {isAlertActive ? "إلغاء تنشيط تذكرة التأخير" : "تنشيط تذكرة وتنبيه التأخير للطباعة"}
        </button>
      </div>

      {isAlertActive ? (
        <div className="space-y-4 animate-in fade-in slide-in-from-top-3 duration-200">
          {/* Main alarm block */}
          <div className="bg-amber-50/70 border border-amber-200/80 p-4 rounded-2xl flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="flex items-start gap-3 w-full md:w-auto">
              <div className="p-3 bg-amber-500/15 rounded-xl border border-amber-400/20 text-amber-600">
                <AlertTriangle className="w-6 h-6 animate-pulse" />
              </div>
              <div className="text-right">
                <p className="text-xs font-black text-amber-900">🚨 جرس إنذار التأخير نشط حالياً على هذا المستخلص</p>
                <p className="text-[11px] text-amber-800 font-semibold mt-1">
                  سيتم تضمين ملحق رسمي لحسابات غرامات التأخير في النسخة المطبوعة للمستخلص وExcel لمراجعتها مع المالك.
                </p>
              </div>
            </div>

            {totalPenalty > 0 && (
              <button
                type="button"
                onClick={handleApplyAsDeduction}
                className="bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs px-4 py-2 rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow-sm"
              >
                <TrendingDown className="w-4 h-4" />
                <span>ترحيل غرامة التأخير كخصم مالي مباشر للمقاصة</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Delay days */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1 justify-end">
                <span>عدد أيام التأخير الفعلية بالموقع</span>
                <Clock className="w-3.5 h-3.5 text-slate-400" />
              </label>
              <input
                type="number"
                min={0}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-850 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white"
                value={delayDays}
                onChange={(e) => handleNumberChange("delayDaysOfProject", parseInt(e.target.value) || 0)}
                placeholder="مثال: 15 يوم"
              />
            </div>

            {/* Daily fine */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1 justify-end">
                <span>غرامة التأخير اليومية المعتمدة (ريال)</span>
                <TrendingDown className="w-3.5 h-3.5 text-slate-400" />
              </label>
              <input
                type="number"
                min={0}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-850 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white"
                value={penaltyRate}
                onChange={(e) => handleNumberChange("delayPenaltyPerDayRate", parseFloat(e.target.value) || 0)}
                placeholder="مثال: 500 ريال"
              />
            </div>

            {/* Dynamic Calculated Penalty Output */}
            <div className="bg-rose-50/60 border border-rose-100 p-4 rounded-xl flex flex-col justify-center text-center">
              <span className="text-[10px] text-rose-800 font-bold">إجمالي قيمة غرامة التأخير المتراكمة</span>
              <span className="text-lg font-black font-mono text-rose-900 mt-1">{totalPenalty.toLocaleString()} ريال</span>
            </div>

            {/* Realtime Status Indicator Card */}
            <div className="bg-slate-50 border border-slate-150 p-4 rounded-xl flex flex-col justify-center text-center">
              <span className="text-[10px] text-slate-600 font-bold">حالة غرامة المشروع</span>
              <span className="text-xs font-black text-amber-800 mt-1 flex items-center gap-1 justify-center">
                <span>{delayDays > 0 ? "⚠️ يستحق خصم مالي" : "✅ منضبط بالخطة"}</span>
              </span>
            </div>
          </div>

          {/* Justifications of Delay */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1 justify-end">
              <span>أسباب ومبررات التأخير أو محاضر تمديد المشروع المعتمدة</span>
              <BadgeInfo className="w-3.5 h-3.5 text-slate-400" />
            </label>
            <textarea
              rows={2}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-850 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white placeholder:text-slate-450 font-semibold"
              value={delayNotes}
              onChange={(e) => handleNotesChange(e.target.value)}
              placeholder="اكتب أسباب التأخير (مثال: تأخير استلام المخططات المعتمدة من الاستشاري، أو ظروف الطقس وتعديلات المالك...)"
            />
          </div>
        </div>
      ) : (
        /* Empty/Safe state */
        <div className="bg-slate-50 hover:bg-slate-100/70 p-6 rounded-2xl border border-dashed border-slate-200 text-center flex flex-col items-center justify-center py-8 transition">
          <CheckCircle2 className="w-8 h-8 text-emerald-500 mb-2" />
          <h4 className="text-xs font-bold text-slate-800">لا يوجد تأخيرات مسجلة بالمشروع حتى الآن</h4>
          <p className="text-[11px] text-slate-450 mt-1">مشروع منضبط في الجداول الزمنية لتسليم بنود المقاولة حسب البدايات المخططة</p>
        </div>
      )}
    </div>
  );
};
