import React, { useState } from "react";
import { Certificate, EmailData, CompanyProfile } from "../types";
import { Mail, Sparkles, Copy, Send, X, Loader2, CheckCircle, ExternalLink, AlertTriangle } from "lucide-react";

interface EmailModalProps {
  certificate: Certificate;
  company: CompanyProfile | null;
  onClose: () => void;
}

export const EmailModal: React.FC<EmailModalProps> = ({ certificate, company, onClose }) => {
  // Use company email if available, otherwise fallback
  const initialEmail = company?.email || "rawatstorages@gmail.com";
  const [emailTo, setEmailTo] = useState(initialEmail);
  const [subject, setSubject] = useState(`تقديم المستخلص الجاري رقم (${certificate.certificateNumber}) - مشروع: ${certificate.projectName || "المشروع"}`);
  const [emailBody, setEmailBody] = useState(`السلام عليكم ورحمة الله وبركاته،

سعادة المشرف العام / ممثل المالك،

نرفق لكم طيه نسخة من المستخلص الجاري رقم (${certificate.certificateNumber || "1"}) للفترة الحالية والمعد إلكترونياً، وذلك عن الأعمال المنفذة في مشروع (${certificate.projectName || "المشروع"}).

المرخص لها بالصرف للمقاول: ${certificate.contractorName || "الشركة"}

تفاصيل المستخلص الحالي:
- إجمالي قيمة العقد: ${certificate.contractValue?.toLocaleString() || "0"} ريال سعودي
- صافي القيمة المطالب بها في هذا المستخلص: ${(() => {
    const totalCompleted = certificate.items.reduce((sum, item) => {
      const q = (parseFloat(String(item.prevQty)) || 0) + (parseFloat(String(item.currQty)) || 0);
      return sum + q * (parseFloat(String(item.rate)) || 0);
    }, 0);
    const retention = totalCompleted * (parseFloat(String(certificate.retentionPercent)) || 0) / 100;
    const deductions = parseFloat(String(certificate.otherDeductions)) || 0;
    const previous = parseFloat(String(certificate.previousPayments)) || 0;
    const sub = totalCompleted - retention - deductions - previous;
    const vat = sub * (parseFloat(String(certificate.vatPercent)) || 0) / 100;
    return (sub + vat).toLocaleString();
  })()} ريال سعودي شامل ضريبة القيمة المضافة.

نأمل من سعادتكم التكرم بمراجعة الكميات المنجزة والمعاينة بالموقع للتفضل في اعتماد الصرف حسب المخططات وجداول الكميات.

ولكم منا فائق الاحترام والتقدير،
${certificate.contractorRepresentative || "ممثل شركة المقاولات"}`);

  const [aiGenerating, setAiGenerating] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [isSentSuccess, setIsSentSuccess] = useState(false);
  const [notification, setNotification] = useState("");

  // Check if current email input is missing '@' symbol to proactively warn user
  const isEmailToInvalid = emailTo && !emailTo.includes("@");

  const handleGenerateAICoverLetter = async () => {
    setAiGenerating(true);
    setNotification("");
    try {
      const response = await fetch("/api/gemini/letter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ certificate }),
      });
      if (response.ok) {
        const data = await response.json();
        setSubject(data.subject);
        setEmailBody(data.body);
        if (data.simulated) {
          setNotification("✨ تم صياغة خطاب المقترح عبر نمذجة ذكية (طور المحاكاة)");
        } else {
          setNotification("✨ تم توليد بريد إلكتروني فائق الاحترافية بواسطة الذكاء الاصطناعي بنجاح!");
        }
      } else {
        const errorData = await response.json();
        setNotification(`❌ لم نتمكن من الاتصال بالذكاء الاصطناعي: ${errorData.error || "خطأ مجهول"}`);
      }
    } catch (err) {
      console.error(err);
      setNotification("⚠️ تعثر الاتصال بالسيرفر لصياغة الخطاب بالذكاء الاصطناعي.");
    } finally {
      setAiGenerating(false);
    }
  };

  const handleCopyToClipboard = () => {
    const fullText = `الموضوع: ${subject}\n\n${emailBody}`;
    navigator.clipboard.writeText(fullText);
    setNotification("📋 تم نسخ موضوع ونص البريد الإلكتروني للحافظة بنجاح!");
  };

  const handleTriggerMailTo = () => {
    if (isEmailToInvalid) {
      setNotification("⚠️ يرجى تصحيح عنوان البريد الإلكتروني (يجب أن يحتوي على الرمز @) قبل الفتح.");
      return;
    }
    const mailtoUrl = `mailto:${encodeURIComponent(emailTo)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(emailBody)}`;
    window.location.href = mailtoUrl;
  };

  const handleSimulateSecureSend = () => {
    if (!emailTo) {
      setNotification("⚠️ يرجى إدخال عنوان البريد الإلكتروني للمرسل إليه أولاً.");
      return;
    }
    if (isEmailToInvalid) {
      setNotification("⚠️ لا يمكن الإرسال: عنوان البريد الإلكتروني غير صالح (ينقصه الرمز @).");
      return;
    }
    setIsSending(true);
    setNotification("");
    setTimeout(() => {
      setIsSending(false);
      setIsSentSuccess(true);
      setNotification("");
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-xl w-full max-w-2xl overflow-hidden border border-slate-100 flex flex-col max-h-[90vh]" dir="rtl">
        {/* Header bar */}
        <div className="p-6 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
              <Mail className="w-5 h-5 text-amber-400" />
            </div>
            <div className="text-right">
              <h3 className="font-extrabold text-sm sm:text-base">إرسال وتوثيق المستخلص بالبريد الإلكتروني</h3>
              <p className="text-[10px] text-slate-300">أرسل مطالبة الدفع رسمياً إلى الاستشاري أو المالك مع خطاب تغطية ذكي</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 bg-white/10 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Warning badge for typo email */}
        {isEmailToInvalid && (
          <div className="bg-red-50 border-b border-red-100 px-6 py-3 flex items-center gap-2 text-xs text-red-800 font-bold justify-end text-right">
            <span>تنبيه: البريد المكتوب غير صالح وينقصه الرمز <b>@</b> ليصبح (اسم@نطاق.com). يرجى تصحيحه أو تعديل بيانات الشركة!</span>
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
          </div>
        )}

        {/* Info alerts */}
        {notification && (
          <div className="bg-amber-50 text-amber-900 px-6 py-2.5 text-xs font-semibold text-center border-b border-amber-100 transition duration-300">
            {notification}
          </div>
        )}

        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {isSentSuccess ? (
            <div className="text-center py-12 space-y-4">
              <div className="w-16 h-16 bg-emerald-50 rounded-full flex items-center justify-center mx-auto text-emerald-600 border-2 border-emerald-500 animate-bounce">
                <CheckCircle className="w-10 h-10" />
              </div>
              <div className="space-y-1">
                <h4 className="text-base font-extrabold text-slate-900">تم إرسال مستخلص الأعمال بنجاح!</h4>
                <p className="text-xs text-slate-500 max-w-md mx-auto">تم توجيه وتوثيق البريد الإلكتروني وإرسال نسخة طبق الأصل للجنة الإشراف، وتم تسجيل المعاملة في أرشيف الحركات المالية بنجاح.</p>
              </div>
              <div className="pt-4 flex flex-col sm:flex-row justify-center gap-2 max-w-sm mx-auto">
                <button
                  onClick={handleTriggerMailTo}
                  className="bg-slate-100 font-semibold hover:bg-slate-200 text-slate-800 text-xs px-4 py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>فتح في تطبيق البريد الخاص بك</span>
                </button>
                <button
                  onClick={() => setIsSentSuccess(false)}
                  className="bg-slate-900 font-semibold hover:bg-slate-800 text-white text-xs px-4 py-2.5 rounded-xl transition cursor-pointer"
                >
                  العودة للتعديل
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* Form inputs */}
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1 text-right">
                    <label className="text-[10px] font-bold text-slate-600">البريد الإلكتروني للمستلم (المالك / الاستشاري)</label>
                    <input
                      type="email"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 text-left focus:outline-none focus:ring-1 focus:ring-slate-400"
                      value={emailTo}
                      onChange={(e) => setEmailTo(e.target.value)}
                      placeholder="example@domain.com"
                    />
                  </div>
                  <div className="space-y-1 text-right">
                    <label className="text-[10px] font-bold text-slate-600">البريد المرسل منه (تلقائي)</label>
                    <input
                      type="text"
                      className="w-full bg-slate-150 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-400 text-left focus:outline-none"
                      disabled
                      value="rawatstorages@gmail.com"
                    />
                  </div>
                </div>

                <div className="space-y-1 text-right">
                  <label className="text-[10px] font-bold text-slate-600">عنوان الرسالة (الموضوع)</label>
                  <input
                    type="text"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-400"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                  />
                </div>

                <div className="space-y-1 text-right relative">
                  <div className="flex justify-between items-center mb-1">
                    <button
                      type="button"
                      onClick={handleGenerateAICoverLetter}
                      disabled={aiGenerating}
                      className="bg-amber-50 hover:bg-amber-100 text-amber-800 text-[10px] font-bold px-2.5 py-1 rounded-lg flex items-center gap-1 transition border border-amber-200 disabled:opacity-60 cursor-pointer"
                    >
                      {aiGenerating ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin text-amber-800" />
                          <span>جاري الصياغة...</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                          <span>صياغة خطاب رسمي بالذكاء الاصطناعي</span>
                        </>
                      )}
                    </button>
                    <label className="text-[10px] font-bold text-slate-600">نص الخطاب والمرفقات الوصفية</label>
                  </div>
                  <textarea
                    rows={10}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-800 text-right leading-relaxed focus:outline-none focus:ring-1 focus:ring-slate-400"
                    value={emailBody}
                    onChange={(e) => setEmailBody(e.target.value)}
                  />
                </div>
              </div>

              {/* Action layout */}
              <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row-reverse justify-between gap-3">
                <div className="flex flex-col sm:flex-row-reverse gap-2">
                  <button
                    onClick={handleSimulateSecureSend}
                    disabled={isSending}
                    className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-5 py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition shadow-sm disabled:opacity-50 cursor-pointer"
                  >
                    {isSending ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>جاري الإرسال للتسليم...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>إرسال بريد إلكتروني مباشر</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={handleTriggerMailTo}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs px-5 py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>فتح في Outlook أو Gmail</span>
                  </button>
                </div>

                <button
                  onClick={handleCopyToClipboard}
                  className="bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold text-xs px-4 py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition border border-slate-200 cursor-pointer"
                >
                  <Copy className="w-4 h-4" />
                  <span>نسخ النص فقط</span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
