import React, { useState } from "react";
import { KeyRound, User, Lock, Eye, EyeOff, FileCheck, Loader2 } from "lucide-react";

interface LoginScreenProps {
  onLoginSuccess: (data: {
    token: string;
    company: any;
    certificates: any[];
    username: string;
  }) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess }) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleOfflineLogin = () => {
    const localSavedCompany = localStorage.getItem("mostakhlas_offline_company");
    const localSavedCerts = localStorage.getItem("mostakhlas_offline_certificates");

    const defaultCompany = {
      name: "شركة روعة عالم التصميم للمقاولات",
      crNumber: "4030201099",
      vatNumber: "310123456700003",
      address: "المملكة العربية السعودية، جدة",
      phone: "+966 50 123 4567",
      email: "rawatstorages@gmail.com",
      logoType: "initials",
      logoInitials: "CR",
      logoColor: "#dc2626",
      logoBase64: ""
    };

    localStorage.setItem("mostakhlas_offline_mode", "true");
    localStorage.setItem("mostakhlas_session_token", "offline_session_token_2026");

    let parsedCerts = [];
    if (localSavedCerts) {
      try {
        parsedCerts = JSON.parse(localSavedCerts);
      } catch (e) {
        console.error(e);
      }
    }

    let parsedCompany = defaultCompany;
    if (localSavedCompany) {
      try {
        parsedCompany = JSON.parse(localSavedCompany);
      } catch (e) {
        console.error(e);
      }
    }

    onLoginSuccess({
      token: "offline_session_token_2026",
      company: parsedCompany,
      certificates: parsedCerts,
      username: "الضيف (نمط محلي أوفلاين)"
    });
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      setErrorMsg("⚠️ يرجى إدخال اسم المستخدم وكلمة المرور.");
      return;
    }

    setLoading(true);
    setErrorMsg("");

    try {
      const response = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: username.trim(),
          password: password.trim(),
        }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        onLoginSuccess({
          token: data.token,
          company: data.company,
          certificates: data.certificates,
          username: data.username,
        });
      } else {
        setErrorMsg(data.error || "خطأ غير متوقع أثناء محاولة الدخول.");
      }
    } catch (err) {
      console.error("Login request failed:", err);
      setErrorMsg("⚠️ تعذر الاتصال بالسيرفر. تأكد من تشغيل الخادم بشكل صحيح.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div 
      className="min-h-screen bg-slate-900 flex items-center justify-center p-4 sm:p-6"
      style={{
        backgroundImage: "radial-gradient(circle at top right, rgba(239, 68, 68, 0.08), transparent 350px), radial-gradient(circle at bottom left, rgba(79, 70, 229, 0.08), transparent 400px)"
      }}
      dir="rtl"
    >
      <div className="w-full max-w-md bg-slate-950/80 border border-slate-800/80 rounded-3xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl space-y-6 text-right animate-in fade-in slide-in-from-bottom-6 duration-300">
        
        {/* Identity Head */}
        <div className="flex flex-col items-center text-center space-y-3">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-rose-600 to-indigo-600 p-3 flex items-center justify-center border border-rose-500/10 shadow-lg shadow-rose-950/20">
            <FileCheck className="w-9 h-9 text-white" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">نظام إدارة الفوترة والمستخلصات</h1>
            <p className="text-xs text-slate-400 font-medium mt-1">مشروع المستخلصات الإنشائية - روعة عالم التصميم للمقاولات</p>
          </div>
        </div>

        {/* Informational default credentials notice */}
        <div className="bg-slate-900/90 border border-slate-800/60 p-4 rounded-2xl space-y-1">
          <p className="text-[11px] font-black text-amber-400 flex items-center gap-1 justify-end">
            <span>بيانات الدخول الافتراضية للتجربة السريعة:</span>
            <span>💡</span>
          </p>
          <div className="flex justify-between items-center text-xs text-slate-300 pt-1 text-left font-mono">
            <span className="bg-slate-950 px-2 py-0.5 rounded border border-slate-800">123</span>
            <span className="font-sans text-[11px] text-slate-450 text-right">كلمة المرور:</span>
            <span className="bg-slate-950 px-2 py-0.5 rounded border border-slate-800">admin</span>
            <span className="font-sans text-[11px] text-slate-450 text-right">المستخدم:</span>
          </div>
        </div>

        {/* Error message */}
        {errorMsg && (
          <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 px-4 py-2.5 rounded-xl text-xs font-bold text-center">
            {errorMsg}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleLoginSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-350 flex items-center justify-end">اسم المستخدم</label>
            <div className="relative">
              <input
                type="text"
                required
                className="w-full bg-slate-900/60 border border-slate-800 hover:border-slate-700 focus:border-slate-500 rounded-xl pl-3 pr-10 py-3 text-sm text-white placeholder:text-slate-600 focus:outline-none transition text-right"
                placeholder="أدخل اسم المستخدم"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
              <User className="w-5 h-5 text-slate-500 absolute right-3.5 top-3.5" />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-350 flex items-center justify-end">كلمة المرور</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                required
                className="w-full bg-slate-900/60 border border-slate-800 hover:border-slate-700 focus:border-slate-500 rounded-xl pl-11 pr-10 py-3 text-sm text-white placeholder:text-slate-600 focus:outline-none transition text-right"
                placeholder="أدخل كلمة المرور"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <Lock className="w-5 h-5 text-slate-500 absolute right-3.5 top-3.5" />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="text-slate-500 hover:text-slate-400 p-1.5 absolute left-3.5 top-2 rounded-lg cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-tr from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white font-bold text-sm tracking-wide py-3 rounded-xl transition-all duration-150 cursor-pointer shadow-lg shadow-rose-955/20 flex items-center justify-center gap-2 mt-2"
          >
            {loading ? (
              <Loader2 className="w-4 h-4 animate-spin text-white" />
            ) : (
              <>
                <KeyRound className="w-4 h-4 text-red-100" />
                <span>دخول آمن للنظام</span>
              </>
            )}
          </button>

          <div className="flex items-center my-3 justify-center gap-2">
            <div className="flex-grow h-[1px] bg-slate-800"></div>
            <span className="text-[11px] font-bold text-slate-500 font-sans">أو البديل</span>
            <div className="flex-grow h-[1px] bg-slate-800"></div>
          </div>

          <button
            type="button"
            onClick={handleOfflineLogin}
            className="w-full bg-slate-900 hover:bg-slate-850 text-amber-500 border border-amber-500/20 hover:border-amber-500/40 font-bold text-xs py-3 rounded-xl transition-all duration-150 cursor-pointer flex items-center justify-center gap-1.5 shadow-md"
          >
            <span>🌐</span>
            <span>الدخول بوضع العمل دون اتصال (أوفلاين)</span>
          </button>
        </form>

        <div className="text-center pt-2">
          <p className="text-[10px] text-slate-500 font-mono">
            Mostakhlas Management Board © {new Date().getFullYear()}
          </p>
        </div>

      </div>
    </div>
  );
};
