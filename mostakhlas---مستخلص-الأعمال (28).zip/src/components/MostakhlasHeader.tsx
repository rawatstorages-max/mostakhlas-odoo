import React from "react";
import { Certificate, CompanyProfile } from "../types";
import { FileSpreadsheet, Calendar, ShieldCheck, DollarSign, Clock, Briefcase, User } from "lucide-react";

interface MostakhlasHeaderProps {
  certificate: Certificate;
  onUpdate: (updated: Partial<Certificate>) => void;
  isPrintView: boolean;
  company: CompanyProfile | null;
}

export const MostakhlasHeader: React.FC<MostakhlasHeaderProps> = ({
  certificate,
  onUpdate,
  isPrintView,
  company,
}) => {
  const handleChange = (field: keyof Certificate, value: any) => {
    onUpdate({ [field]: value });
  };

  // If in Print View / Document Preview, render like the classic Excel style from the user image
  if (isPrintView) {
    return (
      <div className="w-full text-right" dir="rtl">
        {/* Document Frame Top: Logos and Title */}
        <div className="grid grid-cols-3 border-t-2 border-x-2 border-black p-4 items-center bg-white font-sans">
          {/* Left Block: Traditional administrative details */}
          <table className="w-full text-xs border border-gray-300 text-slate-800">
            <tbody>
              <tr className="border-b border-gray-300">
                <td className="bg-gray-100 p-1.5 font-bold border-l border-gray-300 w-1/3">المقاول</td>
                <td className="p-1.5 font-semibold text-slate-900">{company?.name || certificate.contractorName || "-"}</td>
              </tr>
              <tr className="border-b border-gray-300">
                <td className="bg-gray-100 p-1.5 font-bold border-l border-gray-300">أعمال</td>
                <td className="p-1.5 text-slate-700">{certificate.projectName || "-"}</td>
              </tr>
              <tr className="border-b border-gray-300">
                <td className="bg-gray-100 p-1.5 font-bold border-l border-gray-300">عن المدة</td>
                <td className="p-1.5 text-slate-700">{certificate.duration || "مدة العقد"}</td>
              </tr>
              <tr className="border-b border-gray-300">
                <td className="bg-gray-100 p-1.5 font-bold border-l border-gray-300">قيمة العقد</td>
                <td className="p-1.5 font-bold text-slate-900">
                  {certificate.contractValue ? `${certificate.contractValue.toLocaleString()} ريال` : "-"}
                </td>
              </tr>
              <tr>
                <td className="bg-gray-100 p-1.5 font-bold border-l border-gray-300">بدء العمل</td>
                <td className="p-1.5 text-slate-700">{certificate.contractDate || "-"}</td>
              </tr>
            </tbody>
          </table>

          {/* Center Block: Corporate insignia/visual representation */}
          <div className="flex flex-col items-center justify-center">
            {company?.logoType === "base64" && company.logoBase64 ? (
              <img
                src={company.logoBase64}
                alt={company.name}
                className="max-h-16 max-w-full rounded object-contain mb-1"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div 
                className="w-16 h-16 rounded-full flex items-center justify-center text-white font-extrabold text-lg tracking-wider font-mono shadow-sm mb-1"
                style={{ backgroundColor: company?.logoColor || "#dc2626" }}
              >
                {company?.logoInitials || "CR"}
              </div>
            )}
            <span className="text-[10px] text-slate-400 font-mono tracking-widest uppercase">Certified Contractor</span>
          </div>

          {/* Right Block: Company Name Heading and Meta */}
          <div className="text-left flex flex-col justify-between h-full pl-2">
            <div className="text-right">
              <h1 className="text-sm sm:text-base font-extrabold text-slate-900 tracking-tight">
                {company?.name || "شركة روعة عالم التصميم للمقاولات"}
              </h1>
              {company?.crNumber && (
                <p className="text-[11px] text-slate-500 mt-0.5">سجل تجاري رقم: <span className="font-mono">{company.crNumber}</span></p>
              )}
              {company?.vatNumber && (
                <p className="text-[10px] text-slate-400">الرقم الضريبي: <span className="font-mono">{company.vatNumber}</span></p>
              )}
              {company?.phone && (
                <p className="text-[10px] text-slate-400">الهاتف: <span className="font-mono">{company.phone}</span></p>
              )}
            </div>
            <div className="text-right mt-3">
              <h2 className="text-base font-bold text-red-700">{certificate.title || "مستخلص أعمال"}</h2>
              <p className="text-xs font-mono text-slate-600 mt-0.5">تاريخ الإصدار: {certificate.date}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Otherwise, render as high-end contemporary Form for editing
  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 text-right" dir="rtl">
      {/* Visual Indicator Title */}
      <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-6">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center border border-slate-100">
            <FileSpreadsheet className="w-5 h-5 text-slate-600" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900">البيانات الإدارية والتعاقدية</h3>
            <p className="text-xs text-slate-500">حدد معلومات المشروع وأطراف التعاقد باللغة العربية</p>
          </div>
        </div>
      </div>

      {/* Grid of form elements */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {/* Title & Ref */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5 justify-end">
            <span>مسمى المستخلص</span>
            <FileSpreadsheet className="w-3.5 h-3.5 text-slate-400" />
          </label>
          <input
            type="text"
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white transition"
            placeholder="مثال: مستخلص جاري رقم 3"
            value={certificate.title}
            onChange={(e) => handleChange("title", e.target.value)}
          />
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5 justify-end">
            <span>رقم المستخلص</span>
            <Briefcase className="w-3.5 h-3.5 text-slate-400" />
          </label>
          <input
            type="text"
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white transition"
            placeholder="مثال: م-3"
            value={certificate.certificateNumber}
            onChange={(e) => handleChange("certificateNumber", e.target.value)}
          />
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5 justify-end">
            <span>تاريخ المستخلص</span>
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
          </label>
          <input
            type="date"
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white transition"
            value={certificate.date}
            onChange={(e) => handleChange("date", e.target.value)}
          />
        </div>

        {/* Contractor / Client */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5 justify-end">
            <span>اسم شركة المقاولات (المقاول)</span>
            <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
          </label>
          <input
            type="text"
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white transition animate-none"
            placeholder="مثال: شركة روعة عالم التصميم للمقاولات"
            value={certificate.contractorName}
            onChange={(e) => handleChange("contractorName", e.target.value)}
          />
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5 justify-end">
            <span>العميل / مالك المشروع</span>
            <User className="w-3.5 h-3.5 text-slate-400" />
          </label>
          <input
            type="text"
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white transition"
            placeholder="اسم العميل أو الجهة المالكة"
            value={certificate.clientName}
            onChange={(e) => handleChange("clientName", e.target.value)}
          />
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5 justify-end">
            <span>بيان وبيانات الأعمال</span>
            <Briefcase className="w-3.5 h-3.5 text-slate-400" />
          </label>
          <input
            type="text"
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white transition"
            placeholder="تفاصيل الأعمال المتضمنة"
            value={certificate.projectName}
            onChange={(e) => handleChange("projectName", e.target.value)}
          />
        </div>

        {/* Financial contract details */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5 justify-end">
            <span>قيمة العقد الكلية بالمشروع (ريال)</span>
            <DollarSign className="w-3.5 h-3.5 text-slate-400" />
          </label>
          <input
            type="number"
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white transition"
            placeholder="مثال: 140000"
            value={certificate.contractValue || ""}
            onChange={(e) => handleChange("contractValue", parseFloat(e.target.value) || 0)}
          />
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5 justify-end">
            <span>عن المدة / مدة العقد</span>
            <Clock className="w-3.5 h-3.5 text-slate-400" />
          </label>
          <input
            type="text"
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white transition"
            placeholder="مثال: مدة العقد أو من تاريخه إلى..."
            value={certificate.duration}
            onChange={(e) => handleChange("duration", e.target.value)}
          />
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5 justify-end">
            <span>تاريخ بدء العمل</span>
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
          </label>
          <input
            type="text"
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white transition"
            placeholder="مثال: 2026/05/10م"
            value={certificate.contractDate}
            onChange={(e) => handleChange("contractDate", e.target.value)}
          />
        </div>
      </div>
    </div>
  );
};
