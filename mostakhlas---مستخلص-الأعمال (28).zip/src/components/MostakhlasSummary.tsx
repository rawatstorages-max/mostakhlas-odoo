import React from "react";
import { Certificate } from "../types";
import { numberToArabicWords } from "../utils/tafqeet";
import { Landmark, Percent, Scale, FileSignature, Coins } from "lucide-react";

interface MostakhlasSummaryProps {
  certificate: Certificate;
  onUpdate: (updated: Partial<Certificate>) => void;
  isPrintView: boolean;
}

export const MostakhlasSummary: React.FC<MostakhlasSummaryProps> = ({
  certificate,
  onUpdate,
  isPrintView,
}) => {
  const handleChange = (field: keyof Certificate, value: any) => {
    onUpdate({ [field]: value });
  };

  // Safe parsing values
  const vatPercent = parseFloat(String(certificate.vatPercent)) || 0;
  const retentionPercent = parseFloat(String(certificate.retentionPercent)) || 0;
  const advanceDeduction = parseFloat(String(certificate.advanceDeduction)) || 0;
  const otherDeductions = parseFloat(String(certificate.otherDeductions)) || 0;
  const previousPayments = parseFloat(String(certificate.previousPayments)) || 0;
  const stageProgressPercent = parseFloat(String(certificate.stageProgressPercent)) || 0;
  const isDirect = certificate.calculationMethod === "direct";

  // Compute primary totals from work items
  const totalCompletedWorksVal = certificate.items.reduce((sum, item) => {
    const totalQty = (parseFloat(String(item.prevQty)) || 0) + (parseFloat(String(item.currQty)) || 0);
    return sum + totalQty * (parseFloat(String(item.rate)) || 0);
  }, 0);

  // Compute previous works value
  const previousCompletedWorksVal = certificate.items.reduce((sum, item) => {
    return sum + (parseFloat(String(item.prevQty)) || 0) * (parseFloat(String(item.rate)) || 0);
  }, 0);

  // Compute current works value prior to deductions/VAT
  const currentWorksVal = certificate.items.reduce((sum, item) => {
    return sum + (parseFloat(String(item.currQty)) || 0) * (parseFloat(String(item.rate)) || 0);
  }, 0);

  // Declare variables for calculation
  let retentionAmount = 0;
  let advanceDeductionAmount = 0;
  let netCumulativeWorksValue = 0;
  let currentNetDueBeforeVat = 0;
  let currentNetDuePositive = 0;
  let vatAmount = 0;
  let finalNetPayableCurrent = 0;
  let currentValueAfterAdvance = 0;
  let currentValueWithVat = 0;

  if (isDirect) {
    // 1. Advance payment deduction (e.g. 5% of current works)
    advanceDeductionAmount = currentWorksVal * (advanceDeduction / 100);
    
    // 2. Total after advance deduction
    currentValueAfterAdvance = currentWorksVal - advanceDeductionAmount;
    
    // 3. VAT on the after-advance amount
    vatAmount = currentValueAfterAdvance * (vatPercent / 100);
    
    // 4. Total including VAT
    currentValueWithVat = currentValueAfterAdvance + vatAmount;
    
    // 5. Retention Guarantee amount (e.g. 5% of current works as ضمان أعمال)
    retentionAmount = currentWorksVal * (retentionPercent / 100);
    
    // 6. Net payable for current invoice
    finalNetPayableCurrent = currentValueWithVat - retentionAmount - otherDeductions;
  } else {
    // Standard Cumulative Method
    retentionAmount = totalCompletedWorksVal * (retentionPercent / 100);
    advanceDeductionAmount = advanceDeduction;
    netCumulativeWorksValue = totalCompletedWorksVal - retentionAmount - advanceDeductionAmount - otherDeductions;
    currentNetDueBeforeVat = netCumulativeWorksValue - previousPayments;
    currentNetDuePositive = currentNetDueBeforeVat < 0 ? 0 : currentNetDueBeforeVat;
    vatAmount = currentNetDuePositive * (vatPercent / 100);
    finalNetPayableCurrent = currentNetDuePositive + vatAmount;
  }

  // Tafqeet wording
  const arabicWords = numberToArabicWords(Number(finalNetPayableCurrent.toFixed(2)));

  if (isPrintView) {
    return (
      <div className="w-full text-right font-sans" dir="rtl">
        {/* Primary Accounting Summary Grid */}
        <div className="grid grid-cols-2 border-r-2 border-b-2 border-l-2 border-black bg-white">
          {/* Left Cell: Signatures block */}
          <div className="p-4 border-l border-black flex flex-col justify-between">
            <h4 className="font-bold text-slate-800 text-xs border-b border-gray-200 pb-2 mb-4">التوقيعات والاعتمادات الرسمية للتنفيذ وصرف المستخلص:</h4>
            
            <div className="grid grid-cols-3 gap-2 text-center text-xs font-semibold mt-6">
              <div className="space-y-12">
                <p className="border-b border-dashed border-gray-400 pb-1 font-bold">مهندس التنفيذ / الموقع</p>
                <p className="text-[10px] text-slate-700">{certificate.siteEngineer || "م/ ...................."}</p>
                <p className="text-[9px] text-slate-400">التوقيع: .....................</p>
              </div>

              <div className="space-y-12 border-r border-gray-200 px-1">
                <p className="border-b border-dashed border-gray-400 pb-1 font-bold">المدير العام / الاستشاري</p>
                <p className="text-[10px] text-slate-700">{certificate.consultantEngineer || "المهندس الاستشاري"}</p>
                <p className="text-[9px] text-slate-400">التوقيع: .....................</p>
              </div>

              <div className="space-y-12 border-r border-gray-200 px-1">
                <p className="border-b border-dashed border-gray-400 pb-1 font-bold">المقـــاول</p>
                <p className="text-[10px] text-slate-700">{certificate.contractorRepresentative || "ممثل المقاول"}</p>
                <p className="text-[9px] text-slate-400">التوقيع: .....................</p>
              </div>
            </div>
            
            <div className="mt-8 border-t border-gray-200 pt-3 flex justify-between items-center text-[10px] text-slate-500">
              <span>تاريخ الطباعة: {new Date().toLocaleDateString("ar-SA")}</span>
              <span>مستخلص إلكتروني معتمد بنظام روعة الذكي</span>
            </div>
          </div>

          {/* Right Cell: Financial calculations exactly like the user's Excel model */}
          <div className="border-r border-black">
            <table className="w-full text-xs">
              <tbody>
                {isDirect ? (
                  <>
                    <tr className="border-b border-black">
                      <td className="p-2 bg-gray-50 border-l border-black font-bold w-1/2">إجمالي قيمة الأعمال المنفذة تراكمياً:</td>
                      <td className="p-2 font-black font-mono text-slate-900 text-left">{totalCompletedWorksVal.toLocaleString("en-US", {minimumFractionDigits: 2, maximumFractionDigits: 2})} ريال</td>
                    </tr>
                    <tr className="border-b border-black">
                      <td className="p-2 bg-gray-50 border-l border-black font-bold">نسبة الانجاز للمشروع بالكامل %:</td>
                      <td className="p-2 font-bold font-mono text-slate-900 text-left">
                        {certificate.contractValue > 0 ? ((totalCompletedWorksVal / certificate.contractValue) * 100).toFixed(2) : "0.00"}%
                      </td>
                    </tr>
                    {stageProgressPercent > 0 && (
                      <tr className="border-b border-black">
                        <td className="p-2 bg-gray-50 border-l border-black font-bold">نسبة الانجاز للمرحلة الأولى والثانية %:</td>
                        <td className="p-2 font-bold font-mono text-slate-900 text-left">{stageProgressPercent.toFixed(2)}%</td>
                      </tr>
                    )}
                    <tr className="border-b border-black">
                      <td className="p-2 bg-gray-50 border-l border-black font-bold">إجمالي قيمة الأعمال المنفذة سابقاً:</td>
                      <td className="p-2 font-bold font-mono text-slate-505 text-left">{previousCompletedWorksVal.toLocaleString("en-US", {minimumFractionDigits: 2, maximumFractionDigits: 2})} ريال</td>
                    </tr>
                    <tr className="border-b border-black bg-slate-50/50">
                      <td className="p-2 border-l border-black font-extrabold text-blue-900">إجمالي قيمة المستخلص الحالي:</td>
                      <td className="p-2 font-black font-mono text-blue-955 text-left bg-amber-50">{currentWorksVal.toLocaleString("en-US", {minimumFractionDigits: 2, maximumFractionDigits: 2})} ريال</td>
                    </tr>
                    <tr className="border-b border-black">
                      <td className="p-2 bg-gray-50 border-l border-black font-bold">خصم دفعة مقدمة ({advanceDeduction}%):</td>
                      <td className="p-2 font-bold font-mono text-red-700 text-left">-{advanceDeductionAmount.toLocaleString("en-US", {minimumFractionDigits: 2, maximumFractionDigits: 2})} ريال</td>
                    </tr>
                    <tr className="border-b border-black bg-slate-50/20">
                      <td className="p-2 border-l border-black font-bold text-slate-900">إجمالي المستخلص بعد خصم الدفعة المقدمة:</td>
                      <td className="p-2 font-bold font-mono text-slate-900 text-left">{currentValueAfterAdvance.toLocaleString("en-US", {minimumFractionDigits: 2, maximumFractionDigits: 2})} ريال</td>
                    </tr>
                    <tr className="border-b border-black">
                      <td className="p-2 bg-gray-50 border-l border-black font-bold">الضريبة VAT ({vatPercent}%):</td>
                      <td className="p-2 font-bold font-mono text-slate-900 text-left">+{vatAmount.toLocaleString("en-US", {minimumFractionDigits: 2, maximumFractionDigits: 2})} ريال</td>
                    </tr>
                    <tr className="border-b border-black">
                      <td className="p-2 bg-gray-50 border-l border-black font-bold">الإجمالي شامل الضريبة VAT:</td>
                      <td className="p-2 font-bold font-mono text-slate-900 text-left">{currentValueWithVat.toLocaleString("en-US", {minimumFractionDigits: 2, maximumFractionDigits: 2})} ريال</td>
                    </tr>
                    <tr className="border-b border-black">
                      <td className="p-2 bg-gray-50 border-l border-black font-bold">خصم ضمان الأعمال ({retentionPercent}%):</td>
                      <td className="p-2 font-bold font-mono text-red-700 text-left">-{retentionAmount.toLocaleString("en-US", {minimumFractionDigits: 2, maximumFractionDigits: 2})} ريال</td>
                    </tr>
                    {otherDeductions > 0 && (
                      <tr className="border-b border-black">
                        <td className="p-2 bg-gray-50 border-l border-black font-bold">خصومات أخرى:</td>
                        <td className="p-2 font-bold font-mono text-red-700 text-left">-{otherDeductions.toLocaleString("en-US", {minimumFractionDigits: 2, maximumFractionDigits: 2})} ريال</td>
                      </tr>
                    )}
                    <tr className="bg-slate-900 text-white font-extrabold leading-6">
                      <td className="p-2.5 border-l border-black text-sm">إجمالي مستخلص جاري {certificate.certificateNumber || "7"}:</td>
                      <td className="p-2.5 font-black font-mono text-left text-sm text-yellow-500">{finalNetPayableCurrent.toLocaleString("en-US", {minimumFractionDigits: 2, maximumFractionDigits: 2})} ريال سعودي</td>
                    </tr>
                  </>
                ) : (
                  <>
                    <tr className="border-b border-black">
                      <td className="p-2 bg-gray-50 border-l border-black font-bold w-1/2">إجمالي قيمة الأعمال المنفذة تراكمياً:</td>
                      <td className="p-2 font-black font-mono text-slate-900 text-left">{totalCompletedWorksVal.toLocaleString()} ريال</td>
                    </tr>
                    <tr className="border-b border-black">
                      <td className="p-2 bg-gray-50 border-l border-black font-bold">خصم توقيفات وضمان أعمال ({retentionPercent}%):</td>
                      <td className="p-2 font-bold font-mono text-red-700 text-left">-{retentionAmount.toLocaleString()} ريال</td>
                    </tr>
                    {advanceDeductionAmount > 0 && (
                      <tr className="border-b border-black">
                        <td className="p-2 bg-gray-50 border-l border-black font-bold">خصم استرداد دفعة مقدمة:</td>
                        <td className="p-2 font-bold font-mono text-red-700 text-left">-{advanceDeductionAmount.toLocaleString()} ريال</td>
                      </tr>
                    )}
                    {otherDeductions > 0 && (
                      <tr className="border-b border-black">
                        <td className="p-2 bg-gray-50 border-l border-black font-bold">خصومات وغرامات أخرى على المقاول:</td>
                        <td className="p-2 font-bold font-mono text-red-700 text-left">-{otherDeductions.toLocaleString()} ريال</td>
                      </tr>
                    )}
                    <tr className="border-b border-black bg-slate-50/50">
                      <td className="p-2 border-l border-black font-extrabold text-blue-900">صافي قيمة الأعمال المنفذة التراكمية:</td>
                      <td className="p-2 font-black font-mono text-blue-950 text-left">{netCumulativeWorksValue.toLocaleString()} ريال</td>
                    </tr>
                    <tr className="border-b border-black">
                      <td className="p-2 bg-gray-50 border-l border-black font-bold">ما تم صرفه للمقاول في دورات سابقة:</td>
                      <td className="p-2 font-bold font-mono text-slate-750 text-left">-{previousPayments.toLocaleString()} ريال</td>
                    </tr>
                    <tr className="border-b border-black bg-teal-50/[0.15]">
                      <td className="p-2 border-l border-black font-extrabold text-slate-950">صافي قيمة المستخلص الحالي (قبل الضريبة):</td>
                      <td className="p-2 font-black font-mono text-slate-950 text-left bg-amber-50">{currentNetDuePositive.toLocaleString()} ريال</td>
                    </tr>
                    <tr className="border-b border-black">
                      <td className="p-2 bg-gray-50 border-l border-black font-bold">ضريبة القيمة المضافة ({vatPercent}%):</td>
                      <td className="p-2 font-bold font-mono text-slate-900 text-left">+{vatAmount.toLocaleString()} ريال</td>
                    </tr>
                    <tr className="bg-slate-900 text-white font-extrabold leading-6">
                      <td className="p-2.5 border-l border-black text-sm">صافي قيمة المستخلص الحالي النهائي المستحق للصرف:</td>
                      <td className="p-2.5 font-black font-mono text-left text-sm text-yellow-500">{finalNetPayableCurrent.toLocaleString()} ريال سعودي</td>
                    </tr>
                  </>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Tafqeet block - Row spanning full width */}
        <div className="border-r-2 border-b-2 border-l-2 border-black p-3 bg-slate-100/90 font-extrabold text-sm text-center text-slate-950">
          المبلغ المستحق كتابةً: <span className="text-red-800 font-black">{arabicWords}</span>
        </div>
      </div>
    );
  }

  // Interactive Modern Form View for Dashboard
  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 text-right space-y-6" dir="rtl">
      {/* Visual Header */}
      <div className="flex items-center justify-between border-b border-slate-100 pb-4">
        <div>
          <h3 className="text-lg font-bold text-slate-900 flex items-center justify-end gap-2">
            <span>الملخص والالتزام المالي والمقاصات</span>
            <Landmark className="w-5 h-5 text-slate-600" />
          </h3>
          <p className="text-xs text-slate-500 mt-1">اضبط معدلات الخصم والدفعات السابقة والضرائب لتفقيط الفاتورة بنقرة واحدة</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column: Setup parameters inputs */}
        <div className="lg:col-span-1 space-y-4 border-l border-slate-100 lg:pl-6">
          <h4 className="text-xs font-bold text-slate-500 tracking-wider uppercase mb-3 text-right">محددات حسابات المقاصة والخصومات</h4>

          {/* Segmented control for calculation method */}
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/60 space-y-2">
            <span className="text-xs font-bold text-slate-700 block text-right">طريقة حساب المستخلص والخصومات:</span>
            <div className="grid grid-cols-2 gap-1.5 bg-slate-200/50 p-1 rounded-lg">
              <button
                type="button"
                onClick={() => handleChange("calculationMethod", "cumulative")}
                className={`py-1 rounded-md text-[11px] font-bold transition ${
                  !isDirect
                    ? "bg-slate-900 text-white shadow-xs"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                تراكمية عامة
              </button>
              <button
                type="button"
                onClick={() => handleChange("calculationMethod", "direct")}
                className={`py-1 rounded-md text-[11px] font-bold transition ${
                  isDirect
                    ? "bg-amber-600 text-white shadow-xs"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                مباشرة (المرفق)
              </button>
            </div>
            <p className="text-[10px] text-slate-400 text-right">
              {isDirect 
                ? "طريقة مستقرة تحسب التنزيلات والضمان مباشرة من قيمة المستخلص الجاري الحالي." 
                : "طريق تراكمية تعاقدية يتم تصفيتها تراكمياً وطرح المقبوض من الدفعات السابقة."}
            </p>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5 justify-end">
              <span>نسبة خصم التوقيفات وضمان الإنجاز (%)</span>
              <Percent className="w-3.5 h-3.5 text-slate-400" />
            </label>
            <input
              type="number"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-850 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white transition"
              value={certificate.retentionPercent}
              onChange={(e) => handleChange("retentionPercent", parseFloat(e.target.value) || 0)}
              min={0}
              max={100}
            />
            <span className="text-[10px] text-slate-400 block text-right mt-0.5">خصم ضمان الأعمال المستمر (عادةً 5% أو 10%)</span>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5 justify-end">
              <span>{isDirect ? "نسبة استرداد الدفعة المقدمة (%)" : "خصم استرداد دفعة مقدمة (ريال)"}</span>
              <Scale className="w-3.5 h-3.5 text-slate-400" />
            </label>
            <input
              type="number"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-850 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white transition"
              value={certificate.advanceDeduction}
              onChange={(e) => handleChange("advanceDeduction", parseFloat(e.target.value) || 0)}
              min={0}
            />
            <span className="text-[10px] text-slate-400 block text-right mt-0.5">
              {isDirect ? "مستقطعة مباشرة من قيمة الفاتورة الحالية" : "مبلغ مقطوع مخصوم تراكمياً"}
            </span>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5 justify-end">
              <span>نسبة إنجاز المرحلة الأولى والثانية (%)</span>
              <Percent className="w-3.5 h-3.5 text-slate-400" />
            </label>
            <input
              type="number"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-850 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white transition"
              value={certificate.stageProgressPercent || ""}
              onChange={(e) => handleChange("stageProgressPercent", parseFloat(e.target.value) || 0)}
              placeholder="مثال: 24.17"
              min={0}
              max={100}
              step="0.01"
            />
            <span className="text-[10px] text-slate-400 block text-right mt-0.5">مؤشر تقدير النسبة الجزئية لتوسعة المرفق جاري</span>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5 justify-end">
              <span>خصومات أخرى ومواد مستوردة من المالك (ريال)</span>
              <Scale className="w-3.5 h-3.5 text-slate-400" />
            </label>
            <input
              type="number"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-850 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white transition"
              value={certificate.otherDeductions}
              onChange={(e) => handleChange("otherDeductions", parseFloat(e.target.value) || 0)}
              min={0}
            />
          </div>

          {!isDirect && (
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5 justify-end">
                <span>ما تم صرفه سابقاً للمقاول (ريال)</span>
                <Coins className="w-3.5 h-3.5 text-slate-400" />
              </label>
              <input
                type="number"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-850 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white transition font-mono"
                placeholder="إجمالي مبالغ مستخلص رقم 1 و 2..."
                value={certificate.previousPayments}
                onChange={(e) => handleChange("previousPayments", parseFloat(e.target.value) || 0)}
                min={0}
              />
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5 justify-end">
              <span>نسبة ضريبة القيمة المضافة (%)</span>
              <Landmark className="w-3.5 h-3.5 text-slate-400" />
            </label>
            <input
              type="number"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-850 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white transition"
              value={certificate.vatPercent}
              onChange={(e) => handleChange("vatPercent", parseFloat(e.target.value) || 0)}
              min={0}
              max={100}
            />
          </div>
        </div>

        {/* Right column: Formative interactive invoice summing card */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 flex flex-col justify-between h-full">
            <div className="space-y-3.5">
              <h4 className="text-xs font-bold text-slate-500 tracking-wider uppercase text-right">ميزانية أعمال المستخلص الحالي بالتفصيل المالي:</h4>

              {isDirect ? (
                <>
                  <div className="flex justify-between items-center text-sm pb-2 border-b border-dashed border-slate-200">
                    <span className="font-mono text-slate-900 font-bold">{totalCompletedWorksVal.toLocaleString()} ريال</span>
                    <span className="text-slate-600 font-medium">1. إجمالي قيمة الأعمال المنفذة تراكمياً:</span>
                  </div>

                  <div className="flex justify-between items-center text-sm pb-2 border-b border-dashed border-slate-200">
                    <span className="font-mono text-slate-900 font-semibold">
                      {certificate.contractValue > 0 ? ((totalCompletedWorksVal / certificate.contractValue) * 100).toFixed(2) : "0.00"}%
                    </span>
                    <span className="text-slate-600 font-medium">2. نسبة الانجاز الإجمالية للمشروع:</span>
                  </div>

                  {stageProgressPercent > 0 && (
                    <div className="flex justify-between items-center text-sm pb-2 border-b border-dashed border-slate-200">
                      <span className="font-mono text-slate-900 font-semibold">{stageProgressPercent.toFixed(2)}%</span>
                      <span className="text-slate-600 font-medium">3. نسبة إنجاز المرحلة الأولى والثانية الكلية:</span>
                    </div>
                  )}

                  <div className="flex justify-between items-center text-sm pb-2 border-b border-dashed border-slate-200">
                    <span className="font-mono text-slate-700">-{previousCompletedWorksVal.toLocaleString()} ريال</span>
                    <span className="text-slate-650 font-medium">4. قيمة الأعمال المنفذة سابقاً المطروحة:</span>
                  </div>

                  <div className="flex justify-between items-center text-sm pb-1.5 border-b border-dashed border-slate-200 bg-amber-50 p-2 rounded-lg">
                    <span className="font-mono text-amber-950 font-extrabold">{currentWorksVal.toLocaleString()} ريال</span>
                    <span className="text-amber-900 font-bold">5. إجمالي قيمة المستخلص الحالي (قبل الخصم والضريبة):</span>
                  </div>

                  <div className="flex justify-between items-center text-sm pb-2 border-b border-dashed border-slate-200">
                    <span className="font-mono text-red-700 font-semibold">-{advanceDeductionAmount.toLocaleString()} ريال ({advanceDeduction}%)</span>
                    <span className="text-slate-600 font-medium">6. يخصم دفعة مقدمة مستقطعة من الجاري:</span>
                  </div>

                  <div className="flex justify-between items-center text-sm pb-2 border-b border-dashed border-slate-200 bg-slate-100 p-2 rounded-lg">
                    <span className="font-mono text-slate-800 font-bold">{currentValueAfterAdvance.toLocaleString()} ريال</span>
                    <span className="text-slate-700 font-bold">7. إجمالي المستخلص بعد خصم الدفعة المقدمة:</span>
                  </div>

                  <div className="flex justify-between items-center text-sm pb-2 border-b border-dashed border-slate-200">
                    <span className="font-mono text-slate-800">+{vatAmount.toLocaleString()} ريال ({vatPercent}%)</span>
                    <span className="text-slate-600">8. ضريبة القيمة المضافة للتنزيل الحالي:</span>
                  </div>

                  <div className="flex justify-between items-center text-sm pb-2 border-b border-dashed border-slate-200 bg-slate-100 p-2 rounded-lg">
                    <span className="font-mono text-slate-850 font-bold">{currentValueWithVat.toLocaleString()} ريال</span>
                    <span className="text-slate-700 font-bold">9. الإجمالي شامل الضريبة المضافة:</span>
                  </div>

                  <div className="flex justify-between items-center text-sm pb-2 border-b border-dashed border-slate-200 text-red-750">
                    <span className="font-mono font-semibold">-{retentionAmount.toLocaleString()} ريال ({retentionPercent}%)</span>
                    <span className="text-slate-600">10. يخصم ضمان الأعمال المستقطع من الجاري:</span>
                  </div>

                  {otherDeductions > 0 && (
                    <div className="flex justify-between items-center text-sm pb-2 border-b border-dashed border-slate-200">
                      <span className="font-mono text-red-700 font-semibold">-{otherDeductions.toLocaleString()} ريال</span>
                      <span className="text-slate-600 font-bold">11. يطرح خصومات وتنزيلات أخرى:</span>
                    </div>
                  )}

                  <div className="flex justify-between items-center p-3 rounded-xl bg-amber-600 text-white">
                    <span className="font-mono text-lg font-black text-yellow-300">{finalNetPayableCurrent.toLocaleString("en-US", {minimumFractionDigits: 2, maximumFractionDigits: 2})} ريال سعودي</span>
                    <span className="text-sm font-bold">إجمالي مستخلص جاري {certificate.certificateNumber || "7"}:</span>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex justify-between items-center text-sm pb-2 border-b border-dashed border-slate-200">
                    <span className="font-mono text-slate-900 font-bold">{totalCompletedWorksVal.toLocaleString()} ريال</span>
                    <span className="text-slate-600 font-medium">1. إجمالي قيمة الأعمال المنفذة تراكمياً:</span>
                  </div>

                  <div className="flex justify-between items-center text-sm pb-2 border-b border-dashed border-slate-200">
                    <span className="font-mono text-red-700 font-semibold">-{retentionAmount.toLocaleString()} ريال ({retentionPercent}%)</span>
                    <span className="text-slate-600 font-medium">2. يخصم توقيفات ضمان أعمال مستقطعة:</span>
                  </div>

                  {otherDeductions > 0 && (
                    <div className="flex justify-between items-center text-sm pb-2 border-b border-dashed border-slate-200">
                      <span className="font-mono text-red-700 font-semibold">-{otherDeductions.toLocaleString()} ريال</span>
                      <span className="text-slate-600 font-bold">3. يخصم تنزيلات وغرامات تصفية:</span>
                    </div>
                  )}

                  <div className="flex justify-between items-center text-sm pb-2 border-b border-dashed border-slate-200 bg-slate-100/50 p-2 rounded-lg">
                    <span className="font-mono text-blue-900 font-bold">{netCumulativeWorksValue.toLocaleString()} ريال</span>
                    <span className="text-slate-700 font-bold">4. صافي الأعمال المنفذة التراكمية المستحقة:</span>
                  </div>

                  <div className="flex justify-between items-center text-sm pb-2 border-b border-dashed border-slate-200">
                    <span className="font-mono text-slate-600">-{previousPayments.toLocaleString()} ريال</span>
                    <span className="text-slate-500">5. يطرح مبالغ مسددة بمستخلصات سابقة:</span>
                  </div>

                  <div className="flex justify-between items-center text-sm pb-2 border-b border-dashed border-slate-200 bg-teal-50 p-2 rounded-lg">
                    <span className="font-mono text-teal-950 font-extrabold">{currentNetDuePositive.toLocaleString()} ريال</span>
                    <span className="text-teal-905 font-extrabold">6. صافي مستحق المستخلص الحالي قبل الضريبة:</span>
                  </div>

                  <div className="flex justify-between items-center text-sm pb-2 border-b border-dashed border-slate-200">
                    <span className="font-mono text-slate-800">+{vatAmount.toLocaleString()} ريال ({vatPercent}%)</span>
                    <span className="text-slate-600">7. ضريبة القيمة المضافة لنسخة الصرف الحالي:</span>
                  </div>

                  <div className="flex justify-between items-center p-3 rounded-xl bg-slate-900 text-white">
                    <span className="font-mono text-lg font-black">{finalNetPayableCurrent.toLocaleString()} ريال سعودي</span>
                    <span className="text-sm font-bold">المستحق النهائي الصافي للصرف الحالي:</span>
                  </div>
                </>
              )}
            </div>

            {/* Tafqeet Arabic String display */}
            <div className="mt-4 p-3 bg-amber-50 border border-amber-100 rounded-xl text-center">
              <p className="text-[10px] text-amber-800 font-bold uppercase tracking-wider mb-1">تفقيط القيمة المالية بالحروف لتوقيع الشيك أو التحويل البنكي</p>
              <p className="text-xs font-black text-amber-900 pr-1">{arabicWords}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Signatures Fields Setup Inputs */}
      <div className="border-t border-slate-100 pt-5 space-y-4">
        <h4 className="text-xs font-bold text-slate-500 tracking-wider uppercase text-right flex items-center justify-end gap-1.5">
          <span>مسميات وتفاصيل المسؤولين عن الاعتمادات والتوقيعات</span>
          <FileSignature className="w-4 h-4 text-slate-400" />
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-1">
            <label className="text-[10px] text-slate-400 font-semibold">مهندس الموقع / مهندس التنفيذ</label>
            <input
              type="text"
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-300 focus:bg-white"
              value={certificate.siteEngineer}
              onChange={(e) => handleChange("siteEngineer", e.target.value)}
              placeholder="مثال: م. أحمد المطيري"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[10px] text-slate-400 font-semibold">المهندس الاستشاري المشرف (أو المدير العام)</label>
            <input
              type="text"
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-300 focus:bg-white"
              value={certificate.consultantEngineer}
              onChange={(e) => handleChange("consultantEngineer", e.target.value)}
              placeholder="مثال: م. فهد الاستشاري"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[10px] text-slate-400 font-semibold">المقاول / ممثل شركة المقاولات</label>
            <input
              type="text"
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-300 focus:bg-white"
              value={certificate.contractorRepresentative}
              onChange={(e) => handleChange("contractorRepresentative", e.target.value)}
              placeholder="مثال: م. فهد العتيبي (المدير الإنشائي)"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
