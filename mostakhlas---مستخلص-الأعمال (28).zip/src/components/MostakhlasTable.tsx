import React from "react";
import { WorkItem } from "../types";
import { Plus, Trash2, Library, Calculator } from "lucide-react";

interface MostakhlasTableProps {
  items: WorkItem[];
  onUpdateItems: (updatedItems: WorkItem[]) => void;
  isPrintView: boolean;
}

export const MostakhlasTable: React.FC<MostakhlasTableProps> = ({
  items,
  onUpdateItems,
  isPrintView,
}) => {
  const handleItemChange = (index: number, field: keyof WorkItem, value: any) => {
    const updated = [...items];
    updated[index] = { ...updated[index], [field]: value };
    onUpdateItems(updated);
  };

  const addNewItem = () => {
    const newItem: WorkItem = {
      id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      itemNumber: String(items.length + 1),
      description: "",
      unit: "متر مسطح",
      contractQty: 100,
      rate: 100,
      prevQty: 0,
      currQty: 10,
      notes: "",
    };
    onUpdateItems([...items, newItem]);
  };

  const deleteItem = (index: number) => {
    const updated = items.filter((_, i) => i !== index);
    // Auto re-number
    const renumbered = updated.map((item, idx) => ({
      ...item,
      itemNumber: String(idx + 1),
    }));
    onUpdateItems(renumbered);
  };

  const loadPredefinedDescription = (index: number, desc: string, rate: number, unit: string) => {
    const updated = [...items];
    updated[index] = {
      ...updated[index],
      description: desc,
      rate: rate,
      unit: unit,
    };
    onUpdateItems(updated);
  };

  // Predefined typical contractor items for smart autocomplete
  const standardSpecs = [
    { title: "أعمال الحفر والردم والرش والدك", rate: 45, unit: "متر مكعب" },
    { title: "خرسانة عادية مسبقة الصنع بمقاومة 250 كجم/سم2 أسفل القواعد أساسات", rate: 120, unit: "متر مسطح" },
    { title: "خرسانة مسلحة للقواعد والأساسات عيار 350 كجم/سم3 شاملة حديد التسليح", rate: 580, unit: "متر مكعب" },
    { title: "خرسانة مسلحة للأعمدة والجدران بمقاومة 350 كجم/سم2", rate: 750, unit: "متر مكعب" },
    { title: "خرسانة مسلحة للأسقف والأعتاب الشاملة للخرسانة الجاهزة وحديد سابك", rate: 680, unit: "متر مكعب" },
    { title: "أعمال مباني بلوك أسمنتي مفرغ معزول بسماكة 20 سم", rate: 80, unit: "متر مسطح" },
    { title: "أعمال بياض المحارة (اللياسة) الداخلية للجدران والأسقف سماكة 2 سم مع الشبك", rate: 35, unit: "متر مسطح" },
    { title: "أعمال توريد وتركيب بلاط بورسلان نخب أول قياس 60x60 سم للممرات والغرف", rate: 110, unit: "متر مسطح" },
    { title: "دهانات داخلية أساس ناعم ووجهين دهان بلاستيك نصف لمعة جوتن", rate: 25, unit: "متر مسطح" },
    { title: "تمديد وتأسيس مواسير التغذية والصرف الصحي والكهربائية المتكاملة بالمبنى", rate: 15100, unit: "مقطوعية" },
  ];

  // Calculations for sub-totals
  const totalCompletedValSum = items.reduce((sum, item) => {
    const totalQty = (parseFloat(String(item.prevQty)) || 0) + (parseFloat(String(item.currQty)) || 0);
    return sum + totalQty * (parseFloat(String(item.rate)) || 0);
  }, 0);

  const totalCurrentValSum = items.reduce((sum, item) => {
    return sum + (parseFloat(String(item.currQty)) || 0) * (parseFloat(String(item.rate)) || 0);
  }, 0);

  // Print Mode Rendering - Strict black borders, pure white tables matching formal Arabic accounting guidelines
  if (isPrintView) {
    return (
      <div className="w-full text-right" dir="rtl">
        <table className="w-full border-collapse border-2 border-black text-xs font-sans">
          <thead>
            <tr className="bg-gray-150 text-slate-900 border-b-2 border-black text-center font-bold">
              <th className="border border-black p-2 w-[4%]">البند</th>
              <th className="border border-black p-2 w-[35%]">بيان الأعمال المنفذة والمركبة</th>
              <th className="border border-black p-2 w-[8%]">الوحدة</th>
              <th className="border border-black p-2 w-[8%]">الكمية الإجمالية بالعقد</th>
              <th className="border border-black p-2 w-[8%]">الفئة (ريال)</th>
              <th className="border border-black p-2 w-[6%]">الكمية السابقة</th>
              <th className="border border-black p-2 w-[6%]">الكمية الحالية</th>
              <th className="border border-black p-2 w-[7%]">إجمالي المنفذ</th>
              <th className="border border-black p-2 w-[5%]">% الإنجاز</th>
              <th className="border border-black p-2 w-[9%]">الجملة التراكمية (ريال)</th>
              <th className="border border-black p-2 w-[8%]">قيمة الحالي (ريال)</th>
              <th className="border border-black p-2 w-[10%]">الموقع والملاحظات</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, idx) => {
              const contractQty = parseFloat(String(item.contractQty)) || 0;
              const rate = parseFloat(String(item.rate)) || 0;
              const prevQty = parseFloat(String(item.prevQty)) || 0;
              const currQty = parseFloat(String(item.currQty)) || 0;
              const totalQty = prevQty + currQty;
              const completionPercent = contractQty > 0 ? (totalQty / contractQty) * 100 : 0;
              const totalVal = totalQty * rate;
              const currVal = currQty * rate;

              return (
                <tr key={item.id} className="text-center font-medium hover:bg-slate-50 transition border-b border-black">
                  <td className="border border-black p-2 font-bold text-slate-900">{item.itemNumber}</td>
                  <td className="border border-black p-2 text-right leading-relaxed font-semibold text-slate-900">{item.description || "—"}</td>
                  <td className="border border-black p-2 text-slate-800">{item.unit || "—"}</td>
                  <td className="border border-black p-2 text-slate-900 font-mono">{contractQty.toLocaleString()}</td>
                  <td className="border border-black p-2 text-slate-900 font-bold font-mono">{rate.toLocaleString()}</td>
                  <td className="border border-black p-2 text-slate-700 font-mono">{prevQty > 0 ? prevQty.toLocaleString() : "—"}</td>
                  <td className="border border-black p-2 text-slate-900 font-bold font-mono">{currQty > 0 ? currQty.toLocaleString() : "—"}</td>
                  <td className="border border-black p-2 text-slate-900 font-bold font-mono">{totalQty > 0 ? totalQty.toLocaleString() : "—"}</td>
                  <td className="border border-black p-2 text-slate-800 font-mono">{Math.round(completionPercent)}%</td>
                  <td className="border border-black p-2 text-slate-900 font-extrabold font-mono">{totalVal > 0 ? totalVal.toLocaleString() : "-"}</td>
                  <td className="border border-black p-2 text-slate-900 font-extrabold font-mono bg-amber-50/40">{currVal > 0 ? currVal.toLocaleString() : "-"}</td>
                  <td className="border border-black p-2 text-slate-600 text-xs text-right whitespace-pre-wrap">{item.notes || "—"}</td>
                </tr>
              );
            })}
            
            {/* Table Sum total row */}
            <tr className="bg-slate-100 font-extrabold border-t-2 border-black">
              <td colSpan={9} className="border border-black p-2 text-left pl-4 font-bold text-sm bg-gray-100">أجمالــي قيمــة الأعمــال المنفذة حتى تاريخه:</td>
              <td className="border border-black p-2 text-center text-slate-950 text-sm font-mono">{totalCompletedValSum.toLocaleString()} ريال</td>
              <td className="border border-black p-2 text-center text-teal-950 text-sm font-mono bg-slate-200">{totalCurrentValSum.toLocaleString()} ريال</td>
              <td className="border border-black p-2 bg-gray-100"></td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }

  // Interactive Designer Excel Mode
  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 text-right space-y-6" dir="rtl">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-slate-100 pb-4 gap-4">
        <div>
          <h3 className="text-lg font-bold text-slate-900 flex items-center justify-end gap-2">
            <span>جدول حصر بنود الأعمال والكميات المنفذة</span>
            <Calculator className="w-5 h-5 text-slate-600" />
          </h3>
          <p className="text-xs text-slate-500 mt-1">أدخل الكميات السابقة والحالية ليقوم النظام بحساب كامل التدفقات المالية فوراً</p>
        </div>
        <button
          type="button"
          onClick={addNewItem}
          className="bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold px-4 py-2.5 flex items-center gap-1.5 self-start sm:self-center transition shadow-sm cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة بند عمل جديد</span>
        </button>
      </div>

      <div className="overflow-x-auto rounded-xl border border-slate-100">
        <table className="w-full text-right table-fixed min-w-[1200px]">
          <thead>
            <tr className="bg-slate-50 text-slate-700 text-xs font-bold border-b border-slate-100">
              <th className="p-3 w-[4%] text-center">بند</th>
              <th className="p-3 w-[26%]">بيان الأعمال المنفذة بالتفصيل</th>
              <th className="p-3 w-[10%]">الوحدة</th>
              <th className="p-3 w-[10%] text-center">الكمية بالعقد</th>
              <th className="p-3 w-[10%] text-center">سعر الوحدة (الفئة)</th>
              <th className="p-3 w-[9%] text-center">الكمية السابقة</th>
              <th className="p-3 w-[9%] text-center">الكمية الحالية</th>
              <th className="p-3 w-[10%] text-center">إجمالي وقيمة الحالي</th>
              <th className="p-3 w-[14%]">ملاحظات البند / الموقع</th>
              <th className="p-3 w-[4%] text-center">إجراء</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50 text-sm">
            {items.map((item, idx) => {
              const contractQty = parseFloat(String(item.contractQty)) || 0;
              const rate = parseFloat(String(item.rate)) || 0;
              const prevQty = parseFloat(String(item.prevQty)) || 0;
              const currQty = parseFloat(String(item.currQty)) || 0;
              const totalQty = prevQty + currQty;
              const itemTotalVal = totalQty * rate;
              const itemCurrVal = currQty * rate;

              return (
                <tr key={item.id} className="hover:bg-slate-50/50 transition">
                  {/* Item Index */}
                  <td className="p-3 text-center font-bold text-slate-800 bg-slate-50/30">
                    {item.itemNumber}
                  </td>

                  {/* Description Input & helper */}
                  <td className="p-3 space-y-2">
                    <textarea
                      rows={2}
                      className="w-full bg-slate-50 border border-slate-100 rounded-lg p-2 text-xs text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-300 focus:bg-white transition"
                      placeholder="صف العمل المنجز للفوترة والتسليح والصب..."
                      value={item.description}
                      onChange={(e) => handleItemChange(idx, "description", e.target.value)}
                    />
                    <div className="flex flex-wrap gap-1 items-center justify-end">
                      <span className="text-[10px] text-slate-400 font-semibold flex items-center gap-0.5 ml-2">
                        <Library className="w-3 h-3" /> نماذج وصف جاهزة:
                      </span>
                      {standardSpecs.slice(0, 3).map((spec, sIdx) => (
                        <button
                          key={sIdx}
                          type="button"
                          onClick={() => loadPredefinedDescription(idx, spec.title, spec.rate, spec.unit)}
                          className="bg-slate-100/80 hover:bg-slate-200 text-slate-600 text-[10px] px-2 py-0.5 rounded transition cursor-pointer"
                        >
                          {spec.title.substring(0, 15)}...
                        </button>
                      ))}
                    </div>
                  </td>

                  {/* Unit dropdown */}
                  <td className="p-3">
                    <select
                      className="w-full bg-slate-50 border border-slate-100 rounded-lg px-2 py-1.5 text-xs text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-300 focus:bg-white transition"
                      value={item.unit}
                      onChange={(e) => handleItemChange(idx, "unit", e.target.value)}
                    >
                      <option value="متر مسطح">متر مسطح (م²)</option>
                      <option value="متر مكعب">متر مكعب (م³)</option>
                      <option value="متر طولي">متر طولي (م.ط)</option>
                      <option value="مقطوعية">مقطوعية (جملة)</option>
                      <option value="طن">طن</option>
                      <option value="عدد">عدد (حبة)</option>
                      <option value="كيلو جرام">كيلو جرام</option>
                    </select>
                  </td>

                  {/* Contract Quantity */}
                  <td className="p-3">
                    <input
                      type="number"
                      className="w-full bg-slate-50 border border-slate-100 rounded-lg px-2 py-1.5 text-xs text-slate-800 text-center font-mono focus:outline-none focus:ring-1 focus:ring-slate-300 focus:bg-white transition"
                      value={item.contractQty}
                      onChange={(e) => handleItemChange(idx, "contractQty", parseFloat(e.target.value) || 0)}
                    />
                  </td>

                  {/* Rate / price per unit */}
                  <td className="p-3">
                    <input
                      type="number"
                      className="w-full bg-slate-50 border border-slate-100 rounded-lg px-2 py-1.5 text-xs font-bold text-teal-800 text-center font-mono focus:outline-none focus:ring-1 focus:ring-slate-300 focus:bg-white transition"
                      value={item.rate}
                      onChange={(e) => handleItemChange(idx, "rate", parseFloat(e.target.value) || 0)}
                    />
                  </td>

                  {/* Previous Quantity */}
                  <td className="p-3">
                    <input
                      type="number"
                      className="w-full bg-slate-50 border border-slate-100 rounded-lg px-2 py-1.5 text-xs text-slate-600 text-center font-mono focus:outline-none focus:ring-1 focus:ring-slate-300 focus:bg-white transition"
                      value={item.prevQty}
                      onChange={(e) => handleItemChange(idx, "prevQty", parseFloat(e.target.value) || 0)}
                    />
                  </td>

                  {/* Current Quantity */}
                  <td className="p-3 bg-amber-50/20">
                    <input
                      type="number"
                      className="w-full bg-amber-100/50 border border-amber-200 rounded-lg px-2 py-1.5 text-xs font-bold text-slate-900 text-center font-mono focus:outline-none focus:ring-1 focus:ring-amber-300 focus:bg-white transition"
                      value={item.currQty}
                      onChange={(e) => handleItemChange(idx, "currQty", parseFloat(e.target.value) || 0)}
                    />
                  </td>

                  {/* Realtime Outputs */}
                  <td className="p-3 text-right space-y-1 bg-slate-50/20">
                    <div className="text-[11px] text-slate-700">
                      إجمالي المنفذ: <span className="font-mono font-bold text-slate-950">{totalQty.toLocaleString()}</span> {item.unit}
                    </div>
                    <div className="text-[10px] text-slate-500 border-b border-dashed border-slate-100 pb-1">
                      نسبة المسلم: <span className="font-mono">{contractQty > 0 ? Math.round((totalQty / contractQty) * 100) : 0}%</span>
                    </div>
                    <div className="text-xs font-bold text-slate-900">
                      الجملة: <span className="font-mono text-slate-950">{itemTotalVal.toLocaleString()} ريال</span>
                    </div>
                    <div className="text-[11px] text-teal-800 font-semibold bg-teal-50/50 px-1 py-0.5 rounded text-center">
                      قيمي للحالي: <span className="font-mono">{itemCurrVal.toLocaleString()} ريال</span>
                    </div>
                  </td>

                  {/* Notes / specific site details */}
                  <td className="p-3">
                    <textarea
                      rows={2}
                      className="w-full bg-slate-50 border border-slate-100 rounded-lg p-2 text-xs text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-300 focus:bg-white transition"
                      placeholder="مثال: الواجهة الشرقية / معطل جزئياً..."
                      value={item.notes}
                      onChange={(e) => handleItemChange(idx, "notes", e.target.value)}
                    />
                  </td>

                  {/* Delete trigger */}
                  <td className="p-3 text-center">
                    <button
                      type="button"
                      onClick={() => deleteItem(idx)}
                      title="حذف هذا البند"
                      className="p-1.5 text-rose-500 hover:text-white hover:bg-rose-500 border border-rose-100 hover:border-transparent rounded-lg transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {items.length === 0 && (
        <div className="p-12 text-center text-slate-400 border-2 border-dashed border-slate-100 rounded-xl">
          <Calculator className="w-10 h-10 mx-auto text-slate-300 mb-2" />
          <p className="text-sm font-semibold">لا توجد بنود أعمال مضافة حالياً</p>
          <p className="text-xs text-slate-400 mt-1">انقر على زر "إضافة بند عمل جديد" لتبدأ بتعبئة الحصر الخاص بالمشروع</p>
        </div>
      )}

      {/* Direct inline aggregates preview */}
      {items.length > 0 && (
        <div className="bg-slate-50/80 p-4 rounded-xl flex flex-col md:flex-row justify-between items-center border border-slate-100 gap-3 text-xs">
          <div className="text-slate-600">
            عدد البنود الإجمالي بالجدول: <span className="font-bold text-slate-900 font-mono">{items.length} بنود</span>
          </div>
          <div className="flex gap-4">
            <div className="text-right">
              <span className="text-slate-500">مجموع الجملة التراكمي: </span>
              <span className="font-extrabold text-slate-900 font-mono text-sm">{totalCompletedValSum.toLocaleString()} ر.س</span>
            </div>
            <div className="text-right border-r border-slate-200 pr-4">
              <span className="text-teal-700">مجموع المستخلص الحالي: </span>
              <span className="font-extrabold text-teal-850 font-mono text-sm">{totalCurrentValSum.toLocaleString()} ر.س</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
