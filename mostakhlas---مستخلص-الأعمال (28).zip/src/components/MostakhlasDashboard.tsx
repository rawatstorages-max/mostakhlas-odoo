import React, { useState } from "react";
import { Certificate, WorkItem } from "../types";
import { 
  TrendingUp, 
  DollarSign, 
  ShieldAlert, 
  Layers, 
  FileCheck, 
  Clock, 
  PieChart, 
  Activity, 
  ArrowLeft, 
  Award, 
  Gauge,
  Briefcase,
  AlertTriangle,
  FileSpreadsheet
} from "lucide-react";

interface MostakhlasDashboardProps {
  certificates: Certificate[];
  onSelectCertificate: (id: string) => void;
  onClose: () => void;
}

export const MostakhlasDashboard: React.FC<MostakhlasDashboardProps> = ({
  certificates,
  onSelectCertificate,
  onClose,
}) => {
  const [selectedCertId, setSelectedCertId] = useState<string>(
    certificates[0]?.id || ""
  );

  // 1. Calculate general statistics across ALL certificates
  const totalCertificatesCount = certificates.length;
  
  // Aggregate totals
  const totalContractValue = certificates.reduce((sum, c) => sum + (c.contractValue || 0), 0);
  
  // Completed so far values across all certs
  const totalCompletedValue = certificates.reduce((sum, c) => {
    // Current total of work done up to this certificate
    const completedItemsValue = c.items.reduce((itemSum, item) => {
      const totalQty = item.prevQty + item.currQty;
      return itemSum + (totalQty * item.rate);
    }, 0);
    return sum + completedItemsValue;
  }, 0);

  // Aggregated Net Payments
  const totalNetDue = certificates.reduce((sum, c) => {
    const completedItemsValue = c.items.reduce((itemSum, item) => {
      const totalQty = item.prevQty + item.currQty;
      return itemSum + (totalQty * item.rate);
    }, 0);
    
    const vatAmount = (completedItemsValue * (c.vatPercent || 15)) / 100;
    const totalWithVat = completedItemsValue + vatAmount;
    
    // Deductions
    const retentionAmount = (completedItemsValue * (c.retentionPercent || 10)) / 100;
    const advanceDed = c.advanceDeduction || 0;
    const otherDed = c.otherDeductions || 0;
    
    const totalDeductions = retentionAmount + advanceDed + otherDed;
    const netPaid = totalWithVat - totalDeductions - (c.previousPayments || 0);

    return sum + (netPaid > 0 ? netPaid : 0);
  }, 0);

  // Count active delaying certificates
  const delayedCertsCount = certificates.filter(c => c.isDelayAlertActive).length;
  const totalPenaltySum = certificates.reduce((sum, c) => {
    if (c.isDelayAlertActive) {
      return sum + ((c.delayDaysOfProject || 0) * (c.delayPenaltyPerDayRate || 0));
    }
    return sum;
  }, 0);

  // 2. Specific filter stats for the selected certificate
  const activeCert = certificates.find(c => c.id === selectedCertId) || certificates[0];

  const getCertStats = (cert: Certificate) => {
    if (!cert) return { completed: 0, contract: 0, percent: 0, itemsCount: 0, net: 0 };
    
    const contract = cert.contractValue || 1;
    const completedVal = cert.items.reduce((sum, item) => {
      const totalQty = item.prevQty + item.currQty;
      return sum + (totalQty * item.rate);
    }, 0);
    const percent = Math.min((completedVal / contract) * 100, 100);

    const vatAmount = (completedVal * (cert.vatPercent || 15)) / 100;
    const totalWithVat = completedVal + vatAmount;
    const retentionAmount = (completedVal * (cert.retentionPercent || 10)) / 100;
    const totalDeductions = retentionAmount + (cert.advanceDeduction || 0) + (cert.otherDeductions || 0);
    const net = Math.max(totalWithVat - totalDeductions - (cert.previousPayments || 0), 0);

    return {
      completed: completedVal,
      contract: cert.contractValue,
      percent,
      itemsCount: cert.items.length,
      net
    };
  };

  const activeStats = getCertStats(activeCert);

  return (
    <div className="bg-slate-900 text-slate-100 min-h-screen p-4 sm:p-8 rounded-3xl mt-2 relative overflow-hidden" dir="rtl">
      {/* Background visual details */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Sticky top dashboard controller */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-slate-800 pb-6 mb-8 relative z-10">
        <div>
          <div className="flex items-center gap-3">
            <span className="p-2.5 bg-rose-500/10 rounded-2xl border border-rose-500/20 text-rose-500">
              <Activity className="w-6 h-6 animate-pulse" />
            </span>
            <div>
              <h2 className="text-2xl font-black tracking-tight text-white">لوحة القيادة والمؤشرات التفاعلية المباشرة</h2>
              <p className="text-xs text-slate-400 mt-1">تحليل مالي وهندسي ذكي لجميع مستخلصات شركة روعة عالم التصميم للمقاولات</p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <button
            onClick={onClose}
            className="w-full sm:w-auto bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs sm:text-sm px-5 py-3 rounded-2xl border border-slate-700 transition flex items-center justify-center gap-2 cursor-pointer shadow-lg hover:translate-x-1"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>العودة لإدارة المستخلصات</span>
          </button>
        </div>
      </div>

      {/* Section 1: Aggregate KPIs Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-8 relative z-10">
        {/* KPI 1 - Total projects value */}
        <div className="bg-slate-850 border border-slate-800 p-6 rounded-2xl shadow-md relative group hover:border-slate-700 transition duration-150">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400">إجمالي قيم المشاريع المتعاقد عليها</span>
            <span className="p-2 bg-blue-500/10 rounded-xl border border-blue-500/15 text-blue-400">
              <Briefcase className="w-5 h-5" />
            </span>
          </div>
          <div className="mt-4">
            <span className="text-2xl font-black font-mono text-white">{(totalContractValue).toLocaleString()}</span>
            <span className="text-xs text-slate-400 mr-1">ريال سعودي</span>
          </div>
          <p className="text-[10px] text-slate-400 mt-2 flex items-center gap-1">
            <span className="text-emerald-400 font-bold">● نشطة بالكامل</span>
            <span>- لعدد {totalCertificatesCount} مستخلصات معتمدة</span>
          </p>
        </div>

        {/* KPI 2 - Total execution done */}
        <div className="bg-slate-850 border border-slate-800 p-6 rounded-2xl shadow-md relative group hover:border-slate-700 transition duration-150">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400">إجمالي قيمة الأعمال الفنية المنجزة</span>
            <span className="p-2 bg-emerald-500/10 rounded-xl border border-emerald-500/15 text-emerald-400">
              <TrendingUp className="w-5 h-5" />
            </span>
          </div>
          <div className="mt-4">
            <span className="text-2xl font-black font-mono text-emerald-400">{(totalCompletedValue).toLocaleString()}</span>
            <span className="text-xs text-slate-400 mr-1">ريال</span>
          </div>
          <div className="mt-2 flex items-center gap-2">
            {/* Visual percent progress bar */}
            <div className="flex-1 bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div 
                className="bg-emerald-500 h-full rounded-full" 
                style={{ width: `${Math.min((totalCompletedValue / (totalContractValue || 1)) * 100, 100)}%` }}
              />
            </div>
            <span className="text-xs font-mono font-bold text-emerald-400">
              {Math.round((totalCompletedValue / (totalContractValue || 1)) * 100)}%
            </span>
          </div>
        </div>

        {/* KPI 3 - Total Net due to contractor */}
        <div className="bg-slate-850 border border-slate-800 p-6 rounded-2xl shadow-md relative group hover:border-slate-700 transition duration-150">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400">إجمالي مستحقات الدفع الصافية</span>
            <span className="p-2 bg-indigo-500/10 rounded-xl border border-indigo-500/15 text-indigo-400">
              <DollarSign className="w-5 h-5" />
            </span>
          </div>
          <div className="mt-4">
            <span className="text-2xl font-black font-mono text-indigo-400">{(totalNetDue).toLocaleString()}</span>
            <span className="text-xs text-slate-400 mr-1">ريال</span>
          </div>
          <p className="text-[10px] text-slate-400 mt-2">
            صافي المستحق للمقاول بعد تطبيق ضريبة القيمة المضافة وحجز الضمانات
          </p>
        </div>

        {/* KPI 4 - Total fines or delayed */}
        <div className="bg-slate-850 border border-slate-800 p-6 rounded-2xl shadow-md relative group hover:border-slate-700 transition duration-150">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400">غرامات التأخير والموثوقية</span>
            <span className="p-2 bg-rose-500/10 rounded-xl border border-rose-500/15 text-rose-400">
              <ShieldAlert className="w-5 h-5" />
            </span>
          </div>
          <div className="mt-4">
            <span className="text-2xl font-black font-mono text-rose-500">{(totalPenaltySum).toLocaleString()}</span>
            <span className="text-xs text-slate-400 mr-1">ريال</span>
          </div>
          <p className="text-[10px] text-slate-400 mt-2 flex items-center gap-1.5">
            <span className="text-rose-400 font-bold">🚨 {delayedCertsCount} مشاريع متأخرة</span>
            <span>بإجمالي الخصومات اليومية</span>
          </p>
        </div>
      </div>

      {/* Section 2: Detailed Interactive Selection & Live Chart analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 relative z-10">
        {/* Right column: Selection list & quick progress gauges */}
        <div className="bg-slate-850 border border-slate-800 rounded-2xl p-5 space-y-4">
          <h3 className="text-sm font-extrabold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
            <Layers className="w-4 h-4 text-rose-500" />
            <span>اختر المستخلص لعرض تحليله المفصل</span>
          </h3>

          <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
            {certificates.map((c) => {
              const active = c.id === selectedCertId;
              const stats = getCertStats(c);
              return (
                <button
                  key={c.id}
                  onClick={() => setSelectedCertId(c.id)}
                  className={`w-full text-right p-3.5 rounded-xl border text-xs transition duration-150 relative ${
                    active 
                      ? "bg-gradient-to-l from-rose-500/20 to-slate-800 border-rose-500 text-white" 
                      : "bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-350"
                  }`}
                >
                  <div className="flex items-center justify-between font-bold">
                    <span className="max-w-[70%] truncate text-sm">{c.title}</span>
                    <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 font-mono text-[10px]">
                      {c.certificateNumber}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2">
                    <span>قيمة الإنجاز: <strong className="text-emerald-400 font-mono">{(stats.completed).toLocaleString()}</strong></span>
                    <span className="font-mono">{Math.round(stats.percent)}%</span>
                  </div>

                  {/* Tiny progress status bar */}
                  <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden mt-1.5">
                    <div 
                      className={`h-full ${active ? "bg-rose-500" : "bg-emerald-500"}`} 
                      style={{ width: `${stats.percent}%` }}
                    />
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Center column: Dashboard dynamic visuals and stats container */}
        <div className="bg-slate-850 border border-slate-800 rounded-2xl p-6 lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">تحليل المشروع النشط</span>
              <h3 className="text-lg font-black text-white mt-1">
                {activeCert?.title || "لا يوجد مشروع محدد"}
              </h3>
            </div>
            <button
              onClick={() => onSelectCertificate(activeCert.id)}
              className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition cursor-pointer flex items-center gap-1 shadow-md hover:translate-y-[-1px]"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>عرض جدول الكميات والأسعار</span>
            </button>
          </div>

          {/* Quick Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl text-center">
              <span className="block text-[10px] text-slate-400 font-bold">قيمة العقد الأصلية</span>
              <span className="font-mono font-bold text-sm text-slate-200 block mt-1">
                {(activeStats.contract).toLocaleString()} ريال
              </span>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl text-center">
              <span className="block text-[10px] text-slate-400 font-bold">قيمة الإنجاز الفعلي</span>
              <span className="font-mono font-bold text-sm text-emerald-400 block mt-1">
                {(activeStats.completed).toLocaleString()} ريال
              </span>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl text-center">
              <span className="block text-[10px] text-slate-400 font-bold">صافي الدفعة المستحقة</span>
              <span className="font-mono font-bold text-sm text-indigo-400 block mt-1">
                {(activeStats.net).toLocaleString()} ريال
              </span>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl text-center">
              <span className="block text-[10px] text-slate-400 font-bold">عدد البنود الفنية</span>
              <span className="font-mono font-bold text-sm text-blue-400 block mt-1">
                {activeStats.itemsCount} بند مستقل
              </span>
            </div>
          </div>

          {/* Detailed SVG Gauge layout for completion rate */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center bg-slate-900/45 p-6 rounded-2xl border border-slate-800/85">
            {/* Left: Dynamic interactive circular SVG gauge */}
            <div className="flex flex-col items-center justify-center text-center space-y-2">
              <div className="relative w-36 h-36 flex items-center justify-center">
                {/* SVG Radial Gauge */}
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  {/* Gray background track */}
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    fill="transparent"
                    stroke="#1e293b"
                    strokeWidth="8"
                  />
                  {/* Colorful completion path */}
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    fill="transparent"
                    stroke="url(#roseGradient)"
                    strokeWidth="8"
                    strokeDasharray="251.2"
                    strokeDashoffset={251.2 - (251.2 * activeStats.percent) / 100}
                    strokeLinecap="round"
                    className="transition-all duration-1000 ease-out"
                  />
                  {/* Gradients declaration */}
                  <defs>
                    <linearGradient id="roseGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#ef4444" />
                      <stop offset="100%" stopColor="#f43f5e" />
                    </linearGradient>
                  </defs>
                </svg>
                {/* Center Value */}
                <div className="absolute flex flex-col items-center justify-center">
                  <span className="text-2xl font-black font-mono text-white">
                    {Math.round(activeStats.percent)}%
                  </span>
                  <span className="text-[10px] text-slate-400 font-bold">نسبة الإنجاز</span>
                </div>
              </div>
              <div>
                <p className="text-xs text-slate-350 font-bold">مؤشر أداء عقد المشروع</p>
                <p className="text-[10px] text-slate-400 mt-0.5">مقارنة الإنجاز الفعلي مقابل الموازنة التعاقدية الكلية</p>
              </div>
            </div>

            {/* Right: Technical work progress checklist summary */}
            <div className="space-y-3">
              <h4 className="text-xs font-black text-rose-400 border-b border-slate-800 pb-1.5 flex items-center justify-end gap-1.5">
                <span>التحليل الفني للكميات بالمحضر الجاري</span>
                <PieChart className="w-3.5 h-3.5" />
              </h4>

              <div className="space-y-2">
                {/* Done progress item */}
                <div className="bg-slate-850 p-2.5 rounded-lg border border-slate-800 text-[11px] flex justify-between items-center animate-fade-in">
                  <span className="text-emerald-400 font-bold flex items-center gap-1">
                    <FileCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>أعمال منجزة بنسبة 100%</span>
                  </span>
                  <span className="font-mono text-slate-200">
                    {activeCert.items.filter(i => (i.prevQty + i.currQty) >= i.contractQty).length} بنود
                  </span>
                </div>

                {/* Partially done progress item */}
                <div className="bg-slate-850 p-2.5 rounded-lg border border-slate-800 text-[11px] flex justify-between items-center">
                  <span className="text-amber-400 font-bold flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-amber-400" />
                    <span>تحت التنفيذ وجاري إكمالها</span>
                  </span>
                  <span className="font-mono text-slate-200">
                    {activeCert.items.filter(i => {
                      const totalQty = i.prevQty + i.currQty;
                      return totalQty > 0 && totalQty < i.contractQty;
                    }).length} بنود
                  </span>
                </div>

                {/* Not started progress item */}
                <div className="bg-slate-850 p-2.5 rounded-lg border border-slate-800 text-[11px] flex justify-between items-center">
                  <span className="text-slate-400 font-bold flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 text-slate-400" />
                    <span>بنود لم تبدأ أعمالها الفنية بعد</span>
                  </span>
                  <span className="font-mono text-slate-200">
                    {activeCert.items.filter(i => (i.prevQty + i.currQty) === 0).length} بنود
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Delay warnings helper indicator inside dashboard */}
          {activeCert.isDelayAlertActive && (
            <div className="p-4 bg-rose-950/25 border border-rose-550/20 rounded-xl flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
              <div className="text-xs leading-relaxed text-right">
                <p className="font-extrabold text-rose-300">🚨 تنبيه تأخير فني معتمد على هذا المشروع:</p>
                <p className="text-slate-300 mt-1">
                  المشروع تجاوز المدد المخططة بمقدار <span className="font-black text-rose-400 font-mono">{(activeCert.delayDaysOfProject ?? 0)}</span> يوم. 
                  إجمالي الغرامة المحتسبة هي <span className="font-black text-rose-400 font-mono">{((activeCert.delayDaysOfProject ?? 0) * (activeCert.delayPenaltyPerDayRate ?? 0)).toLocaleString()}</span> ريال سعودي.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
