import React, { useState } from "react";
import { Sparkles, X, Check, Copy, Terminal, FileCode, CheckCircle, HelpCircle, BookOpen } from "lucide-react";

interface OdooModalProps {
  onClose: () => void;
}

export function OdooModal({ onClose }: OdooModalProps) {
  const [activeTab, setActiveTab] = useState<"manifest" | "model" | "view" | "security" | "report">("model");
  const [copiedFile, setCopiedFile] = useState<string | null>(null);

  const fileContents = {
    manifest: `# -*- coding: utf-8 -*-
{
    'name': 'Rawat Mostakhlas Billing (Odoo 19)',
    'version': '1.0',
    'summary': 'ادارة مستخلصات المقاولين والأعمال الإنشائية بالتسوية التراكمية والمباشرة',
    'description': """
مستخلصات المقاولين الذكية - شركة روعة عالم التصميم
===================================================
هذا المديول يضيف نظام إدارة مستخلصات المقاولين الكامل لنسخة أودو 19:
* تسجيل وحساب بنود مستخلصات جاري (سواء الطريقة التراكمية أو المباشرة جاري 7).
* خصم الدفع المقدمة المباشرة وضمان الأعمال (توقيفات الإنجاز) من المستخلص.
* حساب ضريبة القيمة المضافة ومستحقات المقاولين بشكل آلي.
* توليد مستند طباعة عربي رسمي معتمد (تقرير QWeb).
""",
    'author': 'Rawat Smart Contracting & AI Studio',
    'category': 'Project/Accounting',
    'depends': ['base', 'account', 'project'],
    'data': [
        'security/ir.model.access.csv',
        'views/mostakhlas_views.xml',
        'report/mostakhlas_report_templates.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
    'license': 'LGPL-3',
}`,
    model: `# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

class MostakhlasCertificate(models.Model):
    _name = 'mostakhlas.certificate'
    _description = 'Contractor Mostakhlas Certificate (المستخلص المالي)'
    _order = 'date desc, id desc'

    name = fields.Char(string='رقم المستخلص المرجعي', required=True, copy=False, default=lambda self: _('مستخلص جديد'))
    title = fields.Char(string='عنوان المستخلص', required=True, default='مستخلص جاري رقم 7')
    certificate_number = fields.Char(string='رقم المستخلص', required=True, default='م-7')
    date = fields.Date(string='تاريخ المستخلص', default=fields.Date.today, required=True)
    contractor_id = fields.Many2one('res.partner', string='المقاول المنفذ (الطرف الثاني)', required=True, domain=[('is_company', '=', True)])
    project_id = fields.Many2one('project.project', string='المشروع الإنشائي المربوط')
    project_name_custom = fields.Char(string='اسم المشروع (يدوي)')
    client_name = fields.Char(string='اسم المالك (الطرف الأول)', default='مجموعة روعة القابضة')
    contract_value = fields.Float(string='القيمة الإجمالية للعقد (ريال)', default=115682208.0)
    
    calculation_method = fields.Selection([
        ('cumulative', 'تراكمية تعاقدية عامة'),
        ('direct', 'طريقة جاري 7 المباشرة (المرفق)')
    ], string='طريقة تصفية الحساب', default='direct', required=True)
    
    retention_percent = fields.Float(string='نسبة خصم ضمان الأعمال %', default=5.0)
    advance_deduction_percent = fields.Float(string='نسبة استرداد الدفعة المقدمة %', default=5.0)
    vat_percent = fields.Float(string='نسبة ضريبة القيمة المضافة %', default=15.0)
    previous_payments = fields.Float(string='ما تم صرفه للمقاول سابقاً (ريال)', default=17599007.55)
    stage_progress_percent = fields.Float(string='نسبة إنجاز المرحلة الأولى والثانية %', default=24.17)
    
    items_ids = fields.One2many('mostakhlas.certificate.line', 'certificate_id', string='بنود الأعمال والكميات المنفذة')
    
    total_completed_works_val = fields.Float(string='إيجاز الأعمال الإجمالي التراكمي', compute='_compute_totals', store=True)
    previous_completed_works_val = fields.Float(string='إجمالي قيمة المنفذ سابقاً', compute='_compute_totals', store=True)
    current_works_val = fields.Float(string='إمر الصرف الحالي (قبل الخصم)', compute='_compute_totals', store=True)
    
    advance_deduction_amount = fields.Float(string='خصم الدفعة المقدمة', compute='_compute_totals', store=True)
    current_value_after_advance = fields.Float(string='المستخلص بعد خصم الدفعة المقدمة', compute='_compute_totals', store=True)
    vat_amount = fields.Float(string='الضريبة القيمة المضافة VAT', compute='_compute_totals', store=True)
    current_value_with_vat = fields.Float(string='الإجمالي شامل الضريبة المضافة', compute='_compute_totals', store=True)
    retention_amount = fields.Float(string='خصم ضمان الأعمال المستقطع', compute='_compute_totals', store=True)
    other_deductions = fields.Float(string='خصومات وغرامات أخرى', default=0.0)
    final_net_payable = fields.Float(string='صافي مستخلص جاري النهائي (ريال)', compute='_compute_totals', store=True)
    
    site_engineer = fields.Char(string='مهندس الموقع المشرف', default='م. محمد الحربي (مهندس التنفيذ)')
    consultant_engineer = fields.Char(string='المهندس الاستشاري / المدير العام')
    contractor_representative = fields.Char(string='ممثل المقاول المعتمد')
    state = fields.Selection([
        ('draft', 'مسودة المستخلص'),
        ('under_review', 'تحت الفحص ومراجعة الاستشاري'),
        ('approved', 'تم الاعتماد النهائي والمطابقة'),
        ('paid', 'تم التحويل البنكي والصرف')
    ], string='الحالة الإجرائية', default='draft')

    @api.depends('items_ids', 'items_ids.rate', 'items_ids.prev_qty', 'items_ids.curr_qty', 
                 'calculation_method', 'retention_percent', 'advance_deduction_percent', 
                 'vat_percent', 'previous_payments', 'other_deductions')
    def _compute_totals(self):
        for rec in self:
            tot_cumulative = 0.0
            tot_prev_val = 0.0
            tot_curr_val = 0.0
            for line in rec.items_ids:
                tot_prev_val += line.prev_qty * line.rate
                tot_curr_val += line.curr_qty * line.rate
                tot_cumulative += (line.prev_qty + line.curr_qty) * line.rate
                
            rec.total_completed_works_val = tot_cumulative
            rec.previous_completed_works_val = tot_prev_val
            rec.current_works_val = tot_curr_val
            
            if rec.calculation_method == 'direct':
                rec.advance_deduction_amount = tot_curr_val * (rec.advance_deduction_percent / 100.0)
                rec.current_value_after_advance = tot_curr_val - rec.advance_deduction_amount
                rec.vat_amount = rec.current_value_after_advance * (rec.vat_percent / 100.0)
                rec.current_value_with_vat = rec.current_value_after_advance + rec.vat_amount
                rec.retention_amount = tot_curr_val * (rec.retention_percent / 100.0)
                rec.final_net_payable = rec.current_value_with_vat - rec.retention_amount - rec.other_deductions
            else:
                rec.retention_amount = tot_cumulative * (rec.retention_percent / 100.0)
                rec.advance_deduction_amount = rec.advance_deduction_percent
                net_cumulative_val = tot_cumulative - rec.retention_amount - rec.advance_deduction_amount - rec.other_deductions
                current_net_due = net_cumulative_val - rec.previous_payments
                current_net_due_positive = current_net_due if current_net_due > 0 else 0.0
                rec.current_value_after_advance = current_net_due_positive
                rec.vat_amount = current_net_due_positive * (rec.vat_percent / 100.0)
                rec.final_net_payable = current_net_due_positive + rec.vat_amount

class MostakhlasCertificateLine(models.Model):
    _name = 'mostakhlas.certificate.line'
    _description = 'Mostakhlas Base Work Items (بنود أعمال المقاول)'
    
    certificate_id = fields.Many2one('mostakhlas.certificate', string='المستخلص الأب', ondelete='cascade', required=True)
    item_number = fields.Char(string='رقم البند المرجعي والميداني', required=True, default='1')
    description = fields.Text(string='بيان الأعمال وبنود التشييد والخلطات بالتفصيل', required=True)
    unit = fields.Char(string='وحدة القياس الهندسية', default='متر مكعب', required=True)
    contract_qty = fields.Float(string='الكمية التعاقدية الكلية المعتمدة', default=0.0)
    rate = fields.Float(string='فئة وتكلفة البند الفردية (ريال)', default=0.0)
    prev_qty = fields.Float(string='الكمية المنفذة في دورات سابقة', default=0.0)
    curr_qty = fields.Float(string='الكمية الحالية المنفذة هذه الدورة', default=0.0)
    total_qty = fields.Float(string='الكمية التراكمية الإجمالية المنفذة', compute='_compute_qty', store=True)
    total_val = fields.Float(string='القيمة الإجمالية المنفذة', compute='_compute_qty', store=True)

    @api.depends('prev_qty', 'curr_qty', 'rate')
    def _compute_qty(self):
        for line in self:
            line.total_qty = line.prev_qty + line.curr_qty
            line.total_val = (line.prev_qty + line.curr_qty) * line.rate`,
    view: `<?xml version="1.0" encoding="utf-8"?>
<odoo>
    <record id="view_mostakhlas_certificate_tree" model="ir.ui.view">
        <name>mostakhlas.certificate.tree</name>
        <model>mostakhlas.certificate</model>
        <arch type="xml">
            <tree string="مستخلصات المقاولين جاري" decoration-success="state == 'approved'">
                <field name="certificate_number"/>
                <field name="title"/>
                <field name="date"/>
                <field name="contractor_id"/>
                <field name="total_completed_works_val" sum="إجمالي الأعمال التراكمية"/>
                <field name="current_works_val" sum="إجمالي أعمال المستخلص الإجمالية"/>
                <field name="final_net_payable" sum="الصافي المستحق للمقاول"/>
                <field name="state" widget="badge"/>
            </tree>
        </arch>
    </record>

    <record id="view_mostakhlas_certificate_form" model="ir.ui.view">
        <name>mostakhlas.certificate.form</name>
        <model>mostakhlas.certificate</model>
        <arch type="xml">
            <form string="مستخلص جاري المقاول">
                <header>
                    <button name="action_under_review" type="object" string="إرسال لإستشاري ومراجعة" class="oe_highlight" invisible="state != 'draft'"/>
                    <button name="action_approve" type="object" string="اعتماد ومطابقة الصرف" class="btn-success" invisible="state != 'under_review'"/>
                    <field name="state" widget="statusbar"/>
                </header>
                <sheet>
                    <notebook>
                        <page string="جدول بنود كميات الأعمال المنفذة (BOQ)">
                            <field name="items_ids">
                                <tree editable="bottom">
                                    <field name="item_number"/>
                                    <field name="description"/>
                                    <field name="unit"/>
                                    <field name="contract_qty"/>
                                    <field name="rate"/>
                                    <field name="prev_qty"/>
                                    <field name="curr_qty"/>
                                    <field name="total_qty" readonly="1"/>
                                    <field name="total_val" readonly="1"/>
                                </tree>
                            </field>
                        </page>
                    </notebook>
                </sheet>
            </form>
        </arch>
    </record>
</odoo>`,
    security: `id,name,model_id:id,group_id:id,perm_read,perm_write,perm_create,perm_unlink
access_mostakhlas_certificate_user,mostakhlas.certificate.user,model_mostakhlas_certificate,base.group_user,1,1,1,1
access_mostakhlas_certificate_line_user,mostakhlas.certificate.line.user,model_mostakhlas_certificate_line,base.group_user,1,1,1,1`,
    report: `<!-- مقتطف ملف التقرير العربي المطبوع -->
<template id="report_mostakhlas_certificate_template">
    <t t-call="web.html_container">
        <t t-foreach="docs" t-as="doc">
            <div class="page text-right" dir="rtl" style="font-family: Arial;">
                <h2>شركة روعة عالم التصميم للمقاولات</h2>
                <h4>مستخلص جاري رقم <t t-esc="doc.certificate_number"/></h4>
                <!-- حساب ميزانية الصرف المالي الفورية -->
            </div>
        </t>
    </t>
</template>`
  };

  const copyToClipboard = (key: keyof typeof fileContents, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedFile(key);
    setTimeout(() => setCopiedFile(null), 2500);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in" dir="rtl">
      <div className="bg-white rounded-3xl w-full max-w-5xl shadow-2xl overflow-hidden border border-slate-200 animate-scale-up flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-6 flex justify-between items-center shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 flex items-center justify-center text-slate-900 font-extrabold flex-shrink-0 animate-pulse">
              O
            </div>
            <div>
              <h3 className="text-lg font-black flex items-center gap-2">
                <span>بوابة التكامل السحابي والموديل المخصص لأودو 19</span>
                <span className="text-[10px] bg-amber-400 text-slate-950 font-extrabold px-2 py-0.5 rounded-full uppercase">Odoo 19 Built</span>
              </h3>
              <p className="text-xs text-slate-300 mt-1">توليد ومطابقة الأكواد البرمجية الرسمية لتثبيتها على قاعدة بيانات أودو أونلاين</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Container (Scrollable) */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          
          {/* Top Instruction Banner */}
          <div className="bg-amber-50 border border-amber-200/80 p-4 rounded-2xl flex flex-col sm:flex-row items-center sm:items-start gap-4">
            <span className="p-2.5 bg-amber-100 text-amber-700 rounded-xl">
              <Sparkles className="w-5 h-5 flex-shrink-0" />
            </span>
            <div className="text-right flex-1">
              <h4 className="text-xs font-black text-amber-950">تنويه تقني هام لنسخة أودو أونلاين (SaaS Online):</h4>
              <p className="text-[11px] text-amber-800 leading-normal mt-1.5">
                تتيح لك منصة **أودو أونلاين القياسية (Standard SaaS)** تطبيق الفواتير الافتراضية، لكن لرفع واستخدام موديولات البايثون المخصصة (كما تم تصميمها بالأسفل) يتطلب النظام استخدام **بيئة Odoo.sh السحابية** أو استخدام **أودو على خادم مخصص (Self-Hosted)**. قمنا بكتابة الأكواد كاملة لتكون جاهزة للمزامنة أو الرفع فوراً!
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left: Interactive File Tabs (3 cols) */}
            <div className="lg:col-span-3 space-y-2">
              <span className="text-xs font-bold text-slate-400 block pb-1 pr-1">أكواد الموديول المخصص:</span>
              
              <button
                onClick={() => setActiveTab("model")}
                className={`w-full py-2.5 px-4 rounded-xl text-right text-xs font-bold transition flex items-center justify-between cursor-pointer border ${
                  activeTab === "model"
                    ? "bg-slate-900 border-slate-950 text-white"
                    : "bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700"
                }`}
              >
                <div className="flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-amber-500" />
                  <span>نماذج البايثون (mostakhlas.py)</span>
                </div>
              </button>

              <button
                onClick={() => setActiveTab("view")}
                className={`w-full py-2.5 px-4 rounded-xl text-right text-xs font-bold transition flex items-center justify-between cursor-pointer border ${
                  activeTab === "view"
                    ? "bg-slate-900 border-slate-950 text-white"
                    : "bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700"
                }`}
              >
                <div className="flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-blue-500" />
                  <span>ملفات الواجهة (views.xml)</span>
                </div>
              </button>

              <button
                onClick={() => setActiveTab("manifest")}
                className={`w-full py-2.5 px-4 rounded-xl text-right text-xs font-bold transition flex items-center justify-between cursor-pointer border ${
                  activeTab === "manifest"
                    ? "bg-slate-900 border-slate-950 text-white"
                    : "bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700"
                }`}
              >
                <div className="flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-emerald-500" />
                  <span>البيان المنشور (__manifest__)</span>
                </div>
              </button>

              <button
                onClick={() => setActiveTab("security")}
                className={`w-full py-2.5 px-4 rounded-xl text-right text-xs font-bold transition flex items-center justify-between cursor-pointer border ${
                  activeTab === "security"
                    ? "bg-slate-900 border-slate-950 text-white"
                    : "bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700"
                }`}
              >
                <div className="flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-rose-500" />
                  <span>تراخيص الأمان (ir.model.access)</span>
                </div>
              </button>

              <button
                onClick={() => setActiveTab("report")}
                className={`w-full py-2.5 px-4 rounded-xl text-right text-xs font-bold transition flex items-center justify-between cursor-pointer border ${
                  activeTab === "report"
                    ? "bg-slate-900 border-slate-950 text-white"
                    : "bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700"
                }`}
              >
                <div className="flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-purple-500" />
                  <span>تقرير الطباعة (Qweb Report)</span>
                </div>
              </button>
            </div>

            {/* Right: Code Viewer (9 cols) */}
            <div className="lg:col-span-9 flex flex-col h-[350px]">
              <div className="bg-slate-800 rounded-t-xl px-4 py-2 flex items-center justify-between border-b border-slate-700">
                <span className="text-xs text-slate-400 font-mono">
                  {activeTab === "model" && "mostakhlas.py"}
                  {activeTab === "view" && "mostakhlas_views.xml"}
                  {activeTab === "manifest" && "__manifest__.py"}
                  {activeTab === "security" && "ir.model.access.csv"}
                  {activeTab === "report" && "mostakhlas_report_templates.xml"}
                </span>
                
                <button
                  type="button"
                  onClick={() => copyToClipboard(activeTab, fileContents[activeTab])}
                  className="bg-slate-700 hover:bg-slate-600 active:scale-95 text-slate-100 px-3 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1.5 transition cursor-pointer"
                >
                  {copiedFile === activeTab ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">تم نسخ الكود!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>نسخ الكود الكامل</span>
                    </>
                  )}
                </button>
              </div>

              <textarea
                readOnly
                className="bg-slate-900 text-slate-100 p-4 rounded-b-xl text-xs font-mono w-full h-full focus:outline-none resize-none"
                style={{ direction: activeTab === "security" ? "ltr" : "ltr" }}
                value={fileContents[activeTab]}
              />
            </div>

          </div>

          {/* Setup steps guide footer inside modal with icons */}
          <div className="border-t border-slate-150 pt-5 text-right">
            <h4 className="text-sm font-black text-slate-900 flex items-center gap-2 mb-3">
              <BookOpen className="w-4 h-4 text-indigo-600" />
              <span>خطوات التركيب والربط الموصى بها</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/50 space-y-1">
                <span className="font-bold text-slate-850 block">1. إنشاء مجلد الموديول:</span>
                <p className="text-[11px] text-slate-450 leading-normal">
                  قم بتحميل ملفات المشروع كاملة (Export ZIP من إعدادات الموقع أعلى اليسار الكبرى). ستجد مجلد الموديول جاهزاً بالكامل باسم `odoo_mostakhlas_module`.
                </p>
              </div>
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/50 space-y-1">
                <span className="font-bold text-slate-850 block">2. الرفع على Odoo.sh:</span>
                <p className="text-[11px] text-slate-450 leading-normal">
                  ارفع المجلد مباشرة إلى مستودع جيت هاب المربوط بـ Odoo Online 19 الخاص بك ليقوم النظام بعمل Build سحابي وتحديث قاعدة الأكواد تلقائياً.
                </p>
              </div>
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/50 space-y-1">
                <span className="font-bold text-slate-850 block">3. التثبيت والطباعة:</span>
                <p className="text-[11px] text-slate-450 leading-normal">
                  تفعيل نمط المطور في أودو، ثم ابحث عن موديول &quot;Rawat Mostakhlas&quot; واضغط تثبيت لتبدأ في تسجيل وحصر المستخلصات وطباعتها فوراً.
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 p-4 border-t border-slate-200 flex justify-end gap-2 shrink-0">
          <button
            onClick={onClose}
            className="bg-slate-905 hover:bg-slate-900 text-slate-900 border border-slate-300 font-bold px-6 py-2 rounded-xl text-xs cursor-pointer transition active:scale-95"
          >
            إغلاق بوابات أودو
          </button>
        </div>

      </div>
    </div>
  );
}
