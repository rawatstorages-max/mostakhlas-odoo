import React, { useState, useRef } from "react";
import { CompanyProfile } from "../types";
import { X, Building, Info, FileText, Phone, Mail, MapPin, Upload, Sparkles, Check, Lock, Loader2 } from "lucide-react";

interface CompanyModalProps {
  company: CompanyProfile;
  username: string;
  onClose: () => void;
  onSave: (updatedCompany: CompanyProfile) => void;
}

export const CompanyModal: React.FC<CompanyModalProps> = ({
  company,
  username,
  onClose,
  onSave,
}) => {
  const [name, setName] = useState(company.name);
  const [crNumber, setCrNumber] = useState(company.crNumber);
  const [vatNumber, setVatNumber] = useState(company.vatNumber);
  const [address, setAddress] = useState(company.address);
  const [phone, setPhone] = useState(company.phone);
  const [email, setEmail] = useState(company.email);
  const [logoType, setLogoType] = useState<"initials" | "base64">(company.logoType);
  const [logoInitials, setLogoInitials] = useState(company.logoInitials);
  const [logoBase64, setLogoBase64] = useState(company.logoBase64);
  const [logoColor, setLogoColor] = useState(company.logoColor || "#dc2626");

  // Password reset fields
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [passwordStatus, setPasswordStatus] = useState({ success: false, message: "" });

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [statusMsg, setStatusMsg] = useState("");

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 1.5 * 1024 * 1024) {
        setStatusMsg("⚠️ حجم الصورة كبير جداً (يجب أن يكون أقل من 1.5 ميجابايت).");
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === "string") {
          setLogoBase64(reader.result);
          setLogoType("base64");
          setStatusMsg("✨ تم تحميل الشعار بنجاح!");
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setStatusMsg("⚠️ يرجى إدخال اسم الشركة.");
      return;
    }
    if (email && !email.includes("@")) {
      setStatusMsg("⚠️ يرجى تصحيح البريد الإلكتروني للشركة. يجب أن يحتوي على الرمز @ (مثال: info@rawataltasmem.com). البريد الذي أدخلته غير صالح حالياً.");
      return;
    }
    const updated: CompanyProfile = {
      name,
      crNumber,
      vatNumber,
      address,
      phone,
      email,
      logoType,
      logoInitials: logoInitials.substring(0, 3).toUpperCase(),
      logoBase64,
      logoColor,
    };
    onSave(updated);
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!oldPassword || !newPassword) {
      setPasswordStatus({ success: false, message: "⚠️ يرجى ملء كافة حقول كلمة المرور." });
      return;
    }
    setPasswordLoading(true);
    setPasswordStatus({ success: false, message: "" });
    try {
      const response = await fetch("/api/db/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ oldPassword, newPassword }),
      });
      const data = await response.json();
      if (response.ok) {
        setPasswordStatus({ success: true, message: "✅ تم تغيير كلمة المرور للمستخدم بنجاح!" });
        setOldPassword("");
        setNewPassword("");
      } else {
        setPasswordStatus({ success: false, message: `❌ ${data.error || "تعذر التغيير"}` });
      }
    } catch (err) {
      console.error(err);
      setPasswordStatus({ success: false, message: "⚠️ فشل الاتصال بالسيرفر لتغيير كلمة المرور." });
    } finally {
      setPasswordLoading(false);
    }
  };

  const colorOptions = [
    { name: "أحمر", value: "#dc2626" },
    { name: "أزرق", value: "#2563eb" },
    { name: "أخضر تعاقدي", value: "#16a34a" },
    { name: "برتقالي هيب", value: "#ea580c" },
    { name: "بنفسجي", value: "#7c3aed" },
    { name: "رمادي داكن", value: "#334155" },
    { name: "أسود فخم", value: "#0f172a" },
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4">
      <div 
        className="bg-white rounded-3xl shadow-2xl w-full max-w-3xl overflow-hidden border border-slate-100 flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-150"
        dir="rtl"
      >
        {/* Modal Header */}
        <div className="p-6 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
              <Building className="w-5 h-5 text-amber-400" />
            </div>
            <div className="text-right">
              <h3 className="font-extrabold text-base">إعدادات هوية المقاول وبيانات الشركة</h3>
              <p className="text-[11px] text-slate-300">خصص مخرجات وشعار المستخلص وعناوين الفواتير المعتمدة بمطبوعاتك</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 bg-white/10 rounded-xl transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Alerts Block */}
        {statusMsg && (
          <div className="bg-amber-50 text-amber-900 px-6 py-2.5 text-xs font-semibold text-center border-b border-amber-100">
            {statusMsg}
          </div>
        )}

        {/* Modal Content Form */}
        <div className="p-6 overflow-y-auto flex-1 grid grid-cols-1 md:grid-cols-5 gap-6">
          
          {/* Right Column: Profile Form (3/5 width) */}
          <form onSubmit={handleFormSubmit} className="md:col-span-3 space-y-4 text-right">
            <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider pb-1 border-b border-slate-50 flex items-center gap-1.5 justify-end">
              <span>تفاصيل السجل والاتصال</span>
              <Info className="w-3.5 h-3.5" />
            </h4>

            {/* Company Name */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-600">اسم المؤسسة / الشركة</label>
              <div className="relative">
                <input
                  type="text"
                  required
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-3 pr-9 py-2 text-xs text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="مثال: شركة روعة عالم التصميم للمقاولات"
                />
                <Building className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
              </div>
            </div>

            {/* CR & VAT */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-600">رقم السجل التجاري (CR)</label>
                <div className="relative">
                  <input
                    type="text"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-3 pr-9 py-2 text-xs text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white"
                    value={crNumber}
                    onChange={(e) => setCrNumber(e.target.value)}
                    placeholder="مثال: 4030201099"
                  />
                  <FileText className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-600">الرقم الضريبي الموحد (VAT)</label>
                <div className="relative">
                  <input
                    type="text"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-3 pr-9 py-2 text-xs text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white"
                    value={vatNumber}
                    onChange={(e) => setVatNumber(e.target.value)}
                    placeholder="مثال: 310123456700003"
                  />
                  <FileText className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
                </div>
              </div>
            </div>

            {/* Address */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-600">العنوان الجغرافي الرئيسي</label>
              <div className="relative">
                <input
                  type="text"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-3 pr-9 py-2 text-xs text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="المملكة العربية السعودية، جدة، حي النعيم"
                />
                <MapPin className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
              </div>
            </div>

            {/* Phone & Email */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-600">الهاتف وأرقام التواصل</label>
                <div className="relative">
                  <input
                    type="text"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-3 pr-9 py-2 text-xs text-slate-800 text-left focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white font-mono"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+966 50 123 4567"
                  />
                  <Phone className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-600">البريد الإلكتروني للشركة</label>
                <div className="relative">
                  <input
                    type="email"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-3 pr-9 py-2 text-xs text-slate-800 text-left focus:outline-none focus:ring-1 focus:ring-slate-400 focus:bg-white"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="info@domain.com"
                  />
                  <Mail className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex justify-end">
              <button
                type="submit"
                className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-6 py-2.5 rounded-xl cursor-pointer shadow-sm flex items-center gap-1"
              >
                <Check className="w-4 h-4 text-amber-400" />
                <span>حفظ بيانات الشركة ومزامنتها</span>
              </button>
            </div>
          </form>

          {/* Left Column: Brand Brand Logo Settings & Security (2/5 width) */}
          <div className="md:col-span-2 space-y-6 text-right">
            {/* BRANDING LOGO */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/60 space-y-4">
              <h4 className="text-xs font-black text-slate-600 uppercase tracking-wider pb-1 border-b border-slate-200/50 flex items-center gap-1 justify-end">
                <span>تخصيص شعار المقاول</span>
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              </h4>

              {/* Selector */}
              <div className="flex gap-2 justify-end">
                <button
                  type="button"
                  onClick={() => setLogoType("base64")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex-1 cursor-pointer ${
                    logoType === "base64" ? "bg-white text-slate-900 border border-slate-300 shadow-sm" : "text-slate-500 hover:bg-slate-100"
                  }`}
                >
                  صورة (شعار مخصص)
                </button>
                <button
                  type="button"
                  onClick={() => setLogoType("initials")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex-1 cursor-pointer ${
                    logoType === "initials" ? "bg-white text-slate-900 border border-slate-300 shadow-sm" : "text-slate-500 hover:bg-slate-100"
                  }`}
                >
                  رمز تجاري (سداسي/دائري)
                </button>
              </div>

              {/* Render dynamic previews */}
              <div className="flex items-center justify-center p-4 bg-white rounded-xl border border-slate-100 shadow-inner">
                {logoType === "base64" && logoBase64 ? (
                  <div className="relative group">
                    <img
                      src={logoBase64}
                      alt="Corporate Logo"
                      className="max-h-24 max-w-full rounded object-contain"
                      referrerPolicy="no-referrer"
                    />
                    <button
                      type="button"
                      onClick={() => setLogoBase64("")}
                      className="absolute -top-1 -right-1 bg-red-500 text-white p-0.5 rounded-full hover:bg-red-600 transition shadow"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ) : logoType === "initials" ? (
                  <div 
                    className="w-20 h-20 rounded-full flex items-center justify-center text-white font-mono font-extrabold text-2xl shadow-md transition-all duration-300"
                    style={{ backgroundColor: logoColor }}
                  >
                    {logoInitials || "CR"}
                  </div>
                ) : (
                  <div className="text-[10px] text-slate-400 py-6 text-center">لا يوجد شعار محمل حالياً</div>
                )}
              </div>

              {/* Logo controls */}
              {logoType === "base64" ? (
                <div className="space-y-2">
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs py-2 rounded-xl border border-indigo-200 transition cursor-pointer flex items-center justify-center gap-1"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>تحميل صورة الشعار (PNG/JPG)</span>
                  </button>
                  <p className="text-[9px] text-slate-400 text-center">يدعم صيغ الصور، حجم أقصى 1.5 ميجابايت</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-600">الأحرف الرمزية (بحد أقصى 3 حروف)</label>
                    <input
                      type="text"
                      className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 text-center font-mono focus:outline-none"
                      maxLength={3}
                      value={logoInitials}
                      onChange={(e) => setLogoInitials(e.target.value.toUpperCase())}
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-600">اختر لون الختم التجاري الرسمى</label>
                    <div className="flex flex-wrap gap-1.5 justify-end">
                      {colorOptions.map((c) => (
                        <button
                          key={c.value}
                          type="button"
                          onClick={() => setLogoColor(c.value)}
                          className={`w-5 h-5 rounded-full relative transition flex items-center justify-center cursor-pointer`}
                          style={{ backgroundColor: c.value }}
                          title={c.name}
                        >
                          {logoColor === c.value && (
                            <span className="w-1.5 h-1.5 rounded-full bg-white animate-scale-up" />
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* SECURITY PASSWORD CHANGE PASSWORD */}
            <form onSubmit={handleChangePassword} className="bg-slate-50 p-4 rounded-2xl border border-slate-200/60 space-y-3">
              <h4 className="text-xs font-black text-slate-600 uppercase tracking-wider pb-1 border-b border-slate-200/50 flex items-center gap-1 justify-end">
                <span>تغيير كلمة المرور للمستخدم</span>
                <Lock className="w-3.5 h-3.5" />
              </h4>

              <div className="text-[10px] text-slate-500 font-semibold leading-relaxed">
                المستخدم الحالي: <span className="font-mono text-slate-850 bg-slate-200/60 px-1.5 py-0.5 rounded">{username}</span>
              </div>

              {passwordStatus.message && (
                <p className={`text-[10px] font-bold text-center ${passwordStatus.success ? "text-emerald-600" : "text-rose-600"}`}>
                  {passwordStatus.message}
                </p>
              )}

              <div className="space-y-2">
                <input
                  type="password"
                  required
                  placeholder="كلمة المرور الحالية"
                  className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 text-right focus:outline-none placeholder:text-slate-400"
                  value={oldPassword}
                  onChange={(e) => setOldPassword(e.target.value)}
                />
                <input
                  type="password"
                  required
                  placeholder="كلمة المرور الجديدة"
                  className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 text-right focus:outline-none placeholder:text-slate-400"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                />
              </div>

              <button
                type="submit"
                disabled={passwordLoading}
                className="w-full bg-slate-200 hover:bg-slate-300 border border-slate-300 text-slate-800 font-bold text-xs py-2 rounded-xl transition cursor-pointer flex items-center justify-center gap-1 disabled:opacity-60"
              >
                {passwordLoading ? (
                  <Loader2 className="w-3 animate-spin" />
                ) : (
                  <span>تحديث كلمة المرور</span>
                )}
              </button>
            </form>

          </div>

        </div>
      </div>
    </div>
  );
};
