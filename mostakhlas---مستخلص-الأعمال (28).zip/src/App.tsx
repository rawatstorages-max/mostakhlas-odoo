import React, { useState, useEffect } from "react";
import { Certificate, WorkItem, CompanyProfile } from "./types";
import { SAMPLE_CERTIFICATES } from "./data/templates";
import { MostakhlasHeader } from "./components/MostakhlasHeader";
import { MostakhlasTable } from "./components/MostakhlasTable";
import { MostakhlasSummary } from "./components/MostakhlasSummary";
import { DelayReminderWidget } from "./components/DelayReminderWidget";
import { MostakhlasDashboard } from "./components/MostakhlasDashboard";
import { EmailModal } from "./components/EmailModal";
import { LoginScreen } from "./components/LoginScreen";
import { CompanyModal } from "./components/CompanyModal";
import { OdooModal } from "./components/OdooModal";
import { numberToArabicWords } from "./utils/tafqeet";
import * as XLSX from "xlsx";
import {
  FileSpreadsheet,
  Download,
  Mail,
  Printer,
  History,
  Trash,
  Plus,
  Copy,
  ChevronRight,
  TrendingUp,
  FileCheck,
  Coins,
  Building,
  Save,
  RotateCcw,
  Sparkles,
  Layers,
  Scale,
  Settings,
  LogOut,
  Upload,
  Terminal
} from "lucide-react";

export default function App() {
  // Application overarching states
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [activeId, setActiveId] = useState<string>("");
  const [isPrintMode, setIsPrintMode] = useState<boolean>(false);
  const [showEmailModal, setShowEmailModal] = useState<boolean>(false);
  const [showCompanyModal, setShowCompanyModal] = useState<boolean>(false);
  const [showOdooModal, setShowOdooModal] = useState<boolean>(false);
  const [saveToast, setSaveToast] = useState<string>("");
  const [currentView, setCurrentView] = useState<'portal' | 'workspace' | 'dashboard'>('portal');
  const [printLayout, setPrintLayout] = useState<'portrait' | 'landscape'>('landscape');

  const saveTimeoutRef = React.useRef<any>(null);

  // Authenticated DB states
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [company, setCompany] = useState<CompanyProfile | null>(null);
  const [username, setUsername] = useState<string>("admin");
  const [isDbLoading, setIsDbLoading] = useState<boolean>(true);

  // Load initially from Database API or LocalStorage fallback
  const loadDatabase = async () => {
    setIsDbLoading(true);
    const token = localStorage.getItem("mostakhlas_session_token");
    const isOffline = localStorage.getItem("mostakhlas_offline_mode") === "true";

    if (!token) {
      setIsAuthenticated(false);
      setIsDbLoading(false);
      return;
    }

    if (isOffline) {
      // Offline mode login
      const localSavedCompany = localStorage.getItem("mostakhlas_offline_company");
      const localSavedCerts = localStorage.getItem("mostakhlas_offline_certificates");

      if (localSavedCompany) {
        setCompany(JSON.parse(localSavedCompany));
      } else {
        setCompany({
          name: "شركة روعة عالم التصميم للمقاولات",
          crNumber: "4030201099",
          vatNumber: "310123456700003",
          address: "المملكة العربية السعودية، جدة",
          phone: "+966 50 123 4567",
          email: "rawatstorages@gmail.com",
          logoType: "initials",
          logoInitials: "CR",
          logoColor: "#dc2626",
          logoBase64: ""
        });
      }

      if (localSavedCerts) {
        const certs = JSON.parse(localSavedCerts);
        setCertificates(certs);
        if (certs.length > 0) {
          setActiveId((prev) => prev || certs[0].id);
        }
      } else {
        setCertificates(SAMPLE_CERTIFICATES);
        if (SAMPLE_CERTIFICATES.length > 0) {
          setActiveId((prev) => prev || SAMPLE_CERTIFICATES[0].id);
        }
      }
      setUsername("الضيف (نمط محلي أوفلاين)");
      setIsAuthenticated(true);
      setIsDbLoading(false);
      return;
    }

    try {
      const response = await fetch("/api/db/load");
      if (response.ok) {
        const data = await response.json();
        setCompany(data.company);
        setCertificates(data.certificates);
        setUsername(data.username || "admin");
        setIsAuthenticated(true);
        if (data.certificates && data.certificates.length > 0) {
          setActiveId((prev) => prev || data.certificates[0].id);
        }
        // Cache to localStorage for offline resilience
        localStorage.setItem("mostakhlas_offline_company", JSON.stringify(data.company));
        localStorage.setItem("mostakhlas_offline_certificates", JSON.stringify(data.certificates));
      } else {
        localStorage.removeItem("mostakhlas_session_token");
        setIsAuthenticated(false);
      }
    } catch (err) {
      console.error("Failed to load database:", err);
      // Fallback on network error
      const localSavedCompany = localStorage.getItem("mostakhlas_offline_company");
      const localSavedCerts = localStorage.getItem("mostakhlas_offline_certificates");
      if (localSavedCompany || localSavedCerts) {
        if (localSavedCompany) setCompany(JSON.parse(localSavedCompany));
        if (localSavedCerts) {
          const certs = JSON.parse(localSavedCerts);
          setCertificates(certs);
          if (certs.length > 0) setActiveId((prev) => prev || certs[0].id);
        }
        setUsername("الضيف (وضع الطوارئ)");
        setIsAuthenticated(true);
      } else {
        localStorage.removeItem("mostakhlas_session_token");
        setIsAuthenticated(false);
      }
    } finally {
      setIsDbLoading(false);
    }
  };

  useEffect(() => {
    loadDatabase();
  }, []);

  // Save changes to Server Database or local fallback
  const saveAllToDatabase = async (updatedList: Certificate[], updatedCompany?: CompanyProfile, forceImmediate = false) => {
    setCertificates(updatedList);
    const companyPayload = updatedCompany || company;
    if (updatedCompany) {
      setCompany(updatedCompany);
    }

    // Always keep LocalStorage updated for offline backup
    localStorage.setItem("mostakhlas_offline_company", JSON.stringify(companyPayload));
    localStorage.setItem("mostakhlas_offline_certificates", JSON.stringify(updatedList));

    const isOffline = localStorage.getItem("mostakhlas_offline_mode") === "true";
    if (isOffline) {
      setSaveToast("💾 تم الحفظ بوضع الأوفلاين في متصفحك!");
      const toastTimeout = (saveAllToDatabase as any).toastTimeout;
      if (toastTimeout) clearTimeout(toastTimeout);
      (saveAllToDatabase as any).toastTimeout = setTimeout(() => setSaveToast(""), 3000);
      return;
    }

    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
    }

    const performSave = async () => {
      try {
        const response = await fetch("/api/db/save", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            certificates: updatedList,
            company: companyPayload,
          }),
        });
        if (response.ok) {
          setSaveToast("✅ تم الحفظ والمزامنة مع السيرفر بنجاح!");
        } else {
          setSaveToast("⚠️ فشل الاتصال بالسيرفر. تم الحفظ محلياً فقط.");
        }
      } catch (err) {
        console.error("Error saving data to database server:", err);
        setSaveToast("💾 السيرفر غير متصل. تم الحفظ محلياً في متصفحك!");
      }
      const toastTimeout = (saveAllToDatabase as any).toastTimeout;
      if (toastTimeout) clearTimeout(toastTimeout);
      (saveAllToDatabase as any).toastTimeout = setTimeout(() => setSaveToast(""), 3000);
    };

    if (forceImmediate) {
      await performSave();
    } else {
      setSaveToast("💾 جاري الحفظ تلقائياً...");
      saveTimeoutRef.current = setTimeout(performSave, 1000);
    }
  };

  const handleLoginSuccess = (data: {
    token: string;
    company: CompanyProfile;
    certificates: Certificate[];
    username: string;
  }) => {
    localStorage.setItem("mostakhlas_session_token", data.token);
    setCompany(data.company);
    setCertificates(data.certificates && data.certificates.length > 0 ? data.certificates : SAMPLE_CERTIFICATES);
    setUsername(data.username);
    setIsAuthenticated(true);
    if (data.certificates && data.certificates.length > 0) {
      setActiveId(data.certificates[0].id);
    } else if (SAMPLE_CERTIFICATES.length > 0) {
      setActiveId(SAMPLE_CERTIFICATES[0].id);
    }

    // Always update offline cache on successful login
    localStorage.setItem("mostakhlas_offline_company", JSON.stringify(data.company));
    localStorage.setItem(
      "mostakhlas_offline_certificates", 
      JSON.stringify(data.certificates && data.certificates.length > 0 ? data.certificates : SAMPLE_CERTIFICATES)
    );
  };

  const handleLogout = () => {
    localStorage.removeItem("mostakhlas_session_token");
    localStorage.removeItem("mostakhlas_offline_mode");
    setIsAuthenticated(false);
    setCompany(null);
    setCertificates([]);
    setActiveId("");
  };

  const downloadFullDatabaseBackup = () => {
    const backupData = {
      version: "mostakhlas_v1",
      company,
      certificates,
      exportDate: new Date().toISOString()
    };
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backupData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `تصدير_قاعدة_بيانات_المستخلص_الكاملة_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    setSaveToast("📥 تم تصدير وتحميل ملف النسخة الاحتياطية لقواعد البيانات بنجاح!");
    setTimeout(() => setSaveToast(""), 4000);
  };

  const handleRestoreDatabaseBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (event) => {
        try {
          const parsed = JSON.parse(event.target?.result as string);
          if (parsed && (parsed.certificates || parsed.company)) {
            const updatedCerts = parsed.certificates || certificates;
            const updatedCompany = parsed.company || company;
            await saveAllToDatabase(updatedCerts, updatedCompany);
            if (parsed.company) setCompany(parsed.company);
            if (parsed.certificates) {
              setCertificates(parsed.certificates);
              if (parsed.certificates.length > 0) setActiveId(parsed.certificates[0].id);
            }
            setSaveToast("📥 تم استيراد واستعادة كامل ملفات قاعدة البيانات الخاصة بك بنجاح ومزامنتها على الخادم!");
            setTimeout(() => setSaveToast(""), 4000);
          } else {
            alert("الملف المرفوع غير مطابق لصيغة قاعدة بيانات المستخلصات المعتمدة!");
          }
        } catch (err) {
          alert("فشل قراءة وتحليل ملف النسخة الاحتياطية!");
        }
      };
      reader.readAsText(file);
    }
  };

  const handleSaveCompany = async (updatedCompany: CompanyProfile) => {
    setCompany(updatedCompany);
    
    // Update active contractorName in certificates so it matches company profile dynamically!
    const updatedCerts = certificates.map(c => ({
      ...c,
      contractorName: updatedCompany.name
    }));

    await saveAllToDatabase(updatedCerts, updatedCompany, true);
    setShowCompanyModal(false);
    setSaveToast("🏢 تم تحديث بيانات الشركة واللوغو وحفظها في قاعدة البيانات بنجاح ومزامنتها فوراً!");
    setTimeout(() => setSaveToast(""), 4000);
  };

  // Find active record safely with a fallback
  const fallbackTemplate: Certificate = SAMPLE_CERTIFICATES[0];
  const activeCertificate = certificates.find((c) => c.id === activeId) || certificates[0] || fallbackTemplate;

  const handleUpdateActiveCertificate = (fields: Partial<Certificate>) => {
    if (!activeCertificate) return;
    const updated = certificates.map((c) => {
      if (c.id === activeCertificate.id) {
        return { ...c, ...fields };
      }
      return c;
    });
    saveAllToDatabase(updated);
  };

  const handleUpdateActiveItems = (updatedItems: WorkItem[]) => {
    handleUpdateActiveCertificate({ items: updatedItems });
  };

  // Trigger manual save toast indicator
  const triggerManualSave = async () => {
    setSaveToast("💾 جاري حفظ البيانات ومزامنتها مع الخادم تفصيلياً...");
    try {
      await saveAllToDatabase(certificates, undefined, true);
      setSaveToast("💾 تم الحفظ والمزامنة المباشرة مع قاعدة البيانات الخاصة بالمشروع بنجاح!");
    } catch (err) {
      setSaveToast("⚠️ تعذر الاتصال بالسيرفر لحفظ التغييرات.");
    }
    setTimeout(() => setSaveToast(""), 4500);
  };

  // Create clean new empty certificate
  const createNewCertificate = () => {
    const newCert: Certificate = {
      id: `cert-${Date.now()}`,
      title: `مستخلص جاري جديد رقم ${certificates.length + 1}`,
      certificateNumber: `م-${certificates.length + 1}`,
      date: new Date().toISOString().split("T")[0],
      contractorName: company?.name || "شركة روعة عالم التصميم للمقاولات",
      projectName: "مشروع تشييد وصيانة وتصميم",
      clientName: "العميل المستحق",
      contractValue: 150000,
      contractDate: new Date().toISOString().split("T")[0],
      duration: "مدة العقد الأصلي",
      items: [
        {
          id: `item-${Date.now()}-1`,
          itemNumber: "1",
          description: "أعمال حفر وقواعد وتسليح مبدئي في الموقع شامل التعديلات الهندسية ومطابقة كود البناء",
          unit: "متر مكعب",
          contractQty: 250,
          rate: 180,
          prevQty: 0,
          currQty: 25,
          notes: "",
        },
      ],
      retentionPercent: 10,
      advanceDeduction: 0,
      otherDeductions: 0,
      vatPercent: 15,
      previousPayments: 0,
      siteEngineer: "م/ مهندس الموقع الأصلي",
      consultantEngineer: "المهندس الاستشاري الإشرافي",
      contractorRepresentative: "مفوض شركة المقاولات",
      createdAt: new Date().toISOString(),
    };
    const newList = [newCert, ...certificates];
    saveAllToDatabase(newList);
    setActiveId(newCert.id);
  };

  // Duplicate active certificate with smart previous quantities adjustment
  // Standard engineer flow: copy old details, make total quantity of old the new base "prevQty" of new!
  const duplicateActiveWithRollover = () => {
    const base = activeCertificate;
    const rolledOverItems = base.items.map((it) => {
      const prevQty = parseFloat(String(it.prevQty)) || 0;
      const currQty = parseFloat(String(it.currQty)) || 0;
      return {
        ...it,
        id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        prevQty: prevQty + currQty, // rollover accumulated quantity
        currQty: 0, // reset current quantity to input fresh progress!
      };
    });

    const nextNumberMatch = base.certificateNumber.match(/\d+/);
    const nextNumber = nextNumberMatch ? parseInt(nextNumberMatch[0]) + 1 : 2;

    const newCert: Certificate = {
      ...base,
      id: `cert-${Date.now()}`,
      title: `مستخلص جاري رقم ${nextNumber} (تراكمي مكرر)`,
      certificateNumber: `م-${nextNumber}`,
      date: new Date().toISOString().split("T")[0],
      items: rolledOverItems,
      previousPayments: (() => {
        // Automatically deduct previous net works as standard accounting
        const totalCompleted = base.items.reduce((sum, item) => {
          const q = (parseFloat(String(item.prevQty)) || 0) + (parseFloat(String(item.currQty)) || 0);
          return sum + q * (parseFloat(String(item.rate)) || 0);
        }, 0);
        const retention = totalCompleted * (parseFloat(String(base.retentionPercent)) || 0) / 100;
        const otherDed = parseFloat(String(base.otherDeductions)) || 0;
        return totalCompleted - retention - otherDed; // previous payment accumulated
      })(),
      createdAt: new Date().toISOString(),
    };

    const newList = [newCert, ...certificates];
    saveAllToDatabase(newList);
    setActiveId(newCert.id);
    setSaveToast("🔄 تم نسخ وتوليد المستخلص التراكمي اللاحق وترحيل كميات الإنجاز السابقة تلقائياً!");
    setTimeout(() => setSaveToast(""), 5000);
  };

  // Delete certificate record
  const deleteCertificate = (id: string) => {
    if (certificates.length <= 1) {
      alert("حسابات المستخلصات تتطلب وجود مستخلص واحد على الأقل، لا يمكن الحذف.");
      return;
    }
    const filtered = certificates.filter((c) => c.id !== id);
    saveAllToDatabase(filtered);
    setActiveId(filtered[0].id);
  };

  // Restore defaults to restart sandbox
  const restoreDefaultTemplates = () => {
    if (window.confirm("هل أنت متأكد من رغبتك في إعادة ضبط المصنع ومسح كافة المستخلصات الحالية واسترجاع النماذج المسبقة؟")) {
      saveAllToDatabase(SAMPLE_CERTIFICATES);
      setActiveId(SAMPLE_CERTIFICATES[0].id);
    }
  };

  // Calculations for KPI Cards
  const totalContractVal = activeCertificate.contractValue || 0;
  
  const totalCompletedTillDate = activeCertificate.items.reduce((sum, item) => {
    const qPrev = parseFloat(String(item.prevQty)) || 0;
    const qCurr = parseFloat(String(item.currQty)) || 0;
    return sum + (qPrev + qCurr) * (parseFloat(String(item.rate)) || 0);
  }, 0);

  const previousCompletedTillDate = activeCertificate.items.reduce((sum, item) => {
    return sum + (parseFloat(String(item.prevQty)) || 0) * (parseFloat(String(item.rate)) || 0);
  }, 0);

  const currentWorksOnly = activeCertificate.items.reduce((sum, item) => {
    return sum + (parseFloat(String(item.currQty)) || 0) * (parseFloat(String(item.rate)) || 0);
  }, 0);

  const isDirect = activeCertificate.calculationMethod === "direct";
  const vatPercent = parseFloat(String(activeCertificate.vatPercent)) || 0;
  const retentionPercent = parseFloat(String(activeCertificate.retentionPercent)) || 0;
  const advanceDeduction = parseFloat(String(activeCertificate.advanceDeduction)) || 0;
  const otherDeductionsVal = parseFloat(String(activeCertificate.otherDeductions)) || 0;
  const previousPaidVal = parseFloat(String(activeCertificate.previousPayments)) || 0;
  const stageProgressPercent = parseFloat(String(activeCertificate.stageProgressPercent)) || 0;

  // Declare metrics
  let retentionDeduction = 0;
  let advanceDeductionAmount = 0;
  let currentNetBeforeVat = 0;
  let currentNetBeforeVatPos = 0;
  let currentVatVal = 0;
  let finalCurrentNetPayable = 0;
  let currentValueAfterAdvance = 0;
  let currentValueWithVat = 0;

  if (isDirect) {
    advanceDeductionAmount = currentWorksOnly * (advanceDeduction / 100);
    currentValueAfterAdvance = currentWorksOnly - advanceDeductionAmount;
    currentVatVal = currentValueAfterAdvance * (vatPercent / 100);
    currentValueWithVat = currentValueAfterAdvance + currentVatVal;
    retentionDeduction = currentWorksOnly * (retentionPercent / 100);
    finalCurrentNetPayable = currentValueWithVat - retentionDeduction - otherDeductionsVal;
  } else {
    retentionDeduction = totalCompletedTillDate * (retentionPercent / 100);
    advanceDeductionAmount = advanceDeduction;
    const netCumulativeWorksValue = totalCompletedTillDate - retentionDeduction - advanceDeductionAmount - otherDeductionsVal;
    currentNetBeforeVat = netCumulativeWorksValue - previousPaidVal;
    currentNetBeforeVatPos = currentNetBeforeVat < 0 ? 0 : currentNetBeforeVat;
    currentVatVal = currentNetBeforeVatPos * (vatPercent / 100);
    finalCurrentNetPayable = currentNetBeforeVatPos + currentVatVal;
  }

  const progressPercent = totalContractVal > 0 ? (totalCompletedTillDate / totalContractVal) * 100 : 0;

  // Custom high-fidelity SheetJS RTL Excel Export
  const exportToExcelFormat = () => {
    const cert = activeCertificate;

    // 1. Build Metadata Heading array
    const headingRows = [
      ["شركة روعة عالم التصميم للمقاولات - مستند مستخلص أعمال رسمي"],
      [`المستخلص الإداري: ${cert.title}`, "", "", "", "", "", "", "", "تاريخ العمل:", cert.date],
      ["المعلومات الإدارية والتعاقدية الأساسية:"],
      ["اسم المقاول الطرف الثاني:", cert.contractorName, "", "", "", "مالك العقد / العميل:", cert.clientName],
      ["بيان الأعمال المتفق عليها:", cert.projectName, "", "", "", "مدة العقد وفترة التقييم:", cert.duration],
      ["قيمة العقد الكلية بالميزانية:", `${cert.contractValue?.toLocaleString()} ريال سعودي`, "", "", "", "تاريخ انطلاق وبدء العمل الميداني:", cert.contractDate],
      [], // Spacing row
      ["جدول بنود الحسابات ودفاتر حصر الكميات المعتمدة:"],
    ];

    // 2. Build Work items header columns
    const itemHeaders = [
      "بند",
      "بيان الأعمال وتوصيف الإنجاز المالي",
      "الوحدة",
      "الكمية بالعقد",
      "سعر الفئة بالريال",
      "الكمية السابقة المنفذة",
      "الكمية الحالية الصرف",
      "إجمالي الكمية المنفذة",
      "قيمة الجملة التراكمية",
      "قيمة المستخلص الحالي",
      "ملاحظات التدقيق"
    ];

    // 3. Populate row data
    const itemRows = cert.items.map((item) => {
      const qContract = parseFloat(String(item.contractQty)) || 0;
      const rate = parseFloat(String(item.rate)) || 0;
      const qPrev = parseFloat(String(item.prevQty)) || 0;
      const qCurr = parseFloat(String(item.currQty)) || 0;
      const qTotal = qPrev + qCurr;
      const totalVal = qTotal * rate;
      const currVal = qCurr * rate;

      return [
        item.itemNumber,
        item.description,
        item.unit,
        qContract,
        rate,
        qPrev,
        qCurr,
        qTotal,
        totalVal,
        currVal,
        item.notes
      ];
    });

    // 4. Populate financial math block rows
    const summaryRows = isDirect ? [
      [],
      ["", "إيجاز المعاملة المالية والتسوية المباشرة من مستخلص جاري الحالي:"],
      ["", "إجمالي قيمة الأعمال المنفذة تراكمياً حتى تاريخه:", "", "", "", "", "", "", totalCompletedTillDate],
      ["", "نسبة الإنجاز الإجمالية للمشروع بالكامل % :", "", "", "", "", "", "", totalContractVal > 0 ? ((totalCompletedTillDate / totalContractVal) * 100).toFixed(2) + "%" : "0.00%"],
      cert.stageProgressPercent ? ["", "نسبة إنجاز المرحلة الأولى والثانية الكلية % :", "", "", "", "", "", "", cert.stageProgressPercent.toFixed(2) + "%"] : [],
      ["", "إجمالي قيمة الأعمال المنفذة سابقاً المطروحة:", "", "", "", "", "", "", -previousCompletedTillDate],
      ["", "إجمالي قيمة المستخلص الحالي (قبل الخصم والضريبة):", "", "", "", "", "", "", currentWorksOnly],
      ["", `خصم استرداد دفعة مقدمة بنسبة (${cert.advanceDeduction}%):`, "", "", "", "", "", "", -advanceDeductionAmount],
      ["", "إجمالي المستخلص بعد خصم الدفعة المقدمة:", "", "", "", "", "", "", currentValueAfterAdvance],
      ["", `ضريبة القيمة المضافة المحتسبة بنسبة (${cert.vatPercent}%):`, "", "", "", "", "", "", currentVatVal],
      ["", "الإجمالي شامل الضريبة المضافة VAT:", "", "", "", "", "", "", currentValueWithVat],
      ["", `خصم ضمان الأعمال وتوقيفات الإنجاز بنسبة (${cert.retentionPercent}%):`, "", "", "", "", "", "", -retentionDeduction],
      otherDeductionsVal > 0 ? ["", "خصومات وغرامات ومقاصات أخرى مستبعدة:", "", "", "", "", "", "", -otherDeductionsVal] : [],
      ["", "صافي مستخلص جاري النهائي (الصافي المستحق للمقاول) :", "", "", "", "", "", "", finalCurrentNetPayable],
      [],
      ["", "المستحق بالأحرف:", numberToArabicWords(Number(finalCurrentNetPayable.toFixed(2)))],
      [],
      ["توقيع واعتماد المشرف والموقع:"],
      ["مهندس ومراقب الموقع:", cert.siteEngineer, "", "المهندس الاستشاري الإشرافي:", cert.consultantEngineer, "", "المقاول المنفذ رسمي:", cert.contractorRepresentative]
    ].filter(r => r.length > 0) : [
      [],
      ["", "إيجاز المعاملة المالية والتسوية التراكمية المعتمدة للفترة:"],
      ["", "إجمالي قيمة الأعمال والخرسانات المنفذة ميدانياً حتى تاريخه:", "", "", "", "", "", "", totalCompletedTillDate],
      ["", `خصم ضمان جودة وتوقيفات تعاقدية بنسبة (${cert.retentionPercent}%):`, "", "", "", "", "", "", -retentionDeduction],
      ["", "خصومات وغرامات ومقاصات أخرى مستبعدة:", "", "", "", "", "", "", -otherDeductionsVal],
      ["", "صافي الأعمال المنفذة التراكمية قبل الدفعات السابقة والضرائب:", "", "", "", "", "", "", totalCompletedTillDate - retentionDeduction - otherDeductionsVal],
      ["", "تنزيل ما تم صرفه بموجب المستخلصات السابقة:", "", "", "", "", "", "", -previousPaidVal],
      ["", "صافي مستحق الدفع بموجب المستخلص الجاري الحالي (قبل الضريبة):", "", "", "", "", "", "", currentNetBeforeVatPos],
      ["", `ضريبة القيمة المضافة المحتسبة بنسبة (${cert.vatPercent}%):`, "", "", "", "", "", "", currentVatVal],
      ["", "إجمالي صافي القيمة النهائية المستحقة للصرف للمقاول الطرف الثاني:", "", "", "", "", "", "", finalCurrentNetPayable],
      [],
      ["", "المستحق بالأحرف:", numberToArabicWords(Number(finalCurrentNetPayable.toFixed(2)))],
      [],
      ["توقيع واعتماد المشرف والموقع:"],
      ["مهندس ومراقب الموقع:", cert.siteEngineer, "", "المهندس الاستشاري الإشرافي:", cert.consultantEngineer, "", "المقاول المنفذ رسمي:", cert.contractorRepresentative]
    ];

    // Merge into one massive array
    const finalSheetData = [...headingRows, itemHeaders, ...itemRows, ...summaryRows];

    // Create SheetJS workbook and sheet
    const ws = XLSX.utils.aoa_to_sheet(finalSheetData);
    
    // Add columns widths for beautiful layout inside Excel
    ws["!cols"] = [
      { wch: 6 },  // بند
      { wch: 55 }, // بيان الأعمال
      { wch: 12 }, // الوحدة
      { wch: 13 }, // الكمية بالعقد
      { wch: 15 }, // سعر الفئة
      { wch: 15 }, // الكمية السابقة
      { wch: 15 }, // الكمية الحالية
      { wch: 15 }, // إجمالي الكمية
      { wch: 18 }, // الجملة
      { wch: 18 }, // قيمة الحالي
      { wch: 25 }, // ملاحظات
    ];

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "مستخلص الأعمال");

    // Force sheet orientation to Right-to-Left (RTL) for perfect Arabic opening inside MS Excel!
    if (!wb.Workbook) wb.Workbook = {};
    if (!wb.Workbook.Views) wb.Workbook.Views = [];
    wb.Workbook.Views[0] = { RTL: true };

    // Write file
    XLSX.writeFile(wb, `${cert.projectName.substring(0, 30).trim()}_مستخلص_أعمال_${cert.certificateNumber}.xlsx`);
  };

  // PDF Export optimized via CSS Print style
  const printMostakhlasDocument = () => {
    window.print();
  };

  if (isDbLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 text-white text-center" dir="rtl">
        <div className="w-10 h-10 rounded-full border-4 border-rose-500 border-t-transparent animate-spin mb-4 mx-auto" />
        <p className="text-sm font-bold text-slate-350">جاري الاتصال والتحميل من قاعدة بيانات مستخلصات روعة...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginScreen onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className={`min-h-screen bg-slate-50 text-right selection:bg-amber-100 font-sans ${isPrintMode ? "bg-white p-0" : "pb-12"}`} dir="rtl">
      {/* HEADER BAR (Hidden in print mode) */}
      {!isPrintMode && (
        <header className="bg-white border-b border-slate-200/80 sticky top-0 z-40 print:hidden shadow-xs">
          {/* Primary Row: Identity & Brand */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col md:flex-row items-center justify-between gap-4">
            
            {/* Right Side: Identity & Info */}
            <div className="text-center md:text-right flex items-center gap-3.5 w-full md:w-auto justify-start">
              {company?.logoType === "base64" && company.logoBase64 ? (
                <img
                  src={company.logoBase64}
                  alt={company.name}
                  className="h-12 w-12 rounded-xl object-contain border border-slate-200 p-1.5 bg-slate-50 hidden sm:block shrink-0 shadow-xs"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-black text-sm shadow-sm font-mono hidden sm:flex shrink-0 transition"
                  style={{ backgroundColor: company?.logoColor || "#2563eb" }}
                >
                  {company?.logoInitials || "CR"}
                </div>
              )}
              
              {currentView === 'portal' ? (
                <div className="text-right">
                  <h1 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight flex items-center gap-2 justify-center md:justify-start">
                    <span>{company?.name || "شركة روعة عالم التصميم للمقاولات"}</span>
                  </h1>
                  <p className="text-xs text-slate-500 font-medium mt-1">
                    لوحة السيطرة الرئيسية | <span className="text-teal-600 font-bold">بوابة المستخلصات ونظام التدفقات الذكي</span>
                  </p>
                </div>
              ) : (
                <div className="text-right">
                  <h1 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight flex items-center gap-2 justify-center md:justify-start">
                    <span>{activeCertificate.title}</span>
                    <span className="text-xs bg-slate-100 border border-slate-200 px-2 py-0.5 rounded-full font-bold text-slate-605">
                      {activeCertificate.certificateNumber}
                    </span>
                  </h1>
                  <p className="text-xs text-slate-500 font-medium mt-1">
                    المشروع: <span className="text-slate-800 font-semibold">{activeCertificate.projectName || "المشروع الإنشائي"}</span> | كود: <span className="font-mono text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded text-[10px]">PRJ-{activeCertificate.date?.replace(/-/g, "").substring(0, 6)}</span>
                  </p>
                </div>
              )}
            </div>

            {/* Left Side: Corporate Logo, Username details & Logout */}
            <div className="flex items-center gap-3 bg-slate-50 px-4 py-2 rounded-2xl border border-slate-200/60 w-full sm:w-auto justify-between sm:justify-start">
              <div className="text-right sm:text-left">
                <div className="text-xs font-black text-slate-800">{company?.name || "المقاول الرئيسي"}</div>
                <div className="text-[10px] text-slate-400 mt-0.5 flex items-center gap-1.5justify-end">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
                  <span>المستخدم: {username}</span>
                </div>
              </div>

              <div className="h-6 w-[1.5px] bg-slate-200 hidden sm:block mx-2"></div>

              <button
                onClick={handleLogout}
                title="تسجيل الخروج الآمن من النظام"
                className="bg-white hover:bg-rose-50 text-slate-650 hover:text-rose-600 p-2 rounded-xl border border-slate-200 shadow-xs cursor-pointer transition active:scale-95"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Secondary Row: Cohesive Action Toolbar Ribbon - Only shown when NOT on portal */}
          {currentView !== 'portal' && (
            <div className="bg-slate-50/70 border-t border-slate-150/80 py-2.5">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-3">
                
                {/* Group A: Core View Toggle Switcher / Breadcrumb returning to Portal */}
                <div className="w-full md:w-auto flex justify-center md:justify-start gap-2">
                  <button
                    onClick={() => setCurrentView('portal')}
                    title="العودة للبوابة الرئيسية والنظام الرئيسي"
                    className="h-9 px-4 rounded-xl font-bold flex items-center gap-1.5 transition text-xs cursor-pointer border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 active:scale-98 shadow-xs"
                  >
                    <ChevronRight className="w-4 h-4 text-slate-500 text-right scale-x-[-1]" />
                    <span>البوابة الرئيسية</span>
                  </button>

                  <button
                    onClick={() => setCurrentView(currentView === 'dashboard' ? 'workspace' : 'dashboard')}
                    title="التبديل بين لوحة التحليل البياني وجدول الحصر الفعلي"
                    className={`h-9 px-4 rounded-xl font-bold flex items-center gap-1.5 transition text-xs cursor-pointer shadow-xs border active:scale-98 ${
                      currentView === 'dashboard'
                        ? "bg-slate-900 border-slate-950 text-white hover:bg-slate-800"
                        : "bg-teal-600 border-teal-700 text-white hover:bg-teal-700"
                    }`}
                  >
                    <TrendingUp className="w-4 h-4" />
                    <span>{currentView === 'dashboard' ? "جدول تفاصيل الحصر والكميات" : "لوحة داشبورد المنجز والتاخير"}</span>
                  </button>
                </div>

                {/* Group B: Cohesive Operations & Outputs (Excel, PDF, Emails, Tools) */}
                <div className="flex flex-wrap items-center justify-center md:justify-end gap-2 w-full md:w-auto">
                  <button
                    onClick={exportToExcelFormat}
                    title="تصدير جدول الأعمال والكميات لملف إكسل مفرغ ومكتمل"
                    className="bg-white hover:bg-emerald-50 text-slate-700 border border-slate-200 hover:border-emerald-300 hover:text-emerald-800 h-9 px-3.5 rounded-xl font-bold flex items-center gap-1.5 transition text-xs shadow-xs cursor-pointer active:scale-98"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                    <span>تصدير Excel</span>
                  </button>

                  <button
                    onClick={() => setIsPrintMode(true)}
                    title="تفعيل وضع المعاينة والطباعة كـ PDF"
                    className="bg-white hover:bg-sky-50 text-slate-700 border border-slate-200 hover:border-sky-300 hover:text-sky-850 h-9 px-3.5 rounded-xl font-bold flex items-center gap-1.5 transition text-xs shadow-xs cursor-pointer active:scale-98"
                  >
                    <Printer className="w-4 h-4 text-sky-600" />
                    <span>معاينة وطباعة PDF</span>
                  </button>

                  <button
                    onClick={() => setShowEmailModal(true)}
                    title="إرسال بريد إلكتروني رسمي للاعتماد"
                    className="bg-white hover:bg-indigo-50 text-slate-700 border border-slate-200 hover:border-indigo-300 hover:text-indigo-850 h-9 px-3.5 rounded-xl font-bold flex items-center gap-1.5 transition text-xs shadow-xs cursor-pointer active:scale-98"
                  >
                    <Mail className="w-4 h-4 text-indigo-600" />
                    <span>المراسلة بالبريد</span>
                  </button>

                  {/* Vertical Divider */}
                  <div className="hidden lg:block h-6 w-px bg-slate-200 mx-1"></div>

                  {/* Backups & Company configuration */}
                  <button
                    onClick={() => setShowCompanyModal(true)}
                    title="تعديل بيانات الشركة وشعار المقاول"
                    className="bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-205 h-9 px-3.5 rounded-xl font-bold flex items-center gap-1.5 transition text-xs shadow-xs cursor-pointer active:scale-98"
                  >
                    <Settings className="w-4 h-4 text-slate-500" />
                    <span>بيانات الشركة</span>
                  </button>

                  <button
                    onClick={downloadFullDatabaseBackup}
                    title="تحميل نسخة احتياطية من جميع المستخلصات والبيانات الحالية"
                    className="bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-205 h-9 px-3.5 rounded-xl font-bold flex items-center gap-1.5 transition text-xs shadow-xs cursor-pointer active:scale-98"
                  >
                    <Download className="w-4 h-4 text-slate-500" />
                    <span>تحميل (JSON)</span>
                  </button>

                  <label
                    title="استعادة البيانات من ملف نسخة احتياطية سابق"
                    className="bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-205 h-9 px-3.5 rounded-xl font-bold flex items-center gap-1.5 transition text-xs shadow-xs cursor-pointer active:scale-98"
                  >
                    <Upload className="w-4 h-4 text-slate-500 animate-pulse" />
                    <span>استيراد backup</span>
                    <input
                      type="file"
                      accept=".json"
                      onChange={handleRestoreDatabaseBackup}
                      className="hidden"
                    />
                  </label>
                </div>

              </div>
            </div>
          )}
        </header>
      )}

      {/* PRIMARY WEB INTERACTIVE LAYOUT */}
      {!isPrintMode ? (
        currentView === 'portal' ? (
          /* PORTAL CONTROLLER PAGE - BEAUTIFUL ARABIC CORP PANEL */
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8 space-y-8 animate-fade-in" dir="rtl">
            
            {/* HERO BOARD & GREETINGS */}
            <div className="bg-slate-900 border border-slate-950 text-white p-6 sm:p-8 rounded-3xl relative overflow-hidden shadow-lg h-auto sm:h-64 flex flex-col justify-between">
              <div className="absolute top-0 left-0 w-72 h-72 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute bottom-0 right-0 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
              <div className="relative z-10">
                <div className="flex items-center gap-2 bg-amber-500/20 border border-amber-500/30 text-amber-305 w-fit px-3.5 py-1 rounded-full text-xs font-bold mb-4">
                  <Sparkles className="w-3.5 h-3.5 animate-pulse text-amber-400" />
                  <span>النظام متاح كلياً وبكامل أداء قاعدة البيانات المستقرة الذكية</span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-black text-white leading-tight">بوابة الحسابات والمستخلصات التراكمية النموذجية</h2>
                <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mt-2 leading-relaxed font-sans">
                  مرحباً بك في النظام السحابي الخاص بشركة <strong className="text-amber-400">{company?.name || "روعة عالم التصميم"}</strong>. تتبع بنود الحصر، صمم، رحل كمياتك اللاحقة بضغطة زر واحدة بمرونة تدفق حسابي دقيق وخالٍ من الأخطاء.
                </p>
              </div>
              <div className="relative z-10 flex flex-wrap items-center justify-between border-t border-slate-800 pt-4 mt-6 text-xs text-slate-400 gap-4">
                <div className="flex items-center gap-2">
                  <span className="w-2 rounded-full h-2 bg-emerald-550 inline-block animate-pulse" />
                  <span>متصل بالتخزين المحلي المتزامن بنجاح: <strong>{certificates.length} مستندات مؤرشفة</strong></span>
                </div>
                <div className="font-mono text-[11px] text-slate-500">
                  التاريخ الحالي: {new Date().toLocaleDateString('ar-SA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                </div>
              </div>
            </div>

            {/* CORE EXECUTIVE BENTO SECTIONS */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-right">
              
              {/* PRIMARY CARD Module 1: THE CERTIFICATES BOX */}
              <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200/80 shadow-xs p-6 space-y-6 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                    <div className="flex items-center gap-2 text-slate-900">
                      <Layers className="w-5 h-5 text-indigo-600" />
                      <h3 className="text-lg font-black text-slate-900">أرشيف وإدارة مستخلصات الأعمال الجارية</h3>
                    </div>
                    <span className="text-[11px] bg-slate-100 px-3 py-1 rounded-full font-bold text-slate-600">جدول أرشيفي شامل</span>
                  </div>

                  <p className="text-xs text-slate-500 mt-2">
                    قم باستعراض أرشيفك الحالي، أو اختر مستخلصاً نشطاً للدخول الفوري لورشة تعديل الكميات والنسب المالية.
                  </p>

                  {/* Saved file registers inside Certificates card */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-5 max-h-[360px] overflow-y-auto pr-1">
                    {/* Dashed button layout for Creating New Certificate directly inside the icon folder context */}
                    <div
                      onClick={() => {
                        createNewCertificate();
                        setCurrentView('workspace');
                      }}
                      className="group p-4 bg-amber-50/20 hover:bg-amber-50/50 rounded-2xl border-2 border-dashed border-amber-200 hover:border-amber-400 transition-all cursor-pointer flex flex-col justify-center items-center text-center h-32 hover:shadow-sm"
                    >
                      <Plus className="w-8 h-8 text-amber-500 mb-2 animate-bounce" />
                      <span className="text-xs font-black text-amber-900">إنشاء وعمل مستخلص هندسي جديد +</span>
                      <span className="text-[10px] text-amber-600 mt-1">بدء حصر جديد لفرع أو مرحلة مستمرة</span>
                    </div>

                    {certificates.map((cert) => {
                      const itemSum = cert.items.reduce((sum, item) => {
                        const totalQty = (parseFloat(String(item.prevQty)) || 0) + (parseFloat(String(item.currQty)) || 0);
                        return sum + totalQty * (parseFloat(String(item.rate)) || 0);
                      }, 0);

                      return (
                        <div
                          key={cert.id}
                          onClick={() => {
                            setActiveId(cert.id);
                            setCurrentView('workspace');
                          }}
                          className="group p-4 bg-slate-50/50 hover:bg-slate-900 hover:text-white rounded-2xl border border-slate-200/60 transition-all cursor-pointer flex flex-col justify-between h-32 relative hover:shadow-md hover:scale-[1.01]"
                        >
                          <div className="flex justify-between items-start gap-1">
                            <span className="font-mono text-[10px] text-slate-400 group-hover:text-slate-300 bg-white group-hover:bg-white/10 px-2 py-0.5 rounded-full font-bold border border-slate-200/20">
                              {cert.certificateNumber}
                            </span>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                if (window.confirm("هل أنت متأكد من مسح مستند هذا المستخلص نهائياً من ذاكرة المتصفح؟")) {
                                  deleteCertificate(cert.id);
                                }
                              }}
                              title="مسح المستخلص من الأرشيف"
                              className="text-slate-400 hover:text-rose-500 p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <Trash className="w-4 h-4" />
                            </button>
                          </div>

                          <div className="mt-2 text-right">
                            <h4 className="text-xs font-black line-clamp-1 text-slate-900 group-hover:text-white">
                              {cert.title}
                            </h4>
                            <p className="text-[10px] text-slate-400 mt-1">تاريخ الصدور: {cert.date}</p>
                          </div>

                          <div className="flex items-center justify-between border-t border-slate-150 group-hover:border-slate-800 pt-2 mt-2 text-[10px]">
                            <span className="text-indigo-600 group-hover:text-amber-400 font-bold">تعديل وتحرير الكميات ✨</span>
                            <span className="font-mono font-black group-hover:text-white">{itemSum.toLocaleString()} ر.س</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                    <button
                      type="button"
                      onClick={restoreDefaultTemplates}
                      className="text-slate-400 hover:text-rose-500 transition-colors flex items-center gap-1 font-semibold cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>إعادة الضبط وحذف كافة المستندات</span>
                    </button>
                  </div>
                  
                  <span className="text-xs text-slate-400">قم بتحميل النسخة الاحتياطية دورياً للحماية</span>
                </div>
              </div>

              {/* SECONDARY TILES */}
              <div className="space-y-6 flex flex-col justify-between">
                
                {/* Tile A: Analytics and Charts panel link */}
                <div 
                  onClick={() => setCurrentView('dashboard')}
                  className="bg-white rounded-3xl border border-slate-200/80 p-5 shadow-xs hover:shadow-md transition cursor-pointer flex flex-col justify-between h-[180px] group text-right"
                >
                  <div className="flex items-center justify-between">
                    <span className="p-2.5 bg-teal-50 text-teal-650 rounded-2xl group-hover:bg-slate-900 group-hover:text-white transition">
                      <TrendingUp className="w-5 h-5 flex-shrink-0" />
                    </span>
                    <span className="text-[10px] text-slate-400 font-bold">تحليل رسومي</span>
                  </div>
                  <div className="mt-4">
                    <h3 className="text-sm font-black text-slate-900">لوحة داشبورد المنجز والتأخير 📊</h3>
                    <p className="text-xs text-slate-500 leading-normal mt-1.5 line-clamp-2">
                      متابعة ذكية لنسب الإنجاز المالية الفورية ورسوم مبيان بيتشارت ويدجيت لضمان سير أعمال المقاول الرئيسي بسلاسة ومراقبة الغرامات.
                    </p>
                  </div>
                </div>

                {/* Tile B: Company setup preferences info */}
                <div 
                  onClick={() => setShowCompanyModal(true)}
                  className="bg-white rounded-3xl border border-slate-200/80 p-5 shadow-xs hover:shadow-md transition cursor-pointer flex flex-col justify-between h-[185px] group text-right"
                >
                  <div className="flex items-center justify-between">
                    <span className="p-2.5 bg-indigo-50 text-indigo-600 rounded-2xl group-hover:bg-slate-900 group-hover:text-white transition">
                      <Building className="w-5 h-5 flex-shrink-0" />
                    </span>
                    <span className="text-[10px] text-slate-400 font-bold">ملف الهوية</span>
                  </div>
                  <div className="mt-4">
                    <h3 className="text-sm font-black text-slate-900">بيانات المقاول والترويسة واللوجو ⚙️</h3>
                    <p className="text-xs text-slate-500 leading-normal mt-1.5 line-clamp-2">
                      تعديل بيانات ورقم السجل ومواصفات ألوان شعارك الشخصي ومقره الرئيسي لينعكس بجمالية فائقة على المستندات الورقية المطبوعة.
                    </p>
                  </div>
                </div>

                {/* Tile C: Help text */}
                <div className="bg-slate-900 text-slate-100 p-5 rounded-3xl border border-slate-950 space-y-3.5 shadow-md flex-1 flex flex-col justify-center text-right">
                  <div className="flex items-center gap-1.5 border-b border-slate-800 pb-2">
                    <Sparkles className="w-4 h-4 text-amber-400 animate-pulse flex-shrink-0" />
                    <h4 className="text-[11px] font-black text-amber-400 uppercase tracking-wider">الترقية المحاسبية التلقائية</h4>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-normal">
                    💡 <strong>ميزة الترحيل التراكمي المدمج:</strong> هل أنجزت مستخصلك السابق؟ لا تكتب الكميات يدوياً! تكرار المستمر يطرح الكمية من "الحالي" ليضيفها لـ "السابق" تلقائياً في خطوة واحدة!
                  </p>
                </div>

              </div>
            </div>

            {/* ODOO CORE 19 SPREAD WEB API INTEGRATION CARD */}
            <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-950 text-white p-6 rounded-3xl shadow-lg relative overflow-hidden animate-fade-in text-right">
              <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
              <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="space-y-2 max-w-3xl">
                  <div className="flex items-center gap-2 bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 w-fit px-3 py-0.5 rounded-full text-[10px] font-bold">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>جاهز للتكامل والتركيب المباشر (Module & APIs)</span>
                  </div>
                  <h3 className="text-lg font-black text-white flex items-center gap-2">
                    <span>ربط المرفقات وبنود الحصر والمستخلصات مع نظام أودو 19 (Odoo Suite)</span>
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed font-sans">
                    لقد قمنا بتطوير موديول برمي مخصص لشركة **روعة عالم التصميم للمقاولات** بلغة **Python** و **XML** متوافق كلياً مع نظام أودو أونلاين 19. يشمل الموديول تتبع الذمم والمصروفات، احتساب التسويات، وتقرير QWeb العربي للطباعة الورقية. يمكنك نسخ أو استخراج الأكواد لرفعها على Odoo.sh فوراً!
                  </p>
                </div>
                
                <button
                  type="button"
                  onClick={() => setShowOdooModal(true)}
                  className="bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-black px-6 py-3 rounded-2xl text-xs flex items-center gap-2 shadow-md transition cursor-pointer shrink-0 font-sans"
                >
                  <Terminal className="w-4 h-4" />
                  <span>فتح بوابة أودو واستعراض ملفات الموديول 🚀</span>
                </button>
              </div>
            </div>

            <div className="border-t border-slate-200/60 pt-6 text-center text-xs text-slate-400">
              جميع العمليات الحسابية متوفرة وفقاً للأنظمة المالية والضريبة المعتمدة (15% ضريبة مضافة حالية). روعة للمقاولات © 2026.
            </div>
          </div>
        ) : currentView === 'dashboard' ? (
          /* DASHBOARD ANALYTICS PORTLET */
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6 lg:mt-8">
            <MostakhlasDashboard
              certificates={certificates}
              onSelectCertificate={(id) => {
                setActiveId(id);
                setCurrentView('workspace');
              }}
              onClose={() => setCurrentView('portal')}
            />
          </div>
        ) : (
          /* WORKSPACE (THE COMPACT TAB-LESS EDITOR) - SPREADS WIDELY GIVING EXTENSIVE BREATHING SPACE */
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6 lg:mt-8 grid grid-cols-1 gap-6 animate-fade-in">
            <main className="space-y-8">
              {/* OVERVIEW METRIC CARDS (Bento Grid Style) */}
              <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-2 text-right">
                {/* Card 1: Contract Value */}
                <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between h-30 transition hover:shadow-sm">
                  <span className="text-slate-400 text-xs sm:text-sm font-bold">قيمة العقد الإجمالية</span>
                  <span className="text-lg sm:text-xl font-black text-indigo-700 font-mono">
                    {totalContractVal > 0 ? `${totalContractVal.toLocaleString()} ر.س` : "لم يحدد"}
                  </span>
                </div>

                {/* Card 2: Accumulated Completion */}
                <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between h-30 transition hover:shadow-sm">
                  <span className="text-slate-400 text-xs sm:text-sm font-bold">إجمالي المنجز حتى تاريخه</span>
                  <span className="text-lg sm:text-xl font-black text-emerald-600 font-mono">
                    {totalCompletedTillDate.toLocaleString()} ر.س
                  </span>
                </div>

                {/* Card 3: Completion percentage with progress bar */}
                <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between h-30 transition hover:shadow-sm">
                  <span className="text-slate-400 text-xs sm:text-sm font-bold">نسبة الإنجاز الكلية</span>
                  <div className="flex items-end gap-2">
                    <span className="text-xl sm:text-2xl font-black text-slate-800 font-mono">
                      {Math.round(progressPercent)}%
                    </span>
                    <div className="w-full bg-slate-100 h-2 rounded-full mb-1.5 overflow-hidden">
                      <div
                        className="bg-emerald-500 h-2 rounded-full transition-all duration-500"
                        style={{ width: `${Math.min(progressPercent, 100)}%` }}
                      ></div>
                    </div>
                  </div>
                </div>

                {/* Card 4: Net Cash Outflow Requested Now */}
                <div className="bg-white p-5 rounded-2xl border border-slate-200/85 shadow-xs flex flex-col justify-between h-30 transition hover:shadow-sm">
                  <span className="text-slate-400 text-xs sm:text-sm font-bold">صافي المستحق للمقاول</span>
                  <span className="text-lg sm:text-xl font-black text-amber-600 font-mono">
                    {finalCurrentNetPayable.toLocaleString()} ر.س
                  </span>
                </div>
              </section>

              {/* ACTION FLOATER TOOLBAR */}
              <div className="bg-white p-4 rounded-2xl shadow-xs border border-slate-100 flex flex-wrap gap-2 items-center justify-between">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      duplicateActiveWithRollover();
                      setCurrentView('workspace');
                    }}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold px-4 py-2.5 rounded-xl flex items-center gap-1.5 transition cursor-pointer font-sans"
                  >
                    <Copy className="w-4 h-4 flex-shrink-0" />
                    <span>تكرار المستخلص وترحيل كمياته اللاحقة</span>
                  </button>
                </div>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={triggerManualSave}
                    className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-5 py-2.5 rounded-xl flex items-center gap-1.5 transition shadow-xs cursor-pointer font-sans"
                  >
                    <Save className="w-4 h-4 text-amber-400 flex-shrink-0" />
                    <span>حفظ المستند الحالي 💾</span>
                  </button>
                </div>
              </div>

              {/* APP COMPONENT PARTS CHUNKS */}
              <MostakhlasHeader
                certificate={activeCertificate}
                onUpdate={handleUpdateActiveCertificate}
                isPrintView={false}
                company={company}
              />

              <MostakhlasTable
                items={activeCertificate.items}
                onUpdateItems={handleUpdateActiveItems}
                isPrintView={false}
              />

              <DelayReminderWidget
                certificate={activeCertificate}
                onUpdate={handleUpdateActiveCertificate}
                isPrintView={false}
              />

              <MostakhlasSummary
                certificate={activeCertificate}
                onUpdate={handleUpdateActiveCertificate}
                isPrintView={false}
              />

              {/* FOOTER WARNING (Hidden in print) */}
              <footer className="text-center text-[11px] text-slate-400 pt-10 border-t border-slate-150 flex flex-col md:flex-row justify-between text-right">
                <span>جميع الحقوق محفوظة للمقاول. تم تطويره بأفضل معايير التدفق الحسابي.</span>
                <span>روعة المقاولات والإنشاءات الذكية © 2026</span>
              </footer>
            </main>
          </div>
        )
      ) : (
        /* PRINT CANVAS VIEW */
        <div className="bg-white text-right p-6 min-h-screen" dir="rtl">
          {/* Dynamic Page Orientation Override Style Injection */}
          <style dangerouslySetInnerHTML={{ __html: `
            @media print {
              @page {
                size: A4 ${printLayout || 'portrait'} !important;
                margin: 0 !important;
              }
            }
          `}} />

          {/* Print controls bar, hidden under normal CSS print block but visible on viewport for testing */}
          <div className="print:hidden max-w-7xl mx-auto mb-6 bg-slate-900 text-white rounded-3xl p-5 flex flex-col md:flex-row gap-4 items-center justify-between shadow-lg">
            <div className="text-right">
              <h4 className="font-extrabold text-sm text-amber-400 flex items-center gap-1.5">
                <span>👀 وضع معاينة وثيقة الطباعة كـ PDF</span>
                <span className="text-[10px] bg-slate-800 border border-slate-700 px-2.5 py-0.5 rounded-full font-bold text-slate-300 mr-2">
                  نمط الصفحة: {printLayout === 'landscape' ? 'عرضي ↔' : 'طولي ↕'}
                </span>
              </h4>
              <p className="text-[10px] text-slate-300 mt-1">يظهر الشكل أدناه تماماً كما سيظهر على الورقة المطبوعة. تراجع للعمل أو أكد الطباعة.</p>
              
              {/* Optional inline frame warning alert */}
              {typeof window !== 'undefined' && window.self !== window.top && (
                <p className="text-[9px] text-amber-300/90 mt-1.5">
                  ⚠️ تنبيه: للتصفح الآمن داخل الـ iFrame، يُرجى استخدام زر <strong>"فتح في نافذة مستقلة"</strong> بشريط الأدوات ثم الضغط على "تأكيد الطباعة" لتفادي قيود المتصفح.
                </p>
              )}
            </div>

            <div className="flex flex-wrap gap-3 items-center">
              {/* Orientation Toggle Selector */}
              <div className="flex gap-1 bg-slate-800 p-1 rounded-xl border border-slate-700">
                <button
                  type="button"
                  onClick={() => setPrintLayout('portrait')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                    printLayout === 'portrait'
                      ? 'bg-amber-500 text-slate-950 font-black shadow-xs'
                      : 'text-slate-300 hover:text-white hover:bg-slate-700'
                  }`}
                >
                  طولي (A4)
                </button>
                <button
                  type="button"
                  onClick={() => setPrintLayout('landscape')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                    printLayout === 'landscape'
                      ? 'bg-amber-500 text-slate-950 font-black shadow-xs'
                      : 'text-slate-300 hover:text-white hover:bg-slate-700'
                  }`}
                >
                  عرضي (A4) ↔
                </button>
              </div>

              <div className="h-6 w-px bg-slate-800 hidden sm:block"></div>

              <div className="flex gap-2">
                <button
                  onClick={() => setIsPrintMode(false)}
                  className="bg-white/10 hover:bg-white/20 text-white text-xs px-4 py-2 rounded-xl transition font-bold flex items-center gap-1 cursor-pointer"
                >
                  <ChevronRight className="w-4 h-4 text-right scale-x-[-1]" />
                  <span>العودة للتعديل</span>
                </button>
                <button
                  onClick={printMostakhlasDocument}
                  className="bg-amber-500 hover:bg-amber-450 text-slate-905 text-xs font-black px-4 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
                >
                  <Printer className="w-4 h-4" />
                  <span>تأكيد وطباعة المستند</span>
                </button>
              </div>
            </div>
          </div>

          {/* Actual aligned printable core form sheet */}
          <div className="max-w-7xl mx-auto space-y-0.5 print-area">
            {/* Header frame */}
            <MostakhlasHeader
              certificate={activeCertificate}
              onUpdate={handleUpdateActiveCertificate}
              isPrintView={true}
              company={company}
            />

            {/* Central items of work */}
            <MostakhlasTable
              items={activeCertificate.items}
              onUpdateItems={handleUpdateActiveItems}
              isPrintView={true}
            />

            <DelayReminderWidget
              certificate={activeCertificate}
              onUpdate={handleUpdateActiveCertificate}
              isPrintView={true}
            />

            {/* Sum math ledger & signatures */}
            <MostakhlasSummary
              certificate={activeCertificate}
              onUpdate={handleUpdateActiveCertificate}
              isPrintView={true}
            />
          </div>
        </div>
      )}

      {/* CORE CONTROL EMAIL CHANNELS WINDOW PANEL */}
      {showEmailModal && (
        <EmailModal
          certificate={activeCertificate}
          company={company}
          onClose={() => setShowEmailModal(false)}
        />
      )}

      {/* COMPANY DETAIL & BRAND LOGO CUSTOMIZATION */}
      {showCompanyModal && company && (
        <CompanyModal
          company={company}
          username={username}
          onClose={() => setShowCompanyModal(false)}
          onSave={handleSaveCompany}
        />
      )}

      {/* ODOO INTEGRATION MODAL */}
      {showOdooModal && (
        <OdooModal
          onClose={() => setShowOdooModal(false)}
        />
      )}
    </div>
  );
}
