import express from "express";
import path from "path";
import fs from "fs";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// Database Setup and Helpers
const DB_DIR = path.join(process.cwd(), "data");
const DB_FILE = path.join(DB_DIR, "db.json");

function ensureDatabase() {
  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }

  if (!fs.existsSync(DB_FILE)) {
    const defaultData = {
      auth: {
        username: "admin",
        password: "123"
      },
      company: {
        name: "شركة روعة عالم التصميم للمقاولات",
        crNumber: "4030201099",
        vatNumber: "310123456700003",
        address: "المملكة العربية السعودية، الدمام",
        phone: "+966 50 123 4567",
        email: "it@rawataltasmem.com",
        logoType: "initials",
        logoInitials: "CR",
        logoBase64: "",
        logoColor: "#dc2626"
      },
      certificates: [
        {
          id: "template-rowa",
          title: "مستخلص جاري رقم 1",
          certificateNumber: "م-1",
          date: "2026-05-03",
          contractorName: "شركة روعة عالم التصميم للمقاولات",
          projectName: "اعتماد أعمال دعاية وإعلان المقر الجديد لمجموعة روعة",
          clientName: "شركة روعة الاستثمارية",
          contractValue: 121200,
          contractDate: "2026-04-10",
          duration: "مدة العقد",
          retentionPercent: 10,
          advanceDeduction: 0,
          otherDeductions: 0,
          vatPercent: 15,
          previousPayments: 0,
          siteEngineer: "م. محمد الحربي (مهندس التنفيذ)",
          consultantEngineer: "المهندس الاستشاري / المدير العام",
          contractorRepresentative: "ممثل شركة روعة عالم التصميم",
          createdAt: "2026-05-03T09:00:00Z",
          items: [
            {
              id: "item-1",
              itemNumber: "1",
              description: "تصميم وتوريد وتركيب مجسمات إعلانية مضيئة ثلاثية الأبعاد (3D Channel Letters) للمدخل الرئيسي للشركة بجدة بالهوية المعتمدة شاملة التمديدات الكهربائية وأجهزة التحكم والضمان والتشغيل والتركيب في الموقع.",
              unit: "مقطوعية",
              contractQty: 1,
              rate: 95000,
              prevQty: 0,
              currQty: 1,
              notes: "تم التركيب والتشغيل بنسبة 100% والاعتماد من مشرف الموقع"
            },
            {
              id: "item-2",
              itemNumber: "2",
              description: "طباعة وتوريد ملصقات فينيل جدارية داخلية مقاومة للرطوبة والخدش مع الحماية (Lamination) للديكورات والممرات والغرف والمكاتب الإدارية حسب التصاميم والمساحات المحددة بجدول الكميات.",
              unit: "متر مسطح",
              contractQty: 120,
              rate: 210,
              prevQty: 0,
              currQty: 120,
              notes: "مكتملة بالكامل ومسلمة حسب الفحص الهندسي للتشطيبات"
            }
          ]
        },
        {
          id: "template-villa",
          title: "مستخلص جاري رقم 3",
          certificateNumber: "م-3",
          date: "2026-06-09",
          contractorName: "مؤسسة الروافد للمقاولات العامة",
          projectName: "فيلا سكنية خاصة - حي النرجس بالرياض",
          clientName: "سعادة الأستاذ عبد الرحمن الخالدي",
          contractValue: 850000,
          contractDate: "2026-01-15",
          duration: "8 أشهر",
          retentionPercent: 5,
          advanceDeduction: 15000,
          otherDeductions: 1200,
          vatPercent: 15,
          previousPayments: 112000,
          siteEngineer: "م. يوسف العتيبي",
          consultantEngineer: "مكتب الإعمار للاستشارات الهندسية",
          contractorRepresentative: "م. خالد الرشيد (مدير المشروع)",
          createdAt: "2026-06-09T11:00:00Z",
          items: [
            {
              id: "v-item-1",
              itemNumber: "1",
              description: "أعمال الحفر والردم والتسوية لأرض المشروع تحت القواعد واللبشة شاملة النقل لمرامي البلدية والتنظيف والرش والدك طبقاً لتقرير فحص التربة المعتمد بالمشروع.",
              unit: "متر مكعب",
              contractQty: 450,
              rate: 35,
              prevQty: 450,
              currQty: 0,
              notes: "أعمال منتهية ومقاسة سابقاً"
            },
            {
              id: "v-item-2",
              itemNumber: "2",
              description: "خرسانة عادية عيار 250 كجم/سم3 مقاومة للأملاح والكبريتات أسفل القواعد والأساسات بسمك 10 سم شاملة الصب والرش بالماء وتجفيف القوالب طبقاً للمواصفات والمخططات التفصيلية.",
              unit: "متر مسطح",
              contractQty: 180,
              rate: 85,
              prevQty: 180,
              currQty: 0,
              notes: "أعمال منتهية ومقاسة سابقاً"
            },
            {
              id: "v-item-3",
              itemNumber: "3",
              description: "خرسانة مسلحة للقواعد والأساسات عيار 350 كجم/سم3 باستخدام الإسمنت المقاوم شاملة حديد التسليح الكويتي أو الراجحي وتوريد خرسانة جاهزة من مصنع معتمد والصب بالمضخة والاختبار والاختام والرش.",
              unit: "متر مكعب",
              contractQty: 110,
              rate: 450,
              prevQty: 90,
              currQty: 20,
              notes: "تم استكمال كامل الكمية بنسبة 100% في هذه الدورة"
            },
            {
              id: "v-item-4",
              itemNumber: "4",
              description: "خرسانة مسلحة لرقاب الأعمدة وميدات الأرضية شاملة الحديد والعزل المائي بمادة البتومين الحار ثلاث طبقات والردم بين الميدات على طبقات بسمك 30 سم والرش والدك وجدول تسوية التدفق.",
              unit: "متر مكعب",
              contractQty: 65,
              rate: 550,
              prevQty: 30,
              currQty: 30,
              notes: "تم بناء دكة الأرضية والصب وعزل الرقاب والميدات بنسبة 92%"
            },
            {
              id: "v-item-5",
              itemNumber: "5",
              description: "مباني الطوب الأسمنتي المعزول (البلوك الأسود المعزول جفالي) بسمك 20 سم للجدران الخارجية شامل المونة الأسمنتية والشبك والزوايا المعدنية وإبر التثبيت طبقاً للأصول الهندسية والمخططات.",
              unit: "متر مسطح",
              contractQty: 350,
              rate: 65,
              prevQty: 0,
              currQty: 140,
              notes: "بدء أعمال جدران الدور الأرضي بنجاح"
            }
          ]
        }
      ]
    };
    fs.writeFileSync(DB_FILE, JSON.stringify(defaultData, null, 2), "utf-8");
  }
}

function getDatabase() {
  ensureDatabase();
  const content = fs.readFileSync(DB_FILE, "utf-8");
  return JSON.parse(content);
}

function saveDatabase(data: any) {
  ensureDatabase();
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf-8");
}

// REST API for authentication and persistence
app.post("/api/login", (req, res) => {
  const { username, password } = req.body;
  const db = getDatabase();
  if (
    db.auth.username.toLowerCase() === (username || "").toLowerCase().trim() &&
    db.auth.password === (password || "").trim()
  ) {
    return res.json({
      success: true,
      token: "session_token_mostakhlas_2026",
      company: db.company,
      certificates: db.certificates,
      username: db.auth.username
    });
  } else {
    return res.status(401).json({ error: "خطأ في اسم المستخدم أو كلمة المرور!" });
  }
});

app.get("/api/db/load", (req, res) => {
  const db = getDatabase();
  return res.json({
    company: db.company,
    certificates: db.certificates,
    username: db.auth.username
  });
});

app.post("/api/db/save", (req, res) => {
  const { company, certificates } = req.body;
  const db = getDatabase();
  
  if (company) db.company = company;
  if (certificates) db.certificates = certificates;

  saveDatabase(db);
  return res.json({ success: true, message: "تم الحفظ بنجاح في قاعدة البيانات!" });
});

app.post("/api/db/change-password", (req, res) => {
  const { oldPassword, newPassword } = req.body;
  const db = getDatabase();
  if (db.auth.password === (oldPassword || "").trim()) {
    if (!newPassword || newPassword.trim().length === 0) {
      return res.status(400).json({ error: "كلمة المرور الجديدة لا يمكن أن تكون فارغة!" });
    }
    db.auth.password = newPassword.trim();
    saveDatabase(db);
    return res.json({ success: true, message: "تم تغيير كلمة المرور بنجاح!" });
  } else {
    return res.status(400).json({ error: "كلمة المرور الحالية غير صحيحة!" });
  }
});

// Initialize Gemini safely
let ai: GoogleGenAI | null = null;
try {
  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey) {
    ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  } else {
    console.warn("⚠️ GEMINI_API_KEY is not defined. AI cover letter features will run in simulated mode.");
  }
} catch (err) {
  console.error("Failed to initialize Gemini:", err);
}

// REST API for AI letter generation
app.post("/api/gemini/letter", async (req, res) => {
  try {
    const { certificate } = req.body;
    if (!certificate) {
      return res.status(400).json({ error: "بيانات المستخلص مطلوبة" });
    }

    if (!ai) {
      // Fallback response if API key is not configured yet
      const fallbackSubject = `طلب مراجعة واعتماد مستخلص الأعمال الحالية - مشروع ${certificate.projectName || "المشروع"}`;
      const fallbackBody = `السلام عليكم ورحمة الله وبركاته،\n\nنرفق لكم طيه مستخلص الأعمال الجاري رقم (${certificate.certificateNumber || "1"}) عن الأعمال المنفذة في مشروع (${certificate.projectName || "المشروع"}) للفترة المحددة.\n\nبيانات المستخلص:\n- إجمالي العقد: ${certificate.contractValue?.toLocaleString() || "0"} ريال\n- صافي المستحق الحالي: ${certificate.items ? "سيتم احتسابه" : "0"} ريال\n\nيرجى التكرم بالمراجعة والاعتماد للصرف.\n\nوتقبلوا وافر التحية والتقدير،\n${certificate.contractorName || "المقاول"}`;
      return res.json({ subject: fallbackSubject, body: fallbackBody, simulated: true });
    }

    const {
      title,
      certificateNumber,
      projectName,
      clientName,
      contractorName,
      contractValue,
      duration,
      siteEngineer,
      items = [],
    } = certificate;

    // Calculate sum of works
    const completedVal = items.reduce((sum: number, it: any) => {
      const prev = Number(it.prevQty) || 0;
      const curr = Number(it.currQty) || 0;
      const rate = Number(it.rate) || 0;
      return sum + ((prev + curr) * rate);
    }, 0);

    const currVal = items.reduce((sum: number, it: any) => {
      const curr = Number(it.currQty) || 0;
      const rate = Number(it.rate) || 0;
      return sum + (curr * rate);
    }, 0);

    const prompt = `أنت مهندس إدارة مشاريع ومحاسب مقاولات خبير ومحترف جداً. 
مطلوب صياغة رسالة بريد إلكتروني (إيميل) رسمية ووقورة جداً باللغة العربية الفصحى موجهة إلى المالك أو الاستشاري لتقديم ومطالبة باعتماد وصرف مستخلص أعمال جاري.

بيانات المستخلص الحالي:
- عنوان المستخلص: ${title || "مستخلص أعمال"}
- رقم المستخلص: ${certificateNumber || "1"}
- اسم المشروع: ${projectName || ""}
- اسم العميل/المالك: ${clientName || ""}
- اسم شركة المقاولات/المقاول: ${contractorName || ""}
- قيمة العقد الإجمالية: ${contractValue ? contractValue.toLocaleString() : "غير محدد"} ريال سعودي
- مدة العقد/الفترة: ${duration || "تاريخه"}
- قيمة الأعمال المنفذة في هذا المستخلص الحالي: ${currVal.toLocaleString()} ريال سعودي
- إجمالي قيمة الأعمال المنفذة تراكمياً حتى تاريخه: ${completedVal.toLocaleString()} ريال سعودي
- مهندس الموقع المشرف: ${siteEngineer || ""}

الرسالة يجب أن تتضمن:
1. تحية رسمية فخمة تليق بجهات الإشراف والمالكين.
2. تفصيل واضح للأعمال المنجزة وأهميتها وقيمتها المالية بأسلوب مهني ولبق.
3. طلب لطيف ومؤدب مشفوعاً بالرجاء لزيارة الموقع للمعاينة أو مراجعة الأوراق وتوقيع المستخلص لتسهيل التدفق المالي للمشروع واستمرار العمل بنفس الكفاءة.
4. خاتمة رسمية راقية مع مساحات ترحيبية للنقاش أو التعديل.

يرجى إلحاق الرد في صيغة JSON تحتوي على الحقول التالية فقط ولا شيء سواها (لا تضع مقدمات ولا وسوم ماركداون إضافية غير الصالحة لـ JSON):
{
  "subject": "عنوان جذاب ورسمي للإيميل",
  "body": "محتوى الإيميل بالكامل منسقاً بشكل جميل مع فواصل أسطر ومقاطع واضحة"
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const responseText = response.text || "{}";
    try {
      const parsed = JSON.parse(responseText.trim());
      return res.json({
        subject: parsed.subject,
        body: parsed.body,
        simulated: false,
      });
    } catch (parseErr) {
      console.error("Error parsing JSON from Gemini:", responseText);
      // Fallback return
      return res.json({
        subject: `تقديم ${title || "المستخلص الجاري"} - مشروع ${projectName}`,
        body: responseText,
        simulated: false,
      });
    }
  } catch (error: any) {
    console.error("Gemini route error:", error);
    res.status(500).json({ error: error.message || "حدث خطأ أثناء معالجة الطلب بالذكاء الاصطناعي" });
  }
});

// Setup Vite middleware for development or Static serve for production
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
