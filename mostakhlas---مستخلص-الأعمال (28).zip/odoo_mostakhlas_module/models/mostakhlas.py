# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

class MostakhlasCertificate(models.Model):
    _name = 'mostakhlas.certificate'
    _description = 'Contractor Mostakhlas Certificate (المستخلص المالي)'
    _order = 'date desc, id desc'

    name = fields.Char(string='رقم المستخلص المرجعي', required=True, copy=False, default=lambda self: _('مستخلص جديد'))
    title = fields.Char(string='عنوان المستخلص', required=True, default='مستخلص جاري رقم 7')
    certificate_number = fields.Char(string='رقم المستخلص', required=True, default='م-7')
    date = fields.Date(string='تاريخ المستخلص', default=fields.Date.today, required=True)
    
    # Partner & Project Info
    contractor_id = fields.Many2one('res.partner', string='المقاول المنفذ (الطرف الثاني)', required=True, domain=[('is_company', '=', True)])
    project_id = fields.Many2one('project.project', string='المشروع الإنشائي المربوط')
    project_name_custom = fields.Char(string='اسم المشروع (يدوي)', help='يستخدم في حال عدم ربطه بمشروع أودو تلقائي')
    client_name = fields.Char(string='اسم المالك (الطرف الأول)', default='مجموعة روعة القابضة')
    
    # Contract Details
    contract_value = fields.Float(string='القيمة الإجمالية للعقد (ريال)', default=115682208.0)
    contract_date = fields.Date(string='تاريخ العقد الإنشائي')
    duration = fields.Char(string='مدة تنفيذ المشروع', default='24 شهراً')
    
    # Config parameters
    calculation_method = fields.Selection([
        ('cumulative', 'تراكمية تعاقدية عامة'),
        ('direct', 'طريقة جاري 7 المباشرة (المرفق بالصورة)')
    ], string='طريقة تصفية الحساب', default='direct', required=True)
    
    retention_percent = fields.Float(string='نسبة خصم ضمان الأعمال %', default=5.0)
    advance_deduction_percent = fields.Float(string='نسبة استرداد الدفعة المقدمة %', default=5.0)
    vat_percent = fields.Float(string='نسبة ضريبة القيمة المضافة %', default=15.0)
    
    # Legacy / manual inputs for standard cumulative method
    previous_payments = fields.Float(string='ما تم صرفه للمقاول سابقاً (ريال)', default=17599007.55)
    stage_progress_percent = fields.Float(string='نسبة إنجاز المرحلة الأولى والثانية %', default=24.17)
    
    # Financial Totals computed automatically
    items_ids = fields.One2many('mostakhlas.certificate.line', 'certificate_id', string='بنود الأعمال والكميات المنفذة')
    
    total_completed_works_val = fields.Float(string='إيجاز الأعمال الإجمالي التراكمي', compute='_compute_totals', store=True)
    previous_completed_works_val = fields.Float(string='إجمالي قيمة المنفذ سابقاً', compute='_compute_totals', store=True)
    current_works_val = fields.Float(string='إمر الصرف الحالي (قبل الخصم)', compute='_compute_totals', store=True)
    
    advance_deduction_amount = fields.Float(string='خصم الدفعة المقدمة', compute='_compute_totals', store=True)
    current_value_after_advance = fields.Float(string='المستخلص بعد خصم الدفعة المقدمة', compute='_compute_totals', store=True)
    vat_amount = fields.Float(string='الضريبة القيمة المضافة VAT', compute='_compute_totals', store=True)
    current_value_with_vat = fields.Float(string='الإجمالي شامل الضريبة المضافة', compute='_compute_totals', store=True)
    retention_amount = fields.Float(string='خصم ضمان الأعمال المستقطع', compute='_compute_totals', store=True)
    other_deductions = fields.Float(string='خصومات وغرامات أخرى', default=0.0)
    
    final_net_payable = fields.Float(string='صافي مستخلص جاري النهائي (ريال)', compute='_compute_totals', store=True)
    
    # Human Approvals details
    site_engineer = fields.Char(string='مهندس الموقع المشرف', default='م. محمد الحربي (مهندس التنفيذ)')
    consultant_engineer = fields.Char(string='المهندس الاستشاري / المدير العام', default='المهندس الاستشاري / المدير العام')
    contractor_representative = fields.Char(string='ممثل المقاول المعتمد', default='ممثل شركة روعة عالم التصميم')
    
    state = fields.Selection([
        ('draft', 'مسودة المستخلص'),
        ('under_review', 'تحت الفحص الهندسي والتدقيق ومراجعة الاستشاري'),
        ('approved', 'تم الاعتماد النهائي والمطابقة المتبادلة'),
        ('paid', 'تم التحويل البنكي والصرف الصافي للمقاول')
    ], string='الحالة الإجرائية للمستخلص', default='draft', tracking=True)

    @api.depends('items_ids', 'items_ids.rate', 'items_ids.prev_qty', 'items_ids.curr_qty', 
                 'calculation_method', 'retention_percent', 'advance_deduction_percent', 
                 'vat_percent', 'previous_payments', 'other_deductions')
    def _compute_totals(self):
        for rec in self:
            tot_cumulative = 0.0
            tot_prev_val = 0.0
            tot_curr_val = 0.0
            
            for line in rec.items_ids:
                tot_prev_val += line.prev_qty * line.rate
                tot_curr_val += line.curr_qty * line.rate
                tot_cumulative += (line.prev_qty + line.curr_qty) * line.rate
                
            rec.total_completed_works_val = tot_cumulative
            rec.previous_completed_works_val = tot_prev_val
            rec.current_works_val = tot_curr_val
            
            if rec.calculation_method == 'direct':
                # Direct method mimicking Jari-7 image formulas
                rec.advance_deduction_amount = tot_curr_val * (rec.advance_deduction_percent / 100.0)
                rec.current_value_after_advance = tot_curr_val - rec.advance_deduction_amount
                rec.vat_amount = rec.current_value_after_advance * (rec.vat_percent / 100.0)
                rec.current_value_with_vat = rec.current_value_after_advance + rec.vat_amount
                rec.retention_amount = tot_curr_val * (rec.retention_percent / 100.0)
                
                # final_net_payable = CurrentValueWithVAT - RetentionGuarantee - otherDeductions
                rec.final_net_payable = rec.current_value_with_vat - rec.retention_amount - rec.other_deductions
            else:
                # Standard cumulative method (Cumulative calculation logic)
                rec.retention_amount = tot_cumulative * (rec.retention_percent / 100.0)
                rec.advance_deduction_amount = rec.advance_deduction_percent  # Flat rate deduction in generic format
                net_cumulative_val = tot_cumulative - rec.retention_amount - rec.advance_deduction_amount - rec.other_deductions
                
                current_net_due = net_cumulative_val - rec.previous_payments
                current_net_due_positive = current_net_due if current_net_due > 0 else 0.0
                
                rec.current_value_after_advance = current_net_due_positive
                rec.vat_amount = current_net_due_positive * (rec.vat_percent / 100.0)
                rec.current_value_with_vat = current_net_due_positive + rec.vat_amount
                rec.final_net_payable = current_net_due_positive + rec.vat_amount

    def action_under_review(self):
        self.write({'state': 'under_review'})

    def action_approve(self):
        # Optional validation before approval
        if not self.items_ids:
            raise ValidationError(_('لا يمكن اعتماد مستخلص فارغ بدون بنود أعمال منفذة!'))
        self.write({'state': 'approved'})

    def action_pay(self):
        self.write({'state': 'paid'})

    def action_draft(self):
        self.write({'state': 'draft'})


class MostakhlasCertificateLine(models.Model):
    _name = 'mostakhlas.certificate.line'
    _description = 'Mostakhlas Base Work Items (بنود أعمال المقاول)'
    
    certificate_id = fields.Many2one('mostakhlas.certificate', string='المستخلص الأب', ondelete='cascade', required=True)
    item_number = fields.Char(string='رقم البند المرجعي والميداني', required=True, default='1')
    description = fields.Text(string='بيان الأعمال وبنود التشييد والخلطات بالتفصيل', required=True)
    unit = fields.Char(string='وحدة القياس الهندسية', default='متر مكعب', required=True)
    
    contract_qty = fields.Float(string='الكمية التعاقدية الكلية المعتمدة', default=0.0)
    rate = fields.Float(string='فئة وتكلفة البند الفردية (ريال)', default=0.0)
    
    prev_qty = fields.Float(string='الكمية المنفذة في دورات سابقة', default=0.0)
    curr_qty = fields.Float(string='الكمية الحالية المنفذة هذه الدورة', default=0.0)
    
    total_qty = fields.Float(string='الكمية التراكمية الإجمالية المنفذة', compute='_compute_qty', store=True)
    total_val = fields.Float(string='القيمة الإجمالية المنفذة', compute='_compute_qty', store=True)

    @api.depends('prev_qty', 'curr_qty', 'rate')
    def _compute_qty(self):
        for line in self:
            line.total_qty = line.prev_qty + line.curr_qty
            line.total_val = (line.prev_qty + line.curr_qty) * line.rate
